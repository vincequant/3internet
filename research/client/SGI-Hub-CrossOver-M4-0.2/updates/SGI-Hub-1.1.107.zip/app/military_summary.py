"""Military presentation, using status-window name thresholds (not a combat score)."""
import tkinter as tk
from tkinter import ttk
from state_extensions import training_progress
NAMES={'infantry':('步兵','强化步兵','重装步兵'),'cavalry':('骑兵','强化骑兵','铁骑兵'),'bow':('弓兵','弩兵','连弩')}
COLS=('兵种级别','库存兵数量','每年夏季募兵≈','训练度','攻击基值 小/中/大','练兵效率')
def troop_info(kind,raw):
 t=training_progress(raw)
 if t is None:return {'name':'兵种等级未知','training':None,'tier':None}
 tier=0 if raw<100 else 1 if raw<200 else 2
 return {'name':NAMES[kind][tier],'training':t,'tier':tier}
class MilitarySummary(tk.Frame):
 """Compact current-state table; forecasts belong in the decision support page."""
 def __init__(self,parent,app=None):
  super().__init__(parent,bg='#f7f4ea');self.app=app;self.tiles={};self.busy=False;self.op_rows={}
  for col,title in enumerate(COLS):
   tk.Label(self,text=title,bg='#eee9d9',fg='#756443',font=('Microsoft YaHei',10),anchor='w').grid(row=0,column=col,sticky='ew',padx=2,pady=(2,1))
   self.columnconfigure(col,weight=1)
  for row,kind in enumerate(('infantry','cavalry','bow'),1):
   cells=[]
   for col in range(len(COLS)):
    cell=tk.Label(self,bg='#f7f4ea',fg='#302c22',font=('Microsoft YaHei',11,'bold' if col==0 else 'normal'),anchor='w',padx=3,pady=1)
    cell.grid(row=row,column=col,sticky='ew',padx=2);cells.append(cell)
   self.tiles[kind]=cells
  self.note=tk.Label(self,text='练兵效率按库存档位，相对1万以下为100%；9万以上最低50%。百分比乘的是单次训练条，不是兵力。人口帽（约人口/10，最多50000）是每种兵各自的单次上限，不是三兵种抢一笔。还可=该兵种相对帽还能建多少；建练兵所不会减骑/弓还可。未扣断线。',bg='#f7f4ea',fg='#786e56',anchor='w',justify='left',wraplength=720,font=('Microsoft YaHei',9))
  self.note.grid(row=4,column=0,columnspan=len(COLS),sticky='ew',padx=3,pady=3)
  box=tk.Frame(self,bg='#f7f4ea');box.grid(row=5,column=0,columnspan=len(COLS),sticky='ew',padx=3,pady=(0,4))
  self.city_tree=ttk.Treeview(box,columns=('city','cap','infantry','cavalry','bow'),show='headings',height=5)
  for key,title,width in (('city','城市',70),('cap','人口帽',80),('infantry','步 相对帽还可',110),('cavalry','骑 相对帽还可',110),('bow','弓 相对帽还可',110)):
   self.city_tree.heading(key,text=title);self.city_tree.column(key,width=width,stretch=True)
  y=ttk.Scrollbar(box,command=self.city_tree.yview);self.city_tree.configure(yscrollcommand=y.set)
  self.city_tree.pack(side='left',fill='x',expand=True);y.pack(side='right',fill='y')
  self.ops_note=tk.Label(self,text='最近两季指令（不含夏季自动增兵）。点出征/移动行可定位部队。录用是本季人事：同城随机抽人，下达前不能点名；成功失败在本季战略阶段出，不必等下季。Hub 要等归属从在野翻过来才记账。',bg='#f7f4ea',fg='#786e56',anchor='w',justify='left',wraplength=720,font=('Microsoft YaHei',9))
  self.ops_note.grid(row=6,column=0,columnspan=len(COLS),sticky='ew',padx=3,pady=(6,0))
  ops_box=tk.Frame(self,bg='#f7f4ea');ops_box.grid(row=7,column=0,columnspan=len(COLS),sticky='nsew',padx=3,pady=(0,4))
  self.rowconfigure(7,weight=1)
  self.ops_tree=ttk.Treeview(ops_box,columns=('when','line'),show='headings',height=6)
  self.ops_tree.heading('when',text='季度');self.ops_tree.heading('line',text='指令')
  self.ops_tree.column('when',width=180,stretch=False);self.ops_tree.column('line',width=520,stretch=True)
  oy=ttk.Scrollbar(ops_box,command=self.ops_tree.yview);self.ops_tree.configure(yscrollcommand=oy.set)
  self.ops_tree.pack(side='left',fill='both',expand=True);oy.pack(side='right',fill='y')
  self.ops_tree.bind('<<TreeviewSelect>>',self.locate_op)
  self.bind('<Configure>',lambda e:(self.note.configure(wraplength=max(180,e.width-10)),self.ops_note.configure(wraplength=max(180,e.width-10))))
 def update_force(self,force,state=None):
  from recruitment_summary import annual_recruitment,city_recruit_rows,recruitment_text
  from training_prediction import describe_stock_efficiency
  totals=annual_recruitment(state,force.get('force_id'))
  from preparation_model import training_bases
  from unit_target_attack import supported_combat_build
  for kind,cells in self.tiles.items():
   name,count,recruits,training,attack=cells[:5]
   recruits.config(text=recruitment_text(totals[kind]))
   info=troop_info(kind,force.get('armament_raw',{}).get(kind));stock=force.get('troop_stock',{}).get(kind)
   name.config(text=info['name']);count.config(text=f'{stock:,}' if type(stock) is int else '未知')
   training.config(text=f"{info['training']} / 100" if info['training'] is not None else '未知')
   bases=training_bases(kind,force.get('armament_raw',{}).get(kind)) if supported_combat_build((state or {}).get('build_sha256')) else None
   attack.config(text=' / '.join(map(str,bases['unit'])) if bases and all(v is not None for v in bases['unit']) else '缺参数' if bases else '未核定')
   if len(cells)>5:cells[5].config(text=describe_stock_efficiency(stock))
  tree=getattr(self,'city_tree',None)
  if tree is not None:
   tree.delete(*tree.get_children())
   for row in city_recruit_rows(state,force.get('force_id')):
    cap='未知' if row['cap'] is None else f"{row['cap']:,}"
    tree.insert('','end',values=(row['name'],cap,row['cells']['infantry'],row['cells']['cavalry'],row['cells']['bow']))
  if getattr(self,'ops_tree',None) is not None:
   self._fill_ops(state,force.get('force_id'))
 def _fill_ops(self,state,force_id):
  import sys
  from pathlib import Path
  bridge=str(Path(__file__).resolve().parent.parent/'bridge')
  if bridge not in sys.path:
   sys.path.insert(0,bridge)
  from state_history import recent_quarter_ops
  tree=self.ops_tree;self.busy=True;self.op_rows={}
  try:
   tree.delete(*tree.get_children())
   blocks=recent_quarter_ops((state or {}).get('history') or {},force_id,2)
   if not blocks:
    tree.insert('','end',iid='empty',values=('—','本局尚未记到建营、训练、录用或部队移动'))
    return
   index=0
   for block in blocks:
    ops=block.get('operations') or []
    if not ops:
     tree.insert('','end',iid=str(index),values=(block.get('label') or '—','本季无指令'));index+=1
     continue
    for item in ops:
     iid=str(index);tree.insert('','end',iid=iid,values=(block.get('label') or '',item.get('line') or item.get('field') or ''))
     self.op_rows[iid]=item;index+=1
  finally:
   self.busy=False
 def locate_op(self,_=None):
  if self.busy or self.app is None:return
  selection=self.ops_tree.selection()
  if not selection:return
  item=self.op_rows.get(selection[0]) or {}
  target=item.get('target') or {}
  state=getattr(self.app,'doc',None) or {}
  entities=state.get('entities') or {}
  if target.get('kind')=='field_units' and target.get('unit_id') is not None:
   match=[row for row in entities.get('field_units') or [] if row.get('unit_id')==target.get('unit_id')]
   if len(match)==1:self.app.locate_object('force_units',match[0]);return
  if target.get('kind')=='cities_and_barriers' and target.get('city_id') is not None:
   match=[row for row in entities.get('cities_and_barriers') or [] if row.get('city_id')==target.get('city_id')]
   if len(match)==1:self.app.locate_object('cities',match[0]);return
 def update_prediction(self,state,force):
  # Compatibility for older callers; this summary intentionally shows observed data only.
  pass
