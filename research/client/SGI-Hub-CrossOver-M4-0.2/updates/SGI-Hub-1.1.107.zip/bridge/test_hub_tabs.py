from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class HubTabs(unittest.TestCase):
    def test_force_page_keeps_right_notebook(self):
        text = (ROOT / 'app' / 'omni_window.py').read_text(encoding='utf-8')
        self.assertIn('self.book=ttk.Notebook(right)', text)
        self.assertIn("workspace.add(self.global_page,text='武将资料')", text)
        self.assertIn("self.book.add(overview,text='库存募兵')", text)
        self.assertIn("self.book.add(self.preparation,text='备战部队')", text)
        self.assertNotIn('克敌部队', text)
        self.assertNotIn('CounterPanel', text)
        verify = (ROOT / 'app' / 'verify_gui.py').read_text(encoding='utf-8')
        self.assertIn('force_right_tabs', verify)
        self.assertIn('preparation_columns', verify)
        self.assertNotIn('self.book=self.workspace', text)
        self.assertNotIn('def _arrange_workspace_tabs', text)
        self.assertIn('前10五维均', text)
        self.assertIn('atk_inf', text)
        self.assertNotIn('备战推荐部队攻击', text)
        self.assertNotIn('recommendation_index', text)
        self.assertIn('不含骑马、弓箭加乘', text)
        self.assertIn('kind_skill_flags', text)
        self.assertNotIn('计谋状态', text)
        self.assertNotIn('弓系肉搏', text)
        military = (ROOT / 'app' / 'military_summary.py').read_text(encoding='utf-8')
        self.assertIn("'步 相对帽还可'", military)
        self.assertIn('最近两季', military)
        self.assertIn('locate_op', military)
        self.assertIn('MilitarySummary(card,self)', text)
        self.assertIn('quarter_rows', text)
        self.assertIn('仅当前势力', text)
        self.assertIn('各季操作账', text)
        self.assertIn("f'变化 ({matched})'", text)
        self.assertIn("state='hidden'", text)
        self.assertIn('from state_history import History', (ROOT / 'bridge' / 'windows_bridge.py').read_text(encoding='utf-8'))
