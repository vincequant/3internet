"""全知情报：三国志 Internet 风格的本机小窗口。读取本机8767实时情报API；不写游戏内存，不操作游戏。"""
from __future__ import annotations

import json
import os
import sys
import threading
from datetime import datetime, timezone
from pathlib import Path

from player_view import player_id, local_projection, comparison_ids
from force_relations import at_war, WAR_BACKGROUND, WAR_FOREGROUND, allied, ALLY_BACKGROUND, ALLY_FOREGROUND, regroup_forces
from force_relations import unit_row_tags, WAR_UNIT_TAG, WAR_UNIT_FOREGROUND
import tkinter as tk
from tkinter import font as tkfont
from display_layout import pixels

ROOT = Path(r"D:\Coding\三国志internet")
MATCH = "sgi-e2e-20260912"
LATEST = ROOT / "data" / "omniscient" / MATCH / "latest.json"
PIDFILE = ROOT / "data" / "omniscient" / MATCH / "window.pid"
DRIVER = ROOT / "src" / "sgi_driver"

BG = "#d4d0c0"
DAMASK = "#c8c3ae"
DAMASK_LINE = "#b3ae98"
WELL = "#f7f4ea"
INK = "#2c281c"
GOLD = "#8a6a12"
GOLD_HI = "#c9a227"
SKILL_CELL = "#f4df96"
SKILL_CELL_INK = "#85291c"
MUTED = "#7a7464"
WARN = "#8a3030"
PANEL = "#3a342c"
SCROLL = "#e6d3a6"
BAR_BG = "#c8c4b4"
BAR_GOLD = "#c9a034"
BAR_RED = "#b84838"
BAR_GREEN = "#3f7a3a"
BAR_BLUE = "#3a5e8a"
SELECT = "#6b5420"
TITLE_BG = "#3f3a32"

W, H = 460, 760


def _font_family(root: tk.Tk) -> str:
    families = set(tkfont.families(root))
    for name in ("PingFang SC", "Songti SC", "楷体", "KaiTi", "STKaiti", "SimSun", "宋体", "Microsoft YaHei"):
        if name in families:
            return name
    return "TkDefaultFont"


def load_doc() -> dict | None:
    if not LATEST.exists():
        return None
    return json.loads(LATEST.read_text(encoding="utf-8"))


def age_s(doc: dict | None) -> float | None:
    if not doc or not doc.get("capture_end"):
        return None
    try:
        t = datetime.fromisoformat(doc["capture_end"])
        return (datetime.now(timezone.utc) - t).total_seconds()
    except ValueError:
        return None


def fmt_num(n) -> str:
    if n is None:
        return "未知"
    try:
        n = int(n)
    except (TypeError, ValueError):
        return "未知"
    if n >= 10000:
        return f"{n:,}".replace(",", ",")
    return str(n)


def fmt_wan(n) -> str:
    if n is None:
        return "未知"
    n = int(n)
    if n >= 10000:
        return f"{n/10000:.1f}万".replace(".0万", "万")
    return str(n)


def force_title(f: dict) -> str:
    if f.get("label_from_ui"):
        return str(f["label_from_ui"])
    if f.get("ruler_from_ui"):
        return str(f["ruler_from_ui"]).replace("王", "")
    cities = f.get("cities") or []
    if len(cities) == 1:
        return f"{cities[0]}"
    if cities:
        return f"{cities[0]}"
    oid = f.get("force_slot_id")
    return "无主" if oid is None else f"槽{oid}"


def place_next_to_game(win: tk.Tk):
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.WinDLL("user32", use_last_error=True)
    user32.FindWindowW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]
    user32.FindWindowW.restype = wintypes.HWND
    user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
    hwnd = user32.FindWindowW("三国志 Internet 网际网络威力加强版", "三国志Internet联机版3.5")
    sw = win.winfo_screenwidth()
    sh = win.winfo_screenheight()
    x, y = 16, 48
    if hwnd:
        rc = wintypes.RECT()
        if user32.GetWindowRect(hwnd, ctypes.byref(rc)):
            if rc.right + 8 + W <= sw:
                x, y = rc.right + 8, max(8, rc.top)
            elif rc.left - 8 - W >= 0:
                x, y = rc.left - 8 - W, max(8, rc.top)
            else:
                x, y = max(8, sw - W - 12), max(8, rc.top)
    y = min(y, max(8, sh - H - 40))
    win.geometry(f"{W}x{H}+{x}+{y}")


def intelligence_rows(state, force_id):
    """Join by entity IDs, never by list position; unknown stays unknown."""
    e = state['entities']
    force = next((f for f in e['lords'] if f['force_id'] == force_id), None)
    officers = [g for g in e['generals'] if g['owner_raw'] == force_id]
    cities = [c for c in e['cities_and_barriers'] if c['owner_raw'] == force_id]
    buildings = [b for b in e['production_buildings'] if b['owner_raw'] == force_id]
    rulers = [g for g in e['generals'] if force and g['general_id_raw'] == force['ruler_general_id']]
    capital = next((c for c in e['cities_and_barriers'] if force and c['city_id'] == force['capital_city_id']), None)
    return {'force': force, 'officers': officers, 'cities': cities, 'buildings': buildings, 'force_units': [u for u in e.get('field_units',[]) if force_id is not None and u.get('owner_raw') == force_id],
            'ruler': rulers[0].get('name') if len(rulers) == 1 else None,
            'capital': capital.get('name') if capital else None}


class OmniWindow:
    def __init__(self, root):
        from tkinter import ttk
        import queue
        self.root=root; self.face=_font_family(root); self.doc=None; self.sel=None; self.identity_session=None; self.last_player=None; self.combat_windows=[]
        self.inbox=queue.Queue(maxsize=1); self.stop=threading.Event()
        self.force_iids=[]; self.filter=tk.StringVar(); self.global_filter=tk.StringVar(); self.last_sig=None; self.sorts={}; self.row_records={}; self.rendering_tables=False
        self.city_filter=tk.StringVar(value="全部城市"); self.net_only=tk.BooleanVar(value=True)
        self.changes_one_force=tk.BooleanVar(value=False); self.hide_flat=tk.BooleanVar(value=False)
        root.title('全知情报'); root.configure(bg=DAMASK); root.resizable(True,True)
        root.minsize(850,620)
        style=ttk.Style(root);style.theme_use('clam')
        style.configure('Treeview',background=WELL,fieldbackground=WELL,foreground=INK,rowheight=pixels(27),font=(self.face,11))
        style.configure('Treeview.Heading',background=BG,foreground=GOLD,font=(self.face,11,'bold'))
        style.map('Treeview',background=[('selected',SELECT)],foreground=[('selected','#fff3cf')])
        style.configure('TNotebook',background=DAMASK);style.configure('TNotebook.Tab',padding=(pixels(14),pixels(7)),font=(self.face,11))
        top=tk.Frame(root,bg=PANEL);top.pack(fill='x',padx=10,pady=(10,6))
        tk.Label(top,text='全知情报',bg=PANEL,fg=GOLD_HI,font=(self.face,21,'bold')).pack(side='left',padx=16,pady=8)
        self.status=tk.Label(top,text='连接完整核心情报…',bg=PANEL,fg='#eee3c5',font=(self.face,10));self.status.pack(side='right',padx=12)
        identity_bar=tk.Frame(root,bg=DAMASK);identity_bar.pack(fill='x',padx=12,pady=3)
        self.identity_label=tk.Label(identity_bar,text='我方未确认',bg=DAMASK,fg=WARN,anchor='w');self.identity_label.pack(side='left')
        self.player_choice=tk.StringVar()
        self.player_combo=ttk.Combobox(identity_bar,textvariable=self.player_choice,state='readonly',width=16);self.player_combo.pack(side='left',padx=8)
        from connection import CONNECTION
        mode='disabled' if CONNECTION.remote else 'normal'
        tk.Button(identity_bar,text='手动确认（备用）',command=self.confirm_player,bg=BG,state=mode).pack(side='left')
        tk.Button(identity_bar,text='重新识别我方',command=lambda:self.confirm_player(clear=True),bg=BG,state=mode).pack(side='left',padx=6)
        self.workspace=ttk.Notebook(root);self.workspace.pack(fill='both',expand=True,padx=10)
        self.force_page=tk.Frame(self.workspace,bg=DAMASK)
        self.global_page=tk.Frame(self.workspace,bg=DAMASK)
        self.workspace.add(self.force_page,text='势力情报')
        self.workspace.add(self.global_page,text='武将资料')
        body=tk.Frame(self.force_page,bg=DAMASK);body.pack(fill='both',expand=True)
        tk.Label(self.global_page,text='全地图资料库',bg=DAMASK,fg=GOLD,font=(self.face,18,'bold'),anchor='w').pack(fill='x',padx=12,pady=(10,2))
        tk.Label(self.global_page,text='覆盖所有势力与无归属武将；不受势力列表选择影响。',bg=DAMASK,fg=MUTED,font=(self.face,11),anchor='w').pack(fill='x',padx=12)
        global_search=tk.Frame(self.global_page,bg=DAMASK);global_search.pack(fill='x',padx=12,pady=10)
        tk.Label(global_search,text='查找武将 / 城池 / ID',bg=DAMASK,fg=INK,font=(self.face,11)).pack(side='left')
        tk.Entry(global_search,textvariable=self.global_filter,font=(self.face,11),bg=WELL).pack(side='left',fill='x',expand=True,padx=8)
        self.global_filter.trace_add('write',lambda *_:self.render_detail())
        self.city_combo=ttk.Combobox(global_search,textvariable=self.city_filter,state='readonly',width=14,values=['全部城市'])
        self.city_combo.pack(side='right');self.city_combo.bind('<<ComboboxSelected>>',lambda _:self.render_detail())
        self.global_book=ttk.Notebook(self.global_page);self.global_book.pack(fill='both',expand=True,padx=10,pady=(0,10))
        left=tk.Frame(body,bg=DAMASK,width=pixels(600));left.pack(side='left',fill='y',padx=(0,10));left.pack_propagate(False)
        tk.Label(left,text='势力排序：我军 → 浅红交战 → 浅绿同盟 → 其他',bg=DAMASK,fg=GOLD,font=(self.face,12,'bold')).pack(anchor='w',pady=5)
        self.force_tree=self.tree(left,[('force','势力',65),('prestige','信望值',50),('officers','部将数',50),('units','部队数',50),('top10','前10五维均',78)])
        style.configure('Force.Treeview',rowheight=pixels(56))
        self.force_tree.configure(style='Force.Treeview',show='tree headings',displaycolumns=('prestige','officers','units','top10'))
        self.force_tree.column('#0',width=pixels(310),minwidth=pixels(310),stretch=False)
        self.force_tree.heading('#0',text='势力颜色 / 势力　　手牌（游戏原图）',command=lambda:self.sort(self.force_tree,'force'))
        from force_card_art import ForceCardArtwork
        self.force_art=ForceCardArtwork(root)
        self.force_tree.bind('<Motion>',self.force_card_hint)
        self.force_tree.bind('<ButtonRelease-1>',self.pick_diplomacy_card,add='+')
        self.force_tree.bind('<Leave>',lambda _:self.force_hint.config(text='点击势力查看详情；指向卡牌查看名称。前10五维均＝该势力统武智政魅合计最高的十名部将平均值，不足十人按实有人数。'))
        self.force_tree.tag_configure('player',background='#f4df96',foreground='#85291c',font=(self.face,11,'bold'))
        self.force_tree.tag_configure('unknown',foreground=MUTED)
        self.force_tree.tag_configure('war',background=WAR_BACKGROUND,foreground=WAR_FOREGROUND)
        self.force_tree.tag_configure('ally',background=ALLY_BACKGROUND,foreground=ALLY_FOREGROUND)
        self.force_tree.bind('<<TreeviewSelect>>',self.choose)
        self.force_hint=tk.Label(left,text='点击势力查看详情；指向卡牌查看名称。前10五维均＝该势力统武智政魅合计最高的十名部将平均值，不足十人按实有人数。',bg=DAMASK,fg=MUTED,font=(self.face,9),justify='left',wraplength=560);self.force_hint.pack(fill='x',pady=5)
        right=tk.Frame(body,bg=DAMASK);right.pack(side='left',fill='both',expand=True)
        self.heading=tk.Label(right,text='选择势力',bg=DAMASK,fg=INK,font=(self.face,18,'bold'),anchor='w');self.heading.pack(fill='x',pady=(4,2))
        self.summary=tk.Label(right,text='',bg=DAMASK,fg=MUTED,font=(self.face,11),anchor='w');self.summary.pack(fill='x')
        self.book=ttk.Notebook(right);self.book.pack(fill='both',expand=True)
        overview=tk.Frame(self.book,bg=DAMASK);self.book.add(overview,text='库存募兵')
        card=tk.Frame(overview,bg=WELL,bd=2,relief='sunken');card.pack(fill='both',expand=True,pady=4)
        self.resources=tk.Label(card,text='等待金米与兵种库存',bg=WELL,fg=INK,font=(self.face,14,'bold'),justify='left',anchor='w');self.resources.pack(fill='x',padx=12,pady=(8,4))
        from military_summary import MilitarySummary
        self.military=MilitarySummary(card,self);self.military.pack(fill='both',expand=True,padx=6)
        self.projection=tk.Label(card,text='',bg=WELL,fg=WARN,font=(self.face,10),justify='left',anchor='w')
        ops_page=tk.Frame(self.book,bg=DAMASK);self.book.add(ops_page,text='变化')
        from quarter_ops_panel import QuarterOpsPanel
        self.quarter_ops=QuarterOpsPanel(ops_page,self);self.quarter_ops.pack(fill='both',expand=True,padx=6,pady=6)
        self.filter.trace_add('write',lambda *_:self.render_detail())
        self.tables={};self.frames={}
        specs={
          'officers':('所属武将',[('id','将 ID',55),('name','姓名',90),('skills','技能（资料）',260),('soldiers','兵力',60),('atk_inf','步兵攻击*',80),('atk_cav','骑兵攻击*',80),('atk_bow','弓兵攻击*',80),('lead','统',40),('war','武',40),('intel','智',40),('pol','政',40),('cha','魅',40)]),
          'cities':('城池关隘',[('name','城关',80),('kind','类别',55),('defense','防御',85),('population','人口',80),('dev','开发',55),('commerce','商业',55),('xy','世界坐标',85)]),
          'buildings':('生产建筑',[('kind','类型',85),('id','ID 候选',70),('xy','世界坐标',85)]),
        }
        specs['all_officers']=('全武将',[('id','将 ID',55),('name','姓名',90),('owner','归属',55),('state','状态',75),('city','所在城',70),('lead','统',40),('war','武',40),('intel','智',40),('pol','政',40),('cha','魅',40)])
        specs['wild']=('在野',[('city','所在城',75),('name','姓名',90),('id','将 ID',55),('lead','统',45),('war','武',45),('intel','智',45),('pol','政',45),('cha','魅',45)])
        specs['field_units']=('全图部队 · 红≤5/黄≤10格',[('id','部队 ID',60),('kind','兵种',85),('xy','坐标',70),('generals','编成将',160),('soldiers','兵数',80),('rice','粮食 / 约可吃',130),('combat','编组战力*',85),('morale','士气',55),('attack','部队攻击系数*',130),('siege','攻城攻击参考*',135),('unit_skills','编成将技能（资料）',320),('size','规模',65),('force','势力',65),('near','距我方最近部队',125),('why','依据 / 缺项',240)])
        specs['changes']=('变化',[('time','季度',160),('name','势力',120),('field','操作',760)])
        specs['traps']=('陷阱（只读）',[('id','陷阱 ID',75),('kind','类型',75),('xy','坐标',90),('owner','归属',65),('evidence','依据',380)])
        specs['cities'][1].append(('traps_near','附近陷阱（坐标3格）',260))
        specs['field_units'][1].extend([('base_unit','对部队基值 / 远射',150),('base_building','对建筑基值 / 远射',150)])
        specs['cities'][1].extend([('spring','春金毛收入≈',115),('autumn','秋粮毛收入≈',115),('recruitcap','人口募兵帽',110)])
        specs['field_units'][1].append(('tutorial','行动 / 士气参考',420))
        specs['force_units']=('部队',list(specs['field_units'][1]))
        specs['wild'][1].extend([('city_candidates','同城在野人数',110),('recruit_share','录用参考%（均分假设）',190)])
        from officer_reference import COLUMNS
        for key in ('wild','all_officers'):specs[key][1].extend(COLUMNS)
        specs['wild'][1].append(('rank_score','排序指标',85))
        specs.pop('buildings',None)
        self.table_books={};self.page_filters={};self.top_force_selectors=[]
        for key,(title,cols) in specs.items():
            book=self.global_book if key in ('all_officers','wild') else self.workspace if key in ('field_units','changes','traps') else self.book
            self.table_books[key]=book
            frame=tk.Frame(book,bg=WELL);book.add(frame,text=title);self.frames[key]=frame
            if key in ('officers','cities','force_units','all_officers'):
                bar=tk.Frame(frame,bg=WELL);bar.pack(fill='x',padx=8,pady=6)
                tk.Label(bar,text='筛选',bg=WELL,fg=INK).pack(side='left',padx=5)
                self.page_filters[key]=tk.StringVar();tk.Entry(bar,textvariable=self.page_filters[key],bg=WELL,fg=INK).pack(side='left',fill='x',expand=True)
                self.page_filters[key].trace_add('write',lambda *_:self.render_detail())
            if key in ('field_units','changes','traps'):
                bar=tk.Frame(frame,bg=WELL);bar.pack(fill='x',padx=8,pady=6)
                if key in ('changes','traps'):self.add_force_selector(bar)
                tk.Label(bar,text='筛选',bg=WELL,fg=INK).pack(side='left',padx=5)
                self.page_filters[key]=tk.StringVar();tk.Entry(bar,textvariable=self.page_filters[key],bg=WELL,fg=INK).pack(side='left',fill='x',expand=True)
                self.page_filters[key].trace_add('write',lambda *_:self.render_detail())
                if key=='changes':
                    opts=tk.Frame(frame,bg=WELL);opts.pack(anchor='w',padx=8,pady=(0,4))
                    tk.Checkbutton(opts,text='各季操作账（取消则看最近逐次差分）',variable=self.net_only,command=self.render_detail,bg=WELL,fg=INK).pack(side='left')
                    tk.Checkbutton(opts,text='仅当前势力',variable=self.changes_one_force,command=self.render_detail,bg=WELL,fg=INK).pack(side='left',padx=10)
                    tk.Checkbutton(opts,text='隐藏无增减',variable=self.hide_flat,command=self.render_detail,bg=WELL,fg=INK).pack(side='left')
                    self.change_info=tk.Label(frame,text='只记建营、训练、录用、出征和部队移动。夏季自动增兵不记。没有这些时不显示变化页。',bg=WELL,fg=MUTED,anchor='w',justify='left',wraplength=980,font=(self.face,10))
                    self.change_info.pack(fill='x',padx=8,pady=(0,4))
            if key=='cards':
                tk.Label(frame,text='每势力 5 个手牌槽 · 独立只读采集，每秒更新 · 持有不代表当前可使用',bg=WELL,fg=MUTED,font=(self.face,10),anchor='w').pack(fill='x',padx=8,pady=8)
            if key=='traps':
                self.trap_info=tk.Label(frame,text='等待陷阱采集',bg=WELL,fg=MUTED,anchor='w');self.trap_info.pack(fill='x',padx=8,pady=4)
            if key=='wild':
                from talent_filters import TalentFilters
                self.talent_filters=TalentFilters(frame,self);self.talent_filters.pack(fill='x')
                from native_city_map import CityLocator
                self.city_locator=CityLocator(frame);self.city_locator.canvas.configure(height=150)
            if key=='officers':
                tk.Label(frame,text='步骑弓列是按该将当前带兵与库存取小后的出兵攻击数值，不含骑马、弓箭加乘，非实伤。骑兵/弓兵格高亮只表示资料具备骑马/弓箭。',bg=WELL,fg=MUTED,anchor='w',wraplength=950).pack(fill='x',padx=8,pady=4)
            if key in ('field_units','force_units'):
                tk.Label(frame,text='粮食天数按攻略每回合约耗兵数÷6（满编约6天，第7天开始饿），未扣城补给。部队攻击系数按公式：步/骑为战力×（基础＋规模＋武装）÷150，弓兵为客户端远射表。不是实伤。地形、防御、宝物等未计入。',bg=WELL,fg=MUTED,anchor='w',wraplength=950).pack(fill='x',padx=8,pady=5)
            self.tables[key]=self.tree(frame,cols,on_scroll=self._schedule_officer_skill_hl if key=='officers' else None)
            if key=='officers':
                self.tables[key].configure(displaycolumns=('id','name','soldiers','atk_inf','atk_cav','atk_bow','skills','lead','war','intel','pol','cha'))
                self.tables[key].bind('<Configure>',lambda _e:self._schedule_officer_skill_hl(),add='+')
            if key=='wild':
                for col,title in {'total':'五维合计','ref_attack':'攻击力','ref_strategy':'计略 %','ref_diplomacy':'外交力','ref_skills':'技能'}.items():self.tables[key].heading(col,text=title)
                self.tables[key].configure(displaycolumns=[c[0] for c in cols if c[0] not in ('ref_total','ref_match','rank_score')])
            if key in ('field_units','force_units'):
                order=[c[0] for c in cols]
                self.tables[key].configure(displaycolumns=order)
            if key=='cities':
                order=[c[0] for c in cols];order.remove('traps_near');order.insert(1,'traps_near');self.tables[key].configure(displaycolumns=order)
                self.tables[key].tag_configure('city_trapped',background='#f8d6d3',foreground='#9d241a')
        from diplomacy_cards import DiplomacyCards
        self.diplomacy_cards=DiplomacyCards(self.book,self);self.book.add(self.diplomacy_cards,text='外交卡片')
        from preparation_panel import PreparationPanel
        self.preparation=PreparationPanel(self.book,self);self.book.add(self.preparation,text='备战部队')
        from battle_panel import BattlePanel
        self.battles=BattlePanel(self.workspace,self);self.workspace.add(self.battles,text='战役')
        from city_talent import CityTalent
        self.city_talent=CityTalent(self.global_book,self);self.global_book.add(self.city_talent,text='城池人才')
        from nearby_intel import NearbyIntel
        self.nearby_intel=NearbyIntel(self.workspace,self,legacy_id=None);self.workspace.add(self.nearby_intel,text='附近情报')
        from world_cities import WorldCities
        self.world_cities=WorldCities(self.workspace,self);self.workspace.add(self.world_cities,text='全图城关')
        from panorama_map import PanoramaMap
        self.panorama=PanoramaMap(self.workspace,title='全景地图',detachable=True)
        self.workspace.add(self.panorama,text='全景地图')
        self._panorama_sig=None
        self.workspace.bind('<<NotebookTabChanged>>',self._on_workspace_tab,add='+')
        self.decision_panel=self.talent_filters
        from rules_panel import RulesPanel
        self.rules_panel=RulesPanel(self.workspace,self,legacy_id=None);self.workspace.add(self.rules_panel,text='攻略预判')
        rule_bar=tk.Frame(self.rules_panel,bg=WELL);rule_bar.pack(fill='x',padx=8,pady=5,before=self.rules_panel.winfo_children()[0]);self.add_force_selector(rule_bar)
        self.workspace.tab(self.rules_panel.diplomacy_page,text='外交对比')
        from original_art_panel import OriginalArtPanel,open_officer
        self.original_art=OriginalArtPanel(self.rules_panel.tabs,self);self.rules_panel.tabs.add(self.original_art,text='原版素材图鉴')
        for key in ('officers','all_officers','wild'):
            self.tables[key].bind('<Double-1>',lambda event,k=key:open_officer(self,k),add='+')
        self.location_window=None;self.object_locator=None
        for key in ('cities','buildings','field_units','force_units','traps'):
            if key in self.tables:self.tables[key].bind('<<TreeviewSelect>>',lambda event,k=key:self.locate_object(k))
        self.tables['wild'].bind('<<TreeviewSelect>>',self.locate_wild)
        self.global_book.select(self.frames['wild'])
        self.workspace.select(self.force_page)
        foot=tk.Frame(root,bg=DAMASK);foot.pack(fill='x',padx=12,pady=7)
        self.coverage=tk.Label(foot,text='部队、训练条、外交关系仍未解析',bg=DAMASK,fg=WARN,font=(self.face,10));self.coverage.pack(side='left')
        tk.Button(foot,text='关闭',command=root.destroy,bg=BG).pack(side='right')
        self.root.bind('<Destroy>',lambda e:self.stop.set() if e.widget is self.root else None)
        threading.Thread(target=self.fetch,daemon=True,name='native-hub-api-reader').start()
        from force_name_colors import ForceNameColors
        self.force_name_colors=ForceNameColors(self)
        self.root.after(200,self.tick)

    def add_force_selector(self,parent):
        from tkinter import ttk
        tk.Label(parent,text='当前势力',bg=WELL,fg=INK).pack(side='left',padx=(0,5))
        var=tk.StringVar();combo=ttk.Combobox(parent,textvariable=var,state='readonly',width=14);combo.pack(side='left',padx=(0,8));self.top_force_selectors.append((var,combo))
        def select(_=None):
            if '#' not in var.get():return
            self.sel=int(var.get().rsplit('#',1)[1])
            if self.force_tree.exists(str(self.sel)):self.force_tree.selection_set(str(self.sel))
            self.refresh_force_art();self.render_detail()
        combo.bind('<<ComboboxSelected>>',select)

    def tree(self,parent,cols,on_scroll=None):
        from tkinter import ttk
        frame=tk.Frame(parent,bg=WELL);frame.pack(fill='both',expand=True)
        tree=ttk.Treeview(frame,columns=[c[0] for c in cols],show='headings',selectmode='browse')
        sy=ttk.Scrollbar(frame,orient='vertical',command=tree.yview);sx=ttk.Scrollbar(frame,orient='horizontal',command=tree.xview)
        def ycmd(*a):
            sy.set(*a)
            if on_scroll:on_scroll()
        def xcmd(*a):
            sx.set(*a)
            if on_scroll:on_scroll()
        tree.configure(yscrollcommand=ycmd,xscrollcommand=xcmd)
        frame.rowconfigure(0,weight=1);frame.columnconfigure(0,weight=1)
        tree.grid(row=0,column=0,sticky='nsew');sy.grid(row=0,column=1,sticky='ns');sx.grid(row=1,column=0,sticky='ew')
        for key,title,width in cols:
            tree.heading(key,text=title,command=lambda k=key,t=tree:self.sort(t,k))
            tree.column(key,width=pixels(width),minwidth=pixels(width),stretch=True)
        return tree

    def sort(self,tree,key):
        items=[(tree.set(i,key),i) for i in tree.get_children()]
        def order(pair):
            try:return (0,float(pair[0].replace(',','').replace('%','').removeprefix('≈')))
            except (ValueError,AttributeError):return (1,pair[0])
        old=self.sorts.get(tree);reverse=not old[1] if old and old[0]==key else True
        self.sorts[tree]=(key,reverse);items.sort(key=order,reverse=reverse)
        if tree is getattr(self,'tables',{}).get('field_units'):
            from unit_proximity import RANK
            items.sort(key=lambda pair:min([RANK.get(str(t).removeprefix('unit_'),3) for t in tree.item(pair[1],'tags')] or [3]))
        if key.startswith('ref_') or key=='total':items.sort(key=lambda pair:pair[0] in ('—','未知','未匹配',''))
        for pos,(_,iid) in enumerate(items):tree.move(iid,'',pos)
        if tree is self.force_tree:regroup_forces(tree,self.doc)
        if tree is self.tables.get('officers'):self._schedule_officer_skill_hl()

    def _clear_officer_skill_hl(self):
        for w in getattr(self,'_officer_skill_hl',[]):
            try:w.destroy()
            except tk.TclError:pass
        self._officer_skill_hl=[]

    def _schedule_officer_skill_hl(self):
        if getattr(self,'rendering_tables',False):return
        job=getattr(self,'_officer_hl_job',None)
        if job is not None:
            try:self.root.after_cancel(job)
            except tk.TclError:pass
        self._officer_hl_job=self.root.after_idle(self._paint_officer_skill_hl)

    def _paint_officer_skill_hl(self):
        self._officer_hl_job=None
        self._clear_officer_skill_hl()
        tree=self.tables.get('officers')
        if tree is None or getattr(self,'rendering_tables',False):return
        flags=getattr(self,'officer_skill_flags',{})
        for iid in tree.get_children():
            mark=flags.get(iid) or {}
            for col,on in (('atk_cav',mark.get('cavalry')),('atk_bow',mark.get('bow'))):
                if not on:continue
                box=tree.bbox(iid,col)
                if not box or box[2]<=1 or box[3]<=1:continue
                x,y,w,h=box
                lab=tk.Label(tree,text=tree.set(iid,col),bg=SKILL_CELL,fg=SKILL_CELL_INK,font=(self.face,10),anchor='center',bd=0)
                lab.place(x=x,y=y,width=w,height=h)
                lab.bind('<Button-1>',lambda _e,i=iid:self._select_officer_row(i))
                lab.bind('<Double-1>',lambda _e,i=iid:self._open_officer_row(i))
                self._officer_skill_hl.append(lab)

    def _select_officer_row(self,iid):
        tree=self.tables['officers']
        if tree.exists(iid):
            tree.selection_set(iid);tree.focus(iid)
        return 'break'

    def _open_officer_row(self,iid):
        self._select_officer_row(iid)
        from original_art_panel import open_officer
        open_officer(self,'officers')
        return 'break'

    def fetch(self):
        from portable_client import poll
        poll(self)

    def tick(self):
        try:
            p=self.inbox.get_nowait()
            if not p.get('fresh'):
                from portable_client import invalidate_player
                if self.doc:self.doc=invalidate_player(self.doc)
                if p.get('state'):p['state']=invalidate_player(p['state'])
                elif self.doc:self.render()
            if p.get('state'):
                self.doc=p['state'];sig=str(self.doc.get('snapshot_id'))+json.dumps(self.doc['entities'],ensure_ascii=False)+json.dumps(self.doc['current_local_projection'])+json.dumps(self.doc.get('history',{}),ensure_ascii=False)+json.dumps(self.doc.get('player_identity',{}),ensure_ascii=False)
                if sig!=self.last_sig:self.last_sig=sig;self.render()
            from portable_client import status_text
            if p.get('fresh') is not True:
                p['fresh']=False
            text,color=status_text(p,self.doc)
            self.status.config(text=text,fg=color)
        except __import__('queue').Empty:pass
        if not self.stop.is_set():self.root.after(250,self.tick)

    def confirm_player(self,clear=False):
        from tkinter import messagebox
        from portable_client import confirm_player
        if not self.doc:return
        fid=None if clear else self.player_options.get(self.player_choice.get())
        if not clear and fid is None:return
        try:
            confirm_player(self.doc,fid)
        except Exception as error:messagebox.showerror('我方身份未更改',str(error))

    def choose(self,_=None):
        selection=self.force_tree.selection()
        if selection:self.sel=int(selection[0]);self.refresh_force_art();self.render_detail()

    def refresh_force_art(self):
        if not self.doc:return
        from native_city_map import state_force_rgb
        from tkinter import ttk
        selected_war=at_war(self.doc,self.sel)
        ttk.Style(self.root).map('Force.Treeview',background=[('selected',WAR_BACKGROUND if selected_war else ALLY_BACKGROUND if allied(self.doc,self.sel) else SELECT)],foreground=[('selected',WAR_FOREGROUND if selected_war else ALLY_FOREGROUND if allied(self.doc,self.sel) else '#fff3cf')])
        for force in self.doc['entities']['lords']:
            fid=force['force_id'];iid=str(fid)
            color=state_force_rgb(self.doc,fid)
            if self.force_tree.exists(iid):self.force_tree.item(iid,image=self.force_art.row(force,color,fid==self.sel,player_id(self.doc),at_war(self.doc,fid),allied(self.doc,fid)))

    def pick_diplomacy_card(self,event):
        iid=self.force_tree.identify_row(event.y)
        if not iid or not self.doc or self.force_tree.identify_column(event.x)!='#0':return
        box=self.force_tree.bbox(iid,'#0')
        if not box:return
        if 'image' not in self.force_tree.identify_element(event.x,event.y):return
        start=event.x
        while start>box[0] and 'image' in self.force_tree.identify_element(start-1,event.y):start-=1
        x=(event.x-start)/getattr(self.root,'sgi_ui_scale',1.)
        slot=(x-74)//42
        if not 0<=slot<5 or not 74<=x<284:return
        fid=int(iid)
        self.root.after_idle(lambda:self.rules_panel.pick_card(fid,int(slot)+1))

    def force_card_hint(self,event):
        iid=self.force_tree.identify_row(event.y)
        if not iid or not self.doc:return
        force=next((f for f in self.doc['entities']['lords'] if str(f['force_id'])==iid),None)
        if not force:return
        slots=force.get('hand_cards',{}).get('slots',[])
        self.force_hint.config(text=force['name']+'：'+(' / '.join(r['name'] for r in slots) if slots else '手牌暂不可用'))

    def render(self):
        meta=self.doc.get('player_identity') or {};session=meta.get('session_id');pid=player_id(self.doc)
        if session!=self.identity_session:
            for window in self.combat_windows:
                if window.winfo_exists():window.destroy()
            self.combat_windows=[]
            self.sel=None;self.sorts.clear();self.force_art.rows.clear();self.row_records.clear()
            self.filter.set('');self.last_player=None
        if pid is not None and pid!=self.last_player:self.sel=pid
        self.identity_session=session;self.last_player=pid
        self.player_options={f"{f['name']}（{f['force_id']}）":f['force_id'] for f in self.doc['entities']['lords']}
        self.player_combo.configure(values=list(self.player_options))
        if self.player_choice.get() not in self.player_options:self.player_choice.set('')
        name=next((f['name'] for f in self.doc['entities']['lords'] if f['force_id']==pid),'未确认')
        source={'user_confirmed':'手动确认','screenshot_verified':'截图核对','game_player_context':'自动识别'}.get(meta.get('source'),'未确认')
        self.identity_label.config(text=f"我方：{name} · {source}" + (' · 持续跟随游戏' if meta.get('source')=='game_player_context' else ' · 识别不足时可手动确认'))
        forces=self.doc['entities']['lords']; ids=[str(f['force_id']) for f in forces]
        if self.sel not in [f['force_id'] for f in forces]:self.sel=forces[0]['force_id'] if forces else None
        for iid in self.force_tree.get_children():
            if iid not in ids:self.force_tree.delete(iid)
        from force_strength import format_average, top_five_stat_average
        for f in sorted(forces,key=lambda f:(f['force_id']!=player_id(self.doc),f['force_id'])):
            iid=str(f['force_id']);data=intelligence_rows(self.doc,f['force_id'])
            vals=(('★' if f['force_id']==player_id(self.doc) else '◆')+(f.get('name') or '?'),fmt_num(f.get('prestige')),len(data['officers']),len(data['force_units']),format_average(top_five_stat_average(data['officers'])))
            tags=('player',) if f['force_id']==player_id(self.doc) else ('war',) if at_war(self.doc,f['force_id']) else ('ally',) if allied(self.doc,f['force_id']) else ('unknown',)
            if self.force_tree.exists(iid):self.force_tree.item(iid,values=vals,tags=tags)
            else:self.force_tree.insert('','end',iid=iid,values=vals,tags=tags)
        regroup_forces(self.force_tree,self.doc)
        if self.sel is not None:self.force_tree.selection_set(str(self.sel))
        self.coverage.config(text=f"已读 {len(forces)}势力 / {len(self.doc['entities']['generals'])}武将；状态/所在地为静态解析，部队待实战验证")
        city_names=sorted(set(c['name'] for c in self.doc['entities']['cities_and_barriers'] if c.get('name')))
        self.city_combo.configure(values=['全部城市']+city_names)
        self.refresh_force_art()
        self.render_detail()

    def show_combat(self):
        if not self.doc:return
        from military_summary import troop_info
        window=tk.Toplevel(self.root);window.title('兵力 / 武将对比 · 不等同伤害或胜率');window.geometry('800x610')
        self.combat_windows=[w for w in self.combat_windows if w.winfo_exists()]+[window]
        text=tk.Text(window,wrap='word',font=('Microsoft YaHei',11),bg=WELL,padx=16,pady=14);text.pack(fill='both',expand=True)
        force_ids=comparison_ids(self.doc,self.sel)
        for fid in force_ids:
            d=intelligence_rows(self.doc,fid);f=d['force']
            text.insert('end',f['name']+' · 当前势力库存\n')
            for key in ('infantry','cavalry','bow'):
                info=troop_info(key,f['armament_raw'][key]);text.insert('end',f"  {info['name']}：{f['troop_stock'][key]:,} 兵，训练 {info['training']} / 100\n")
            officers=sorted(d['officers'],key=lambda g:g['attributes']['lead'],reverse=True)[:3]
            text.insert('end','  统率最高的三名归属武将（不代表已编入同一部队）：\n')
            for g in officers:
                a=g['attributes'];text.insert('end',f"    {g.get('name','?')}：统 {a['lead']} / 武 {a['war']} / 智 {a['intel']}，个人兵力 {g['soldiers']:,}\n")
            text.insert('end','\n')
        text.insert('end','怎样判断优势\n先比较实际交战部队的兵种、可投入兵力和所编武将，再检查训练、地形与其他战斗修正。势力库存不能当成已经出征的兵力，最强三将也不能当作实际阵容。\n\n已确认的显示规则\n0–99 为基础兵种；100–199 为第二级；200–300 为第三级。训练进度取余数，300 显示100。204 是重装步兵、训练4；它不是204点伤害，也不意味着比原值105强约两倍。\n\n当前计算边界\n全图部队已按实际编成将计算编组战力，再将兵种、规模及部队武装字段代入网站公式，逐队显示攻击力。编组算法来自静态复现，训练字段及网站参数映射仍待界面对照；弓兵只计远射。地形、目标防御、士气及随机项尚未纳入，因此不能把攻击力当作扣血或胜率。')
        text.config(state='disabled')

    def locate_object(self,key,record=None,*,prefer_world=False):
        if self.rendering_tables:return
        if record is None:
            selection=self.tables[key].selection()
            if not selection:return
            record=self.row_records.get(key,{}).get(selection[0])
        if record is None:return
        if self.location_window is None or not self.location_window.winfo_exists():
            from native_city_map import CityLocator
            self.location_window=tk.Toplevel(self.root);self.location_window.title('全知情报 · 城关 / 建筑 / 部队定位')
            from tkinter import ttk
            from city_tactical import CityTactical
            self.location_window.geometry('1180x740');self.location_window.minsize(960,580)
            self.location_book=ttk.Notebook(self.location_window);self.location_book.pack(fill='both',expand=True)
            self.tactical=CityTactical(self.location_book,legacy_id=None);self.location_book.add(self.tactical,text='城周边 · 地形 / 陷阱 / 部队')
            self.object_locator=CityLocator(self.location_book);self.location_book.add(self.object_locator,text='全图定位')
        self.object_locator.update_state(self.doc)
        kind={'cities':'cities_and_barriers','buildings':'production_buildings','field_units':'field_units','force_units':'field_units','traps':'traps'}[key]
        self.object_locator.focus_entity(kind,record)
        if key=='cities':
            self.tactical.focus(self.doc,record);self.location_book.tab(self.tactical,text='城周边 · 地形 / 陷阱 / 部队');self.location_book.select(self.tactical)
        elif key in ('field_units','force_units'):
            self.tactical.focus_unit(self.doc,record);self.location_book.tab(self.tactical,text='部队周边 · 地形 / 陷阱 / 部队');self.location_book.select(self.tactical)
        else:self.location_book.select(self.object_locator)
        if prefer_world:self.location_book.select(self.object_locator)
        self.location_window.deiconify();self.location_window.lift()

    def locate_wild(self,_=None):
        if self.rendering_tables:return
        selection=self.tables['wild'].selection()
        if not selection:return
        officer=self.row_records.get('wild',{}).get(selection[0])
        if officer:
            self.city_locator.focus_officer(officer)
            popup=getattr(self,'wild_map_window',None)
            if popup is None or not popup.winfo_exists():
                from native_city_map import CityLocator
                self.wild_map_window=tk.Toplevel(self.root);self.wild_map_window.title('在野人才 · 城池定位')
                self.wild_map_window.geometry('740x570');self.wild_map_window.minsize(540,420)
                self.wild_map_window.protocol('WM_DELETE_WINDOW',self.wild_map_window.withdraw)
                self.wild_popup_locator=CityLocator(self.wild_map_window);self.wild_popup_locator.pack(fill='both',expand=True)
            self.wild_popup_locator.update_state(self.doc);self.wild_popup_locator.focus_officer(officer)
            self.wild_map_window.deiconify();self.wild_map_window.lift()

    def render_detail(self):
        if not self.doc:return
        d=intelligence_rows(self.doc,self.sel);f=d['force']
        if not f:return
        choices=[f"{x['name']} #{x['force_id']}" for x in self.doc['entities']['lords']]
        for var,combo in self.top_force_selectors:combo.configure(values=choices);var.set(f"{f['name']} #{f['force_id']}")
        kind='我军' if self.sel==player_id(self.doc) else '其他势力' if player_id(self.doc) is not None else '我方未确认'
        self.heading.config(text=f"{f.get('name') or '?'}　{kind}")
        self.summary.config(text=f"君主：{d['ruler'] or '未解码'}　首都：{d['capital'] or '未解码'}　城关 {len(d['cities'])}　归属武将 {len(d['officers'])}　部队 {len(d['force_units'])}")
        t=f['troop_stock'];a=f['armament_raw']
        self.resources.config(text=f"金 {fmt_num(f['gold'])}　　米 {fmt_num(f['rice'])}　　信望 {f['prestige']}")
        self.military.update_force(f,self.doc)
        self.quarter_ops.update_force(f,self.doc)
        self.diplomacy_cards.update_force(f)
        self.projection.config(text='')
        p=local_projection(self.doc,self.sel)
        if p is not None:
            different=[]
            for key,label in [('gold','金'),('rice','米')]:
                if p.get(key)!=f.get(key):different.append(label+' '+fmt_num(p.get(key)))
            for key,label in [('infantry','步'),('cavalry','骑'),('bow','弓')]:
                v=p.get('training_progress',{}).get(key)
                if v!=f.get('training_progress',{}).get(key):different.append(label+'训练 '+fmt_num(v))
            if different:self.projection.config(text='同一势力操作层与核心层差异：'+' · '.join(different))
        from trap_state import trap_status
        self.trap_info.config(text=trap_status(self.doc))
        d['traps']=[t for t in self.doc['entities'].get('traps',[]) if t.get('owner_raw')==self.sel]
        d['cards']=f.get('hand_cards',{}).get('slots',[])
        ranked=self.talent_filters.rank(self.doc);rank_scores={id(item['officer']):item['score'] for item in ranked}
        d['wild']=[item['officer'] for item in ranked]
        visible=[c for c in self.tables['wild']['columns'] if c not in ('ref_total','ref_match','rank_score')]
        self.tables['wild'].configure(displaycolumns=visible)
        d['all_officers']=self.doc['entities']['generals']
        from unit_combat import enrich_unit_combat
        enrich_unit_combat(self.doc)
        from unit_proximity import annotate, player_id as proximity_player_id, COLORS, sort_key
        all_units=annotate(self.doc,legacy_id=None)
        my_force=proximity_player_id(self.doc,legacy_id=None)
        d['field_units']=sorted(all_units,key=sort_key)
        d['force_units']=[u for u in d['field_units'] if u.get('owner_raw')==self.sel]
        for key in ('field_units','force_units'):
            for band,color in COLORS.items():self.tables[key].tag_configure('unit_'+band,background=color)
        self.tables['field_units'].tag_configure(WAR_UNIT_TAG,foreground=WAR_UNIT_FOREGROUND)
        history=self.doc.get('history',{})
        if getattr(self,'change_info',None) is not None:
            self.change_info.config(text=history.get('digest') or history.get('banner') or '尚无建营、训练、录用或部队移动，变化页先不显示。')
        if self.net_only.get():
            rows=list(history.get('quarter_rows') or [])
        else:
            rows=[c for c in (history.get('recent_changes') or []) if c.get('line')]
            if not rows:
                rows=list(history.get('quarter_rows') or [])
        if self.hide_flat.get():
            rows=[c for c in rows if not c.get('flat')]
        if self.changes_one_force.get():
            rows=[c for c in rows if c.get('owner')==self.sel]
        d['changes']=rows
        force_names={f['force_id']:f['name'] for f in self.doc['entities']['lords']}
        generals_by_id={}
        for g in self.doc['entities']['generals']:generals_by_id.setdefault(g['general_id_raw'],[]).append(g)
        titles={'force_units':'部队','traps':'陷阱（已读）','cards':'手牌','officers':'所属将','all_officers':'全武将','cities':'城关','buildings':'建筑','wild':'在野人才','field_units':'全图部队 · 红≤5/黄≤10格','changes':'变化'}
        query=self.filter.get().strip().lower();kindmap={'city':'城市','barrier':'关隘','parade_ground':'练兵所','horse_farm':'牧场','bow_studio':'弓工坊'}
        self.city_locator.update_state(self.doc)
        if getattr(self,'wild_map_window',None) is not None and self.wild_map_window.winfo_exists():self.wild_popup_locator.update_state(self.doc)
        if self.location_window is not None and self.location_window.winfo_exists():
            self.object_locator.update_state(self.doc);self.tactical.update_state(self.doc)
        from officer_sortie import officer_cells, kind_skill_flags
        self.rendering_tables=True
        for key in self.tables:
            query=(self.page_filters[key].get() if key in self.page_filters else self.global_filter.get() if key in ('all_officers','wild') else self.filter.get()).strip().lower()
            self.row_records[key]={}
            tree=self.tables[key];ys=tree.yview();xs=tree.xview();tree.delete(*tree.get_children());matched=0
            if key=='officers':
                self._clear_officer_skill_hl();self.officer_skill_flags={}
            for row_index,r in enumerate(d[key]):
                xy=','.join(map(str,r.get('world_xy_raw',[])))
                if key=='officers':
                    from officer_reference import officer_metrics
                    skills=officer_metrics(r)
                    preview=officer_cells(r,f,self.doc)
                    vals=(r['general_id_raw'],r.get('name') or '姓名未解码',skills['skills'],fmt_num(r['soldiers']),preview['infantry'],preview['cavalry'],preview['bow'],*[r['attributes'][a] for a in ['lead','war','intel','pol','cha']])
                    self.officer_skill_flags[str(row_index)]=kind_skill_flags(r)
                elif key=='cities':vals=(r.get('name') or '?',kindmap[r['type']],'/'.join(map(str,r['defense'])),fmt_num(r.get('population')),fmt_num(r.get('development')),fmt_num(r.get('commerce')),xy)
                elif key=='traps':vals=(r['trap_id'],r['trap_kind'],xy,force_names.get(r['owner_raw'],'无主'),'类型/容器静态确认；实景对照待完成')
                elif key=='buildings':vals=(kindmap[r['type']],r.get('object_id_candidate'),xy)
                elif key in ('wild','all_officers'):
                    from officer_reference import eligible_wild
                    if key=='wild' and not eligible_wild(r):continue
                    if key=='wild' and self.city_filter.get()!='全部城市' and r.get('location_city_name')!=self.city_filter.get():continue
                    attrs=[r['attributes'][a] for a in ['lead','war','intel','pol','cha']]
                    if key=='wild':vals=(r.get('location_city_name') or '城市未解析',r.get('name') or '姓名未解码',r['general_id_raw'],*attrs)
                    else:vals=(r['general_id_raw'],r.get('name') or '姓名未解码',force_names.get(r['owner_raw'],'无归属'),r.get('status_label','未解析'),r.get('location_city_name') or '未解析',*attrs)
                    from officer_reference import cells
                    vals=(*vals,*cells(r))
                elif key=='cards':vals=(r['slot'],r['name'],r['card_id'],{'known':'已识别','empty':'空槽','unknown':'待识别'}[r['status']])
                elif key in ('field_units','force_units'):
                    gs=[]
                    for gid in r.get('general_ids',[]):
                        if gid is None:continue
                        found=generals_by_id.get(gid,[]);gs.append((found[0].get('name') or '?') if len(found)==1 else f'ID{gid}待核验')
                    from unit_memory import attack_label, rice_label
                    vals=(r['unit_id'],r['unit_kind'],xy,' / '.join(gs),fmt_num(r.get('soldiers_candidate')),rice_label(r),fmt_num(r.get('basic_combat_power')),fmt_num(r.get('morale')),attack_label(r),r.get('target_attack_building','缺参数'),r.get('unit_skills_reference','未匹配'),r.get('size_label','未知'),force_names.get(r.get('owner_raw'),'未知势力'),r.get('proximity_label','距离未知'),r.get('target_attack_note') or '；'.join(r.get('combat_missing',[])))
                else:
                    display=lambda v:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else str(v)
                    stamp=r.get('when') or (r.get('time') or history.get('recording_since') or '')[:19]
                    if r.get('line'):
                        vals=(stamp,r.get('name') or '',r['line'])
                    else:
                        vals=(stamp,r.get('name') or '',r.get('field') or display(r.get('after')))
                if key=='cities':
                    from tutorial_rules import city_economy
                    from recruitment_summary import population_cap
                    er=city_economy(r,f) if r.get('type')=='city' else None
                    from city_tactical import city_alert
                    cap=(r.get('recruitment_capacity') or {}).get('population_cap')
                    if cap is None and r.get('type')=='city':cap=population_cap(r.get('population'))
                    cap_text='—' if r.get('type')!='city' else (f'{cap:,}' if type(cap) is int else '未采集')
                    vals=(*vals,city_alert(self.doc,r)[0],*(round(er[k],1) if er else '—' for k in ('gold','rice')),cap_text)
                elif key in ('field_units','force_units'):
                    from tutorial_rules import unit_rule_hint
                    from attack_reference import attack_reference
                    vals=(*vals,*attack_reference(r),unit_rule_hint(self.doc,r))
                elif key=='wild':
                    cid=r.get('location_city_id')
                    crowd=sum(g.get('status_code')==1 and g.get('owner_raw')==65535 and g.get('location_city_id')==cid for g in self.doc['entities']['generals']) if cid is not None else '未知'
                    valid_city=sum(c.get('city_id')==cid for c in self.doc['entities'].get('cities_and_barriers',[]))==1 if cid is not None else False
                    share=f'{100/crowd:.1f}%' if valid_city and type(crowd) is int and crowd>0 else '未知'
                    vals=(*vals[:8],crowd,share,*vals[8:],fmt_num(rank_scores.get(id(r))))
                if query and not any(query in str(v).lower() for v in vals):continue
                tags=unit_row_tags(self.doc,r,key,'unit_'+r.get('proximity_band','unknown')) if key in ('field_units','force_units') else (('city_trapped',) if key=='cities' and city_alert(self.doc,r)[1] else ())
                tree.insert('','end',iid=str(row_index),values=vals,tags=tags);self.row_records[key][str(row_index)]=r;matched+=1
            tree.yview_moveto(ys[0] if ys else 0);tree.xview_moveto(xs[0] if xs else 0)
            if tree in self.sorts:
                sort_key,reverse=self.sorts[tree]
                def sort_value(iid):
                    val=tree.set(iid,sort_key)
                    try:return (0,float(val.replace(',','').rstrip('%').removeprefix('≈')))
                    except ValueError:return (1,val)
                for ix,iid in enumerate(sorted(tree.get_children(),key=sort_value,reverse=reverse)):tree.move(iid,'',ix)
            label=titles[key]+f' ({matched})'
            if key=='cards':label='手牌 · '+(str(f['hand_cards']['occupied_count'])+' 张' if 'hand_cards' in f else '读取不可用')
            if key=='field_units' and not matched:label='部队（未观察到）'
            if self.table_books[key] is self.workspace:
                label={'field_units':'全图部队','changes':f'变化 ({matched})','traps':'陷阱'}.get(key,label)
            elif self.table_books[key] is self.book:
                label={'officers':f'所属将 ({matched})','cities':f'城关 ({matched})','force_units':f'部队 ({matched})'}.get(key,label)
            elif self.table_books[key] is self.global_book:
                label={'all_officers':f'全武将 ({matched})','wild':f'在野 ({matched})'}.get(key,label)
            self.table_books[key].tab(self.frames[key],text=label)
            if key=='changes':
                book=self.table_books[key];frame=self.frames[key]
                if history.get('quarter_rows'):
                    book.tab(frame,state='normal')
                else:
                    try:
                        current=book.select()
                    except tk.TclError:
                        current=''
                    if current==str(frame):
                        book.select(self.force_page)
                    book.tab(frame,state='hidden')
        self.rendering_tables=False
        self._schedule_officer_skill_hl()
        self.city_talent.refresh()
        self.nearby_intel.refresh()
        self.world_cities.refresh()
        self.decision_panel.refresh()
        self.rules_panel.refresh()
        self.battles.refresh()
        self.preparation.refresh()
        self.refresh_panorama()

    def _on_workspace_tab(self, _=None):
        self.refresh_panorama(force=True)

    def refresh_panorama(self, force=False):
        try:
            if self.workspace.select() != str(self.panorama):
                return
        except tk.TclError:
            return
        sig = None if not self.doc else (self.doc.get('snapshot_id'), self.doc.get('capture_end'))
        if not force and sig == self._panorama_sig:
            return
        self._panorama_sig = sig
        self.panorama.update_state(self.doc)
        from battle_model import freshness
        self.panorama.status.set(freshness(self.doc) if self.doc else '等待采集')


def main():
    root=tk.Tk()
    from dock_icon import apply as apply_dock_icon
    apply_dock_icon(root,'hub')
    root.geometry('1060x760+30+40')
    OmniWindow(root)
    root.mainloop()


if __name__ == '__main__':main()
