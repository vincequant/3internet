import importlib.util
from pathlib import Path
import struct
import sys
import unittest
import tempfile
import time
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parent))
from room_list_model import decode_room,AlertState

def record(current=1, maximum=8):
    data=bytearray(80)
    struct.pack_into('<I',data,0,123)
    data[4:8]=b'room'
    data[35:39]=b'host'
    struct.pack_into('<III',data,68,maximum,current,0)
    return bytes(data)

class RoomTests(unittest.TestCase):
    def test_record(self):
        self.assertEqual(decode_room(record())['name'],'room[host]')
        self.assertEqual(decode_room(record())['current'],1)
        self.assertEqual(decode_room(record())['maximum'],8)
    def test_invalid(self):
        for value in (b'',record(9),record(0),record(1,100)):
            with self.assertRaises(ValueError):decode_room(value)
    def test_nonterminated(self):
        data=bytearray(record());data[4:35]=b'a'*31
        with self.assertRaises(ValueError):decode_room(bytes(data))
    def test_strict_threshold(self):
        state=AlertState()
        self.assertEqual(state.update({'status':'fresh','rooms':[decode_room(record(4))]}),[])
        self.assertEqual(len(state.update({'status':'fresh','rooms':[decode_room(record(5))]})),1)
    def test_cached_never_alerts(self):
        self.assertEqual(AlertState().update({'status':'cached','rooms':[decode_room(record(8))]}),[])
    def test_no_duplicate_and_rearm(self):
        state=AlertState();high={'status':'fresh','rooms':[decode_room(record(5))]}
        self.assertEqual(len(state.update(high,now=0)),1)
        self.assertEqual(state.update(high,now=20),[])
        self.assertEqual(state.update({'status':'unavailable','rooms':[]}),[])
        self.assertEqual(state.update(high,now=30),[])
        state.update({'status':'fresh','rooms':[decode_room(record(4))]})
        self.assertEqual(state.update(high,now=59),[])
        self.assertEqual(len(state.update(high,now=60)),1)
    def test_unknown_is_not_zero(self):
        self.assertEqual(AlertState().update({'status':'unavailable','rooms':[]}),[])
    def test_windows_command(self):
        path=Path(__file__).resolve().parents[1]/'app/room_watch.py'
        sys.path.insert(0,str(path.parent))
        spec=importlib.util.spec_from_file_location('room_watch_test',path)
        app=importlib.util.module_from_spec(spec);spec.loader.exec_module(app)
        with patch.object(sys,'platform','win32'):
            cmd,env=app.command(True)
        self.assertEqual(cmd[-1],'--refresh')
        self.assertTrue(any('room_list_reader.py' in x for x in cmd))
        self.assertFalse(any('wine' in x.lower() for x in cmd))
    def test_native_probe_read_only_cache(self):
        # Live refresh is a separate opt-in flag, never part of a cached read.
        source=(Path(__file__).parent/'room_list_reader.py').read_text()
        for forbidden in ('WriteProcessMemory','VirtualAllocEx','CreateRemoteThread','TerminateProcess',
                          'SendInput','mouse_event','keybd_event','SetForegroundWindow','BringWindowToTop',
                          'LVM_GETITEMTEXT','AccessibleObjectFromWindow'):
            self.assertNotIn(forbidden,source)
        self.assertIn("click(hwnd,pid,TITLE,1006,'刷新列表(&S)',allow_hidden=quiet)",source)
        self.assertIn("click(dialog,pid,CONFIRM,1,'确定',allow_hidden=quiet)",source)
        self.assertIn('SW_HIDE',source)
        self.assertNotIn('SW_SHOWMAXIMIZED',source)
        self.assertNotIn('def hide_pid',source)
        self.assertIn('hide_wait_windows',source)
        self.assertIn('WAIT_TITLES',source)
        self.assertIn('NetHookCoreWindow2012',source)
        self.assertGreaterEqual(source.count('hide_wait_windows(pid)'),2)
        self.assertNotIn('DestroyWindow',source)
        self.assertNotIn('elif quiet:hide_pid',source)
        self.assertEqual(source.count("click(hwnd,pid,TITLE,1006"),1)
        self.assertNotIn("click(hwnd,pid,TITLE,1024",source)
        self.assertIn('已离开游戏选择，观察已暂停',source)
        self.assertNotIn("click(hwnd,pid,TITLE,1005",source)

    def test_configurable_repeat(self):
        state=AlertState(6,2)
        value={'status':'fresh','rooms':[decode_room(record(6))]}
        self.assertFalse(state.update(value,now=0))
        value['rooms']=[decode_room(record(7))]
        self.assertEqual(len(state.update(value,now=1)),1)
        self.assertFalse(state.update(value,now=120))
        self.assertEqual(len(state.update(value,now=121)),1)

    def test_multiple_rooms_shared_interval(self):
        state=AlertState(4,1);r=decode_room(record(5))
        value={'status':'fresh','rooms':[r]}
        self.assertTrue(state.update(value,now=0))
        value['rooms'].append(dict(r,id='other'))
        self.assertFalse(state.update(value,now=10))
        self.assertEqual(len(state.update(value,now=60)),2)

    def test_muted_and_stale_never_alert(self):
        state=AlertState();value={'status':'fresh','rooms':[decode_room(record(5))]}
        self.assertFalse(state.update(value,now=0,enabled=False))
        value['observed_at']=time.time()-120
        self.assertFalse(state.update(value,now=0))
        value['observed_at']=time.time()
        self.assertTrue(state.update(value,now=0))

    def test_settings_round_trip_and_validation(self):
        sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'))
        from room_watch_settings import load,save
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'room-watch.local.json'
            self.assertEqual(load(path),(4,1))
            save(path,6,2.5);self.assertEqual(load(path),(6,2.5))
            for x,y in [('abc',1),(4,0),(4,-1),(4,'nan'),(4,'inf'),(4.5,1),(64,1)]:
                with self.assertRaises(ValueError):save(path,x,y)
            self.assertEqual(load(path),(6,2.5))

    def test_settings_not_published(self):
        sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
        from publish import allowed
        self.assertFalse(allowed('room-watch.local.json'))
        self.assertTrue(allowed('Start-Room-Watch.command'))
        self.assertTrue(allowed('Start-Room-Watch.cmd'))
        self.assertTrue(allowed('Start-Quiet-Wait.command'))
        self.assertTrue(allowed('Start-Quiet-Wait.cmd'))
        self.assertTrue(allowed('app/quiet_wait_launch.py'))

    def test_settings_preserve_audio_original(self):
        sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'))
        from room_watch_settings import load,save,update,read_file
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'room-watch.local.json'
            update(path,audio_original=1)
            save(path,5,3)
            self.assertEqual(load(path),(5,3))
            self.assertEqual(read_file(path)['audio_original'],1)

    def test_audio_restore_does_not_guess(self):
        sys.path.insert(0,str(Path(__file__).resolve().parent))
        from room_watch_audio import read_play_bgm, write_play_bgm
        text=';背景音乐开关，0=关闭，1=打开\r\nPlayBGM=1\r\nPlaySE=1\r\n'
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'Setting.ini'
            path.write_bytes(text.encode('gbk'))
            self.assertEqual(read_play_bgm(path)[0],1)
            write_play_bgm(path,0)
            self.assertEqual(read_play_bgm(path)[0],0)
            write_play_bgm(path,1)
            raw=path.read_bytes()
            self.assertEqual(raw.decode('gbk').count('PlayBGM=1'),1)
            self.assertIn('PlaySE=1',raw.decode('gbk'))
            self.assertIn('背景音乐',raw.decode('gbk'))

    def test_quiet_and_reveal_flags(self):
        path=Path(__file__).resolve().parents[1]/'app/room_watch.py'
        sys.path.insert(0,str(path.parent))
        spec=importlib.util.spec_from_file_location('room_watch_flags',path)
        app=importlib.util.module_from_spec(spec);spec.loader.exec_module(app)
        with patch.object(sys,'platform','win32'):
            quiet,_=app.command(True,quiet=True)
            reveal,_=app.command(False,reveal=True)
            cache,_=app.command(False)
        self.assertIn('--refresh',quiet)
        self.assertIn('--quiet',quiet)
        self.assertIn('--reveal',reveal)
        self.assertNotIn('--refresh',reveal)
        self.assertTrue(str(cache[-1]).endswith('room_list_reader.py'))
        self.assertNotIn('--quiet',cache)

    def test_alert_uses_host_sound_not_game_ini(self):
        path=Path(__file__).resolve().parents[1]/'app/room_watch.py'
        source=path.read_text(encoding='utf-8')
        self.assertIn('afplay',source)
        self.assertIn('Ping.aiff',source)
        self.assertIn('mute_bgm',source)
        self.assertIn('只阻止下一首',source)
        self.assertNotIn('WriteProcessMemory',source)

    def test_launchers_do_not_autowatch(self):
        root=Path(__file__).resolve().parents[1]
        hub=(root/'app/mac_main.py').read_text(encoding='utf-8')
        self.assertIn("room_watch.py')])",hub.replace('"', "'"))
        self.assertNotIn('--watch',hub)
        launcher=(root/'Start-Room-Watch.command').read_text(encoding='utf-8')
        self.assertIn('exec "$PY" -B app/room_watch.py',launcher)
        self.assertNotIn('room_watch.py --watch',launcher)
        win=(root/'Start-Room-Watch.cmd').read_text(encoding='utf-8')
        self.assertNotIn('--watch',win)
        quiet=(root/'Start-Quiet-Wait.command').read_text(encoding='utf-8')
        self.assertIn('quiet_wait_launch.py',quiet)
        self.assertNotIn('room_watch.py --watch',quiet)
        self.assertIn('安静等待',hub)
        self.assertNotIn('WriteProcessMemory',(root/'app/quiet_wait_launch.py').read_text(encoding='utf-8'))

    def test_command_is_game_ignores_helpers(self):
        from room_watch_audio import command_is_game
        self.assertTrue(command_is_game('./3I\\SANPK.exe /1an','SANPK.exe'))
        self.assertTrue(command_is_game('/Users/x/drive_c/sgi/run-3.5/SANGUO.exe','SANGUO.exe'))
        self.assertTrue(command_is_game('/Users/vk/Library/Application Support/SGI-Wine/prefix/drive_c/sgi/run-3.5/SANGUO.exe','SANGUO.exe'))
        self.assertFalse(command_is_game('python.exe Z:\\\\scripts\\\\sgi_wine_process_watch.py C:\\\\sgi\\\\run-3.5\\\\3I\\\\SANPK.exe','SANPK.exe'))
        self.assertFalse(command_is_game('python3 -B app/room_watch.py --watch','SANPK.exe'))

    def test_quiet_wait_plan_does_not_touch_running_game(self):
        sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'))
        from quiet_wait_launch import plan
        blocked=plan({'sanpk':True,'lobby':True},platform='darwin')
        self.assertFalse(blocked['prepare'])
        self.assertFalse(blocked['launch_lobby'])
        self.assertEqual(blocked['mode'],'observe_existing')
        ready=plan({'sanpk':False,'lobby':False},platform='darwin')
        self.assertTrue(ready['prepare'])
        self.assertTrue(ready['launch_lobby'])
        self.assertEqual(ready['mode'],'quiet_wait')
        windows=plan({'sanpk':False,'lobby':False},platform='win32')
        self.assertTrue(windows['prepare'])
        self.assertFalse(windows['launch_lobby'])
        lobby_only=plan({'sanpk':False,'lobby':True},platform='darwin')
        self.assertTrue(lobby_only['prepare'])
        self.assertFalse(lobby_only['launch_lobby'])

    def test_prepare_quiet_launch_saves_original(self):
        sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'))
        from quiet_wait_launch import prepare_quiet_launch
        from room_watch_settings import read_file
        from room_watch_audio import read_play_bgm
        text=';背景音乐开关，0=关闭，1=打开\r\nPlayBGM=1\r\nPlaySE=1\r\n'
        with tempfile.TemporaryDirectory() as directory:
            ini=Path(directory)/'Setting.ini'
            settings=Path(directory)/'room-watch.local.json'
            ini.write_bytes(text.encode('gbk'))
            self.assertEqual(prepare_quiet_launch(settings,ini),1)
            self.assertEqual(read_play_bgm(ini)[0],0)
            self.assertEqual(read_file(settings)['audio_original'],1)
            self.assertTrue(read_file(settings)['quiet_launch'])
            self.assertIn('PlaySE=1',ini.read_bytes().decode('gbk'))
            prepare_quiet_launch(settings,ini)
            self.assertEqual(read_file(settings)['audio_original'],1)

if __name__=='__main__':unittest.main()
