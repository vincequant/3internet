"""Panorama map: LBM/MBM layers and read-only overlay lists. No game writes."""
import json
from pathlib import Path

from tactical_terrain import world_pixel

APP = Path(__file__).resolve().parent
WORLD = (101, 202)
LBM_SIZE = (525, 350)
MBM_SIZE = (9744, 4872)
SWITCH_ZOOM = 3.0
MIN_ZOOM = 1.0
MAX_ZOOM = 12.0
DEFAULT_CENTER = (50.5, 101.0)

RESEARCH = (
    '研究结论（独立于 Hub，不连采集、不写游戏）\n'
    '\n'
    '1. Hub「全图定位」低倍仍用 SanInet.lbm（525×350）全国示意，'
    '倍率≥3 与独立全景视窗一样切 SanInet.mbm 原作地面。\n'
    '2. 原作地面已经在 SanInet.mbm（9744×4872，48×24 交错菱格）里，'
    'Hub「城周边」已经在用同一套只读贴图。那才是山、路、水、灰地的来源。\n'
    '3. 宫殿、城墙、部队立体模型不在 MBM 里，是游戏实时三维。'
    '只读贴图做不到完整「原作画质」；城标可用已有 2D 原版精灵。\n'
    '4. 可行路线：低倍看 LBM 全国，高倍按视野裁切 MBM（与城周边同一坐标）。'
    '本页是这条路线的原型：滚轮或＋－可从全国缩放到城战附近。\n'
    '5. 图上城名来自历史截图样本，不是当前对局归属。未做整张 MBM 预烘焙，也未还原三维建筑。'
)

LAYER_HINT = {
    'lbm': '战略底图 SanInet.lbm · 全国示意，再放大只会糊',
    'mbm': '原作地面 SanInet.mbm · 按视野裁切，接近城战地形',
}


def layer_for_zoom(zoom):
    return 'mbm' if float(zoom) >= SWITCH_ZOOM else 'lbm'


def clamp_zoom(zoom):
    return max(MIN_ZOOM, min(MAX_ZOOM, float(zoom)))


def clamp_center(center, world=WORLD, offset=0.5):
    x, y = center
    return (
        max(offset, min(world[0] - 1 + offset, float(x))),
        max(offset, min(world[1] - 1 + offset, float(y))),
    )


def visible_cells(zoom):
    return max(2.4, 28.0 / clamp_zoom(zoom))


def mbm_view(center, zoom, view_w, view_h):
    """Return (pixel_box, scale) for a viewport crop of SanInet.mbm."""
    cx, cy = world_pixel(*center)
    cells = visible_cells(zoom)
    width = max(1, int(view_w))
    height = max(1, int(view_h))
    scale = width / (96 * cells)
    left = int(cx - width / scale / 2)
    top = int(cy - height / scale / 2)
    box = (left, top, left + int(width / scale) + 1, top + int(height / scale) + 1)
    return box, scale


def catalog_cities(palette=None):
    """Unique city positions from the historical screenshot palette. Not live ownership."""
    if palette is None:
        palette = json.loads((APP / 'game_palette.json').read_text(encoding='utf-8'))
    cities = {}
    for entry in palette.get('colors', {}).values():
        for sample in entry.get('samples', []):
            cid = sample.get('city_id')
            xy = sample.get('world_xy')
            name = sample.get('city_name')
            if type(cid) is not int or not isinstance(xy, (list, tuple)) or len(xy) != 2:
                continue
            if not all(type(v) in (int, float) for v in xy):
                continue
            if not (0 <= xy[0] < WORLD[0] and 0 <= xy[1] < WORLD[1]):
                continue
            cities[cid] = {'city_id': cid, 'name': name or f'#{cid}', 'world_xy': (int(xy[0]), int(xy[1]))}
    return sorted(cities.values(), key=lambda row: row['city_id'])


def world_xy(row, world=WORLD):
    point = row.get('world_xy_raw')
    if not isinstance(point, (list, tuple)) or len(point) != 2:
        return None
    if not all(type(value) is int for value in point):
        return None
    if not (0 <= point[0] < world[0] and 0 <= point[1] < world[1]):
        return None
    return (point[0], point[1])


def object_key(kind, row):
    field = {'城关': 'city_id', '建筑': 'object_id_candidate', '陷阱': 'trap_id', '部队': 'unit_id'}[kind]
    return (kind, row.get('type'), row.get(field))


def live_objects(state):
    if not state:
        return []
    entities = state.get('entities') or {}
    rows = []
    for kind, source in (
        ('城关', 'cities_and_barriers'),
        ('建筑', 'production_buildings'),
        ('陷阱', 'traps'),
        ('部队', 'field_units'),
    ):
        for row in entities.get(source) or []:
            if world_xy(row):
                rows.append((kind, row))
    return rows


def box_from_corners(points):
    xs = [point[0] for point in points]
    ys = [point[1] for point in points]
    return (min(xs), min(ys), max(xs), max(ys))


def in_world_box(xy, box, pad=0.55):
    if not xy or not box or len(box) != 4:
        return False
    x, y = xy[0] + 0.5, xy[1] + 0.5
    return box[0] - pad <= x <= box[2] + pad and box[1] - pad <= y <= box[3] + pad


def units_in_view(state, box, war_only=False):
    rows = []
    for kind, row in live_objects(state):
        if kind != '部队' or not show_overlay(state, kind, row, war_only):
            continue
        if in_world_box(world_xy(row), box):
            rows.append(row)
    return rows


def sort_view_units(state, rows, center):
    from force_relations import at_war
    from player_view import player_id
    own = player_id(state)
    cx, cy = center if center else DEFAULT_CENTER

    def key(row):
        xy = world_xy(row) or (0, 0)
        owner = row.get('owner_raw')
        rank = 0 if owner == own else 1 if at_war(state, owner) else 2
        return (rank, (xy[0] + 0.5 - cx) ** 2 + (xy[1] + 0.5 - cy) ** 2, row.get('unit_id') or 0)

    return sorted(rows, key=key)


def view_unit_line(state, row):
    names = {force.get('force_id'): force.get('name') or '?'
             for force in (state or {}).get('entities', {}).get('lords') or []}
    owner = names.get(row.get('owner_raw'), '?')
    soldiers = row.get('soldiers_candidate')
    troop = f'{soldiers:,}' if type(soldiers) is int else '?'
    return f"{owner} · {object_label(state, '部队', row)} · 兵{troop}"


def show_overlay(state, kind, row, war_only):
    if not war_only:
        return True
    from force_relations import at_war
    from player_view import player_id
    owner = row.get('owner_raw')
    own = player_id(state)
    return owner == own or at_war(state, owner)


def opponent_brief(state):
    if not state:
        return '尚无采集。进入对局后叠城关、建筑、部队、陷阱。'
    from force_relations import at_war
    from player_view import player_id
    if player_id(state) is None:
        return '我方身份未确认，交战高亮暂不可用。已采集对象仍会叠在图上。'
    wars = [force for force in state.get('entities', {}).get('lords', []) if at_war(state, force.get('force_id'))]
    units = [row for kind, row in live_objects(state) if kind == '部队' and at_war(state, row.get('owner_raw'))]
    cities = [row for kind, row in live_objects(state) if kind == '城关' and at_war(state, row.get('owner_raw'))]
    if not wars:
        return '当前没有标记为「与我军战争」的势力。图上仍显示全部已采集对象。'
    names = '、'.join(force.get('name') or f"#{force.get('force_id')}" for force in wars)
    return f'交战：{names} · 部队 {len(units)} · 城关 {len(cities)}'


def object_label(state, kind, row):
    if kind == '城关':
        return row.get('name') or f"城关 #{row.get('city_id')}"
    if kind == '建筑':
        return {'parade_ground': '练兵所', 'horse_farm': '牧场', 'bow_studio': '弓工坊'}.get(row.get('type'), '建筑')
    if kind == '陷阱':
        return row.get('trap_kind') or '陷阱'
    if kind == '部队':
        from map_unit_labels import unit_label
        return unit_label(state, row)
    return kind


CITY_VISION = 3  # 城市 3 格，与城周边 / 补给参考一致，不是已解析迷雾


def vision_cells(center, radius=CITY_VISION, world=WORLD):
    if not isinstance(center, (list, tuple)) or len(center) != 2:
        return []
    if not all(type(value) is int for value in center):
        return []
    cx, cy = center
    cells = []
    for y in range(cy - radius, cy + radius + 1):
        for x in range(cx - radius, cx + radius + 1):
            if 0 <= x < world[0] and 0 <= y < world[1] and max(abs(x - cx), abs(y - cy)) <= radius:
                cells.append((x, y))
    return cells


def cell_diamond(wx, wy):
    px, py = world_pixel(wx, wy)
    return ((px - 48, py), (px, py - 24), (px + 48, py), (px, py + 24))


def overlay_force_diamonds(image, diamonds, alpha=78):
    """Paint capital vision cells with a transparent force color. Not game fog."""
    from PIL import Image, ImageDraw
    if image is None or not diamonds:
        return image
    base = image.convert('RGBA')
    veil = Image.new('RGBA', base.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(veil)
    for item in diamonds:
        points = item.get('points') or ()
        rgb = item.get('rgb')
        if len(points) < 3 or not isinstance(rgb, (list, tuple)) or len(rgb) != 3:
            continue
        if any(type(value) is not int or not 0 <= value <= 255 for value in rgb):
            continue
        xy = [(int(round(x)), int(round(y))) for x, y in points]
        fill_a = min(170, alpha + (36 if item.get('center') else 0))
        draw.polygon(xy, fill=(*rgb, fill_a), outline=(*rgb, min(210, fill_a + 60)))
    return Image.alpha_composite(base, veil)


def sprite_size(kind, zoom, scale=None):
    city = kind in ('城关', 'city', 'cities_and_barriers', 'barrier')
    if float(zoom) < SWITCH_ZOOM or scale is None:
        return 22 if city else 16
    frac = 0.82 if city else 0.62
    return max(28, min(120, int(96 * float(scale) * frac)))


def nearest_city(point, cities, max_cells=1.6):
    x, y = point
    best = None
    best_d = max_cells
    for city in cities:
        cx, cy = city['world_xy']
        distance = max(abs(cx + 0.5 - x), abs(cy + 0.5 - y))
        if distance <= best_d:
            best, best_d = city, distance
    return best


def assigned_owner(owner):
    return type(owner) is int and 0 <= owner < 22


def city_sites(state, world=WORLD):
    rows = []
    if not state:
        return rows
    for row in (state.get('entities') or {}).get('cities_and_barriers') or []:
        if type(row.get('city_id')) is not int or world_xy(row, world) is None:
            continue
        rows.append(row)
    return rows


def supply_lines(state, edges=None):
    if edges is None:
        from city_roads import load_road_edges
        edges = load_road_edges()
    cities = {row.get('city_id'): row for row in city_sites(state)}
    lines = []
    for edge in edges:
        left = cities.get(edge.get('a'))
        right = cities.get(edge.get('b'))
        path = edge.get('path')
        if left is None or right is None or not isinstance(path, list) or len(path) < 2:
            continue
        if any(not isinstance(point, (list, tuple)) or len(point) != 2 for point in path):
            continue
        owner = left.get('owner_raw')
        same = assigned_owner(owner) and owner == right.get('owner_raw')
        lines.append({
            'path': [tuple(point) for point in path],
            'a_xy': world_xy(left),
            'b_xy': world_xy(right),
            'a_id': left.get('city_id'),
            'b_id': right.get('city_id'),
            'owner_raw': owner if same else None,
            'same_owner': same,
        })
    return lines


def capital_marks(state):
    marks = []
    if not state:
        return marks
    cities = {row.get('city_id'): row for row in city_sites(state)}
    for force in (state.get('entities') or {}).get('lords') or []:
        city = cities.get(force.get('capital_city_id'))
        if city is None:
            continue
        xy = world_xy(city)
        if xy is None:
            continue
        marks.append({
            'force_id': force.get('force_id'),
            'force_name': force.get('name') or f"#{force.get('force_id')}",
            'city_id': city.get('city_id'),
            'city_name': city.get('name') or f"#{city.get('city_id')}",
            'world_xy': xy,
            'owner_raw': city.get('owner_raw'),
        })
    return marks


def is_capital(state, row):
    if type(row.get('city_id')) is not int or not state:
        return False
    return any(force.get('capital_city_id') == row.get('city_id') for force in (state.get('entities') or {}).get('lords') or [])
