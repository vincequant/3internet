"""Return focus after the observer window maps. Mac only; no Win32 foreground calls."""
import os
import re
import subprocess
import sys

PYTHON_NAMES = ('python', 'python3', 'python.app')


def parse_lsappinfo(text):
    if not text:
        return None
    pid = re.search(r'"pid"=(\d+)', text)
    if not pid:
        return None
    name = re.search(r'"(?:LSDisplayName|CFBundleName)"="([^"]*)"', text)
    bundle = re.search(r'"CFBundleIdentifier"="([^"]*)"', text)
    return {
        'pid': int(pid.group(1)),
        'name': name.group(1) if name else '',
        'bundle': bundle.group(1) if bundle else '',
    }


def capture_frontmost():
    if sys.platform != 'darwin':
        return None
    try:
        front = subprocess.check_output(['lsappinfo', 'front'], text=True, timeout=2).strip()
        info = subprocess.check_output(
            ['lsappinfo', 'info', '-only', 'name,pid,bundleid', front],
            text=True, timeout=2)
        return parse_lsappinfo(info)
    except Exception:
        return None


def is_python_front(info, self_pid=None):
    if not info:
        return False
    self_pid = os.getpid() if self_pid is None else self_pid
    if info.get('pid') == self_pid:
        return True
    return info.get('name', '').lower() in PYTHON_NAMES


def restore_frontmost(saved, current=None, self_pid=None):
    if sys.platform != 'darwin' or not saved:
        return False
    self_pid = os.getpid() if self_pid is None else self_pid
    if saved.get('pid') == self_pid or is_python_front(saved, self_pid):
        return False
    current = capture_frontmost() if current is None else current
    if not is_python_front(current, self_pid):
        return False
    try:
        if saved.get('bundle'):
            subprocess.run(['open', '-b', saved['bundle']], check=True, timeout=3,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
        if saved.get('name'):
            subprocess.run(['open', '-a', saved['name']], check=True, timeout=3,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
    except Exception:
        return False
    return False
