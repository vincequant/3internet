import sys
import unittest
from pathlib import Path

sys.path[:0] = [str(Path(__file__).resolve().parent.parent / 'app'), str(Path(__file__).resolve().parent)]
from officer_sortie import format_preview, kind_preview, officer_cells
from test_preparation import general, state


class OfficerSortie(unittest.TestCase):
    def test_preview_uses_current_size_and_stock_cap(self):
        force = state()['entities']['lords'][0]
        g = general(1, 14000, 84, 100)
        infantry = kind_preview(g, force, 'infantry')
        self.assertEqual((infantry['size_label'], infantry['name'], infantry['factor'], infantry['power'], infantry['attack']),
                         ('小队', '步兵', 143, 92, 88))
        cavalry = kind_preview(g, force, 'cavalry')
        self.assertEqual((cavalry['soldiers'], cavalry['capped'], cavalry['name'], cavalry['factor'], cavalry['attack']),
                         (8860, True, '重装骑兵', 211, 129))
        bow = kind_preview(g, force, 'bow')
        self.assertEqual((bow['name'], bow['factor'], bow['attack']), ('强弓兵', 167, 102))
        force['troop_stock']['infantry'] = 0
        self.assertIsNone(kind_preview(g, force, 'infantry'))

    def test_mid_size_without_stock_cap(self):
        force = state()['entities']['lords'][0]
        force['troop_stock']['infantry'] = 80000
        mid = kind_preview(general(1, 25000, 84, 100), force, 'infantry')
        self.assertEqual((mid['size_label'], mid['factor'], mid['attack'], mid['capped']), ('中队', 243, 149, False))

    def test_cells_and_recommendation_text(self):
        s = state()
        g = s['entities']['generals'][0]
        cells = officer_cells(g, s['entities']['lords'][0], s)
        self.assertEqual(cells['infantry'], '88')
        self.assertEqual(cells['cavalry'], '129')
        self.assertEqual(cells['bow'], '102')
        blocked = officer_cells(g, s['entities']['lords'][0], {'build_sha256': 'other'})
        self.assertEqual(blocked, {'infantry': '—', 'cavalry': '—', 'bow': '—'})

    def test_format_marks_stock_limit(self):
        self.assertEqual(format_preview(None), '—')
        text = format_preview({'attack': 88, 'factor': 143, 'size_label': '小队', 'name': '步兵', 'capped': True})
        self.assertEqual(text, '88')
