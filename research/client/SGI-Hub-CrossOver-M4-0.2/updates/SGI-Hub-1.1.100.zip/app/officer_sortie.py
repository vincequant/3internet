"""Single-officer sortie preview from current troop size. Not engine damage."""
from preparation_model import combat_power, size_index, training_bases
from unit_target_attack import rnd, supported_combat_build

KINDS = ('infantry', 'cavalry', 'bow')
KIND_LABEL = {'infantry': '步', 'cavalry': '骑', 'bow': '弓'}
SIZES = ('小队', '中队', '大队')


def taken_soldiers(officer, force, kind):
    soldiers = (officer or {}).get('soldiers')
    if type(soldiers) is not int or soldiers <= 0:
        return None
    stock = ((force or {}).get('troop_stock') or {}).get(kind)
    if type(stock) is int:
        taken = min(soldiers, stock)
        if taken <= 0:
            return None
        return taken, soldiers, stock, stock < soldiers
    return soldiers, soldiers, None, False


def kind_preview(officer, force, kind):
    taken = taken_soldiers(officer, force, kind)
    if not taken:
        return None
    soldiers, capacity, stock, capped = taken
    power = combat_power([officer])
    bases = training_bases(kind, ((force or {}).get('armament_raw') or {}).get(kind))
    size = size_index(soldiers)
    if not bases or power is None or not 0 <= power <= 150:
        return None
    factor = bases['unit'][size]
    if factor is None:
        return None
    return {
        'kind': kind, 'name': bases['name'], 'training': bases['training'],
        'soldiers': soldiers, 'capacity': capacity, 'stock': stock,
        'size': size, 'size_label': SIZES[size], 'power': power,
        'factor': factor, 'attack': rnd(factor * power / 150), 'capped': capped,
    }


def officer_previews(officer, force, state=None):
    if state is not None and not supported_combat_build(state.get('build_sha256')):
        return {kind: None for kind in KINDS}
    return {kind: kind_preview(officer, force, kind) for kind in KINDS}


def format_preview(preview):
    if not preview or preview.get('attack') is None:
        return '—'
    return str(preview['attack'])


def officer_cells(officer, force, state=None):
    previews = officer_previews(officer, force, state)
    return {kind: format_preview(previews[kind]) for kind in KINDS}
