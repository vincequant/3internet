"""Independent maximized panorama: original terrain plus live overlays. Read-only."""
import math
import queue
import sys
import threading
import time
import tkinter as tk
from collections import defaultdict
from pathlib import Path
from tkinter import font as tkfont
from tkinter import ttk
from PIL import Image, ImageTk

from city_tactical import fmt
from dock_icon import apply as apply_dock_icon
from force_relations import at_war
from mac_light_theme import apply_light_defaults
from map_navigation import bind_arrows, bind_pointer_wheel, move_center, navigation_bar
from map_unit_labels import label_box
from unit_memory import memory_line
from native_city_map import map_viewport, state_force_rgb
from original_sprites import OriginalSprites
from city_roads import mbm_to_world, path_for_layer
from panorama_model import (
    DEFAULT_CENTER, LAYER_HINT, MIN_ZOOM, SWITCH_ZOOM, WORLD, box_from_corners, capital_marks,
    cell_diamond, clamp_center, clamp_zoom, is_capital, layer_for_zoom, live_objects,
    mbm_view, object_key, object_label, opponent_brief, overlay_force_diamonds,
    show_overlay, sort_view_units, sprite_size, supply_lines, units_in_view,
    view_unit_line, vision_cells, world_xy,
)
from player_view import player_id
from tactical_terrain import Terrain, world_pixel

APP = Path(__file__).resolve().parent
ROOT = APP.parent
BG = '#1b1d18'
INK = '#efe7cf'
MUTED = '#b7ad8f'
BAR = '#2a2c24'


def ui_font(root):
    families = set(tkfont.families(root))
    for name in ('PingFang SC', 'Hiragino Sans GB', 'Songti SC', 'STHeiti', 'Microsoft YaHei'):
        if name in families:
            return name
    return 'TkDefaultFont'


def tk_pixels(widget, value):
    """Tk 9 Canvas.cget('width') can be '10c'; winfo_fpixels converts screen units."""
    if value in (None, '', 0, '0'):
        return 0
    try:
        return max(0, int(round(float(widget.winfo_fpixels(str(value))))))
    except (tk.TclError, TypeError, ValueError, AttributeError):
        try:
            return max(0, int(round(float(str(value)))))
        except ValueError:
            return 0


def maximize(root):
    root.update_idletasks()
    try:
        root.state('zoomed')
    except tk.TclError:
        pass
    root.geometry(f'{root.winfo_screenwidth()}x{root.winfo_screenheight()}+0+0')


def acquire_lock(path=None):
    path = Path(path or ROOT / 'logs' / 'panorama.lock')
    path.parent.mkdir(exist_ok=True)
    stream = path.open('a+b')
    try:
        if sys.platform == 'win32':
            import msvcrt
            stream.seek(0)
            stream.write(b'0')
            stream.flush()
            stream.seek(0)
            msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except Exception:
        stream.close()
        return None
    return stream


class PanoramaMap(tk.Frame):
    def __init__(self, parent, title='全景视窗', detachable=False):
        super().__init__(parent, bg=BG)
        self.face = ui_font(parent.winfo_toplevel())
        self.title_text = title
        self.detachable = detachable
        self.zoom = 6.0
        self.center = DEFAULT_CENTER
        self.state = None
        self.lbm = None
        self.terrain = None
        self.terrain_error = ''
        self.photo = None
        self.selected = None
        self.hits = []
        self.drag = None
        self.layers = {name: tk.BooleanVar(value=True) for name in ('补给线', '首都', '城关', '建筑', '部队', '陷阱', '文字')}
        self.war_only = tk.BooleanVar(value=False)
        self.status = tk.StringVar(value='正在连接只读采集…')
        self.brief = tk.StringVar(value=opponent_brief(None))
        self.detail = tk.StringVar(value='点图上的城关、建筑、部队或陷阱查看对手状态。')
        self._load_assets()
        self._build()
        self.sprites = OriginalSprites(self.canvas)
        self.canvas.bind('<Configure>', lambda _: self.draw())
        bind_pointer_wheel(self.canvas, self._wheel)
        bind_pointer_wheel(self, self._wheel)
        self.canvas.bind('<ButtonPress-1>', self._press)
        self.canvas.bind('<B1-Motion>', self._drag)
        self.canvas.bind('<ButtonRelease-1>', self._release)
        bind_arrows(self.canvas, self.pan)
        bind_arrows(self, self.pan)
        self.after(80, self.draw)

    def open_detached(self):
        from wine_nav import open_panorama
        open_panorama(self.center, self.zoom if self.zoom >= SWITCH_ZOOM else 6.)

    def _load_assets(self):
        try:
            self.lbm = Image.open(APP / 'assets' / 'SanInet.lbm').convert('RGB')
        except (OSError, ValueError):
            self.lbm = None
        try:
            self.terrain = Terrain()
        except (OSError, ValueError) as error:
            self.terrain_error = str(error)

    def _build(self):
        bar = tk.Frame(self, bg=BAR)
        bar.pack(fill='x')
        tk.Label(bar, text=self.title_text, bg=BAR, fg=INK, font=(self.face, 16, 'bold')).pack(side='left', padx=12, pady=8)
        tk.Label(bar, textvariable=self.status, bg=BAR, fg=MUTED, font=(self.face, 11)).pack(side='left', padx=8)
        if self.detachable:
            tk.Button(bar, text='打开独立视窗', command=self.open_detached, bg='#3d3f34', fg=INK, relief='flat', padx=10).pack(side='left', padx=6)
        tk.Label(bar, text='滚轮缩放', bg=BAR, fg=MUTED, font=(self.face, 10)).pack(side='right', padx=8)
        for text, command in (('全图', self.fit), ('－', lambda: self.change_zoom(-0.5)), ('＋', lambda: self.change_zoom(0.5))):
            tk.Button(bar, text=text, command=command, bg='#3d3f34', fg=INK, relief='flat', padx=10).pack(side='right', padx=3, pady=6)
        for name in reversed(tuple(self.layers)):
            tk.Checkbutton(bar, text=name, variable=self.layers[name], command=self.draw, bg=BAR, fg=INK, selectcolor=BAR, activebackground=BAR, activeforeground=INK).pack(side='right', padx=2)
        tk.Checkbutton(bar, text='只看交战/我方', variable=self.war_only, command=self.draw, bg=BAR, fg='#e7c27a', selectcolor=BAR, activebackground=BAR).pack(side='right', padx=8)
        self.layer = tk.StringVar()
        tk.Label(bar, textvariable=self.layer, bg=BAR, fg='#d8c27a', font=(self.face, 10)).pack(side='right', padx=10)
        body = tk.Frame(self, bg=BG)
        body.pack(fill='both', expand=True)
        map_area = tk.Frame(body, bg=BG)
        map_area.pack(side='left', fill='both', expand=True)
        navigation_bar(map_area, self.pan, self.fit).pack(fill='x')
        holder = tk.Frame(map_area, bg=BG)
        holder.pack(fill='both', expand=True)
        self.canvas = tk.Canvas(holder, bg='#68724e', highlightthickness=0)
        self.canvas.pack(fill='both', expand=True)
        self.view_panel = tk.Frame(holder, bg='#1c1f18', highlightbackground='#8a6f2a', highlightthickness=1)
        tk.Label(self.view_panel, text='本视野部队', bg='#1c1f18', fg='#e4c56a',
                 font=(self.face, 11, 'bold'), anchor='w').pack(fill='x', padx=8, pady=(6, 2))
        self.view_hint = tk.StringVar(value='拖到覆盖范围后列出该范围内部队')
        tk.Label(self.view_panel, textvariable=self.view_hint, bg='#1c1f18', fg=MUTED,
                 font=(self.face, 9), anchor='w').pack(fill='x', padx=8)
        self.view_units = tk.Listbox(self.view_panel, bg='#2c2f26', fg=INK, selectbackground='#6a5520',
                                     height=7, width=42, font=(self.face, 10), relief='flat')
        self.view_units.pack(fill='both', padx=8, pady=(2, 8))
        self.view_units.bind('<<ListboxSelect>>', self._pick_view_unit)
        self.view_unit_keys = []
        self._view_sig = None
        self.view_panel.place(relx=1.0, rely=1.0, x=-10, y=-10, anchor='se')
        side = tk.Frame(body, bg='#22241d', width=340)
        side.pack(side='right', fill='y')
        side.pack_propagate(False)
        tk.Label(side, text='对手状态', bg='#22241d', fg=INK, font=(self.face, 13, 'bold'), anchor='w').pack(fill='x', padx=12, pady=(12, 4))
        tk.Label(side, textvariable=self.brief, bg='#22241d', fg='#e4c56a', wraplength=300, justify='left', anchor='w', font=(self.face, 11)).pack(fill='x', padx=12)
        tk.Label(side, text='各军首都', bg='#22241d', fg=MUTED, anchor='w', font=(self.face, 10)).pack(fill='x', padx=12, pady=(10, 2))
        self.capitals = tk.Listbox(side, bg='#2c2f26', fg=INK, selectbackground='#6a5520', height=8, font=(self.face, 11), relief='flat')
        self.capitals.pack(fill='x', padx=12)
        self.capitals.bind('<<ListboxSelect>>', self._pick_capital)
        tk.Label(side, text='交战部队', bg='#22241d', fg=MUTED, anchor='w', font=(self.face, 10)).pack(fill='x', padx=12, pady=(10, 2))
        self.enemies = tk.Listbox(side, bg='#2c2f26', fg=INK, selectbackground='#6a3b2a', height=12, font=(self.face, 11), relief='flat')
        self.enemies.pack(fill='both', expand=True, padx=12)
        self.enemies.bind('<<ListboxSelect>>', self._pick_enemy)
        tk.Label(side, text='选中对象', bg='#22241d', fg=MUTED, anchor='w', font=(self.face, 10)).pack(fill='x', padx=12, pady=(10, 2))
        tk.Label(side, textvariable=self.detail, bg='#22241d', fg=INK, wraplength=300, justify='left', anchor='nw', font=(self.face, 11)).pack(fill='both', expand=True, padx=12, pady=(0, 12))

    def update_state(self, state):
        self.state = state
        self.brief.set(opponent_brief(state))
        self._fill_capitals()
        self._fill_enemies()
        if self.selected:
            kind, row = self._selected_row()
            if row is None:
                self.selected = None
                self.detail.set('原对象已消失或标识不唯一。')
            else:
                self.detail.set(self._describe(kind, row))
        self.draw()

    def _fill_capitals(self):
        self.capital_keys = []
        self.capitals.delete(0, 'end')
        if not self.state:
            return
        for mark in capital_marks(self.state):
            city = next((row for kind, row in live_objects(self.state) if kind == '城关' and row.get('city_id') == mark['city_id']), None)
            if city is None:
                continue
            self.capital_keys.append(object_key('城关', city))
            x, y = mark['world_xy']
            self.capitals.insert('end', f"{mark['force_name']}  {mark['city_name']}  ({x},{y})")

    def _pick_capital(self, _=None):
        selection = self.capitals.curselection()
        if not selection:
            return
        self.selected = self.capital_keys[selection[0]]
        kind, row = self._selected_row()
        if row is None:
            return
        xy = world_xy(row)
        self.center = (xy[0] + 0.5, xy[1] + 0.5)
        self.zoom = max(self.zoom, 4.0)
        self.detail.set(self._describe(kind, row))
        self.draw()

    def _visible_box(self, w, h):
        return box_from_corners((
            self._world_at(0, 0),
            self._world_at(w, 0),
            self._world_at(0, h),
            self._world_at(w, h),
        ))

    def _refresh_view_units(self, w, h):
        if not self.layers['部队'].get():
            sig = ('hidden',)
            lines, keys, hint = ['已关闭部队层'], [], '勾选上方「部队」后列出本视野'
        elif not self.state:
            sig = ('empty',)
            lines, keys, hint = ['尚无采集'], [], '进入对局后列出覆盖范围内部队'
        else:
            box = self._visible_box(w, h)
            rows = sort_view_units(self.state, units_in_view(self.state, box, self.war_only.get()), self.center)
            keys = [object_key('部队', row) for row in rows]
            lines = [view_unit_line(self.state, row) for row in rows] or ['本视野无部队']
            hint = f'覆盖 {len(rows)} 支' + (' · 只看交战/我方' if self.war_only.get() else '')
            sig = (tuple(keys), tuple(lines), hint)
        if sig == self._view_sig:
            return
        self._view_sig = sig
        self.view_unit_keys = keys
        self.view_hint.set(hint)
        self.view_units.delete(0, 'end')
        for line in lines:
            self.view_units.insert('end', line)

    def _pick_view_unit(self, _=None):
        selection = self.view_units.curselection()
        if not selection or selection[0] >= len(self.view_unit_keys):
            return
        self.selected = self.view_unit_keys[selection[0]]
        kind, row = self._selected_row()
        if row is None:
            return
        xy = world_xy(row)
        self.center = (xy[0] + 0.5, xy[1] + 0.5)
        self.zoom = max(self.zoom, 6.0)
        self.detail.set(self._describe(kind, row))
        self.draw()

    def _fill_enemies(self):
        self.enemy_keys = []
        self.enemies.delete(0, 'end')
        if not self.state:
            return
        for kind, row in live_objects(self.state):
            if kind != '部队' or not at_war(self.state, row.get('owner_raw')):
                continue
            self.enemy_keys.append(object_key(kind, row))
            self.enemies.insert('end', object_label(self.state, kind, row))

    def _pick_enemy(self, _=None):
        selection = self.enemies.curselection()
        if not selection:
            return
        self.selected = self.enemy_keys[selection[0]]
        kind, row = self._selected_row()
        if row is None:
            return
        xy = world_xy(row)
        self.center = (xy[0] + 0.5, xy[1] + 0.5)
        self.zoom = max(self.zoom, 6.0)
        self.detail.set(self._describe(kind, row))
        self.draw()

    def _selected_row(self):
        if not self.selected or not self.state:
            return None, None
        matches = [(kind, row) for kind, row in live_objects(self.state) if object_key(kind, row) == self.selected]
        return matches[0] if len(matches) == 1 else (None, None)

    def _describe(self, kind, row):
        xy = world_xy(row)
        owner = next((force.get('name') for force in self.state.get('entities', {}).get('lords', []) if force.get('force_id') == row.get('owner_raw')), '未分配')
        war = '交战' if at_war(self.state, row.get('owner_raw')) else ('我方' if row.get('owner_raw') == player_id(self.state) else '其他')
        text = f'{kind} · {object_label(self.state, kind, row)}\n坐标 {xy} · {owner} · {war}'
        if kind == '城关':
            text += f"\n防御 {fmt(row.get('defense'))} · 人口 {fmt(row.get('population'))} · 开发 {fmt(row.get('development'))} · 商业 {fmt(row.get('commerce'))}"
            if is_capital(self.state, row):
                text += f'\n首都位置 ({xy[0]},{xy[1]}) · {owner}'
        if kind == '部队':
            text += f"\n{memory_line(row)} · 攻城 {fmt(row.get('target_attack_building'))}"
        if kind == '建筑':
            text += f"\n对象ID {fmt(row.get('object_id_candidate'))} · 建成状态/等级尚未解析"
        if kind == '陷阱':
            text += ' · 独立只读对象；所属城市字段尚待核定'
        return text

    def fit(self):
        self.zoom = MIN_ZOOM
        self.center = DEFAULT_CENTER
        self.draw()

    def pan(self, dx, dy):
        self.center = move_center(self.center, dx, dy, max(0.4, 10 / self.zoom), WORLD, 0.5)
        self.draw()

    def change_zoom(self, delta, screen=None):
        old = self.zoom
        before = self._world_at(*screen) if screen is not None else None
        self.zoom = clamp_zoom(self.zoom + delta)
        if before is not None and self.zoom != old:
            after = self._world_at(*screen)
            self.center = clamp_center((
                self.center[0] + (before[0] - after[0]),
                self.center[1] + (before[1] - after[1]),
            ))
        self.draw()

    def _wheel(self, event, sx=None, sy=None):
        from map_navigation import wheel_direction_from_event
        direction = wheel_direction_from_event(event)
        if not direction:
            return
        now = time.monotonic()
        if now - getattr(self, '_wheel_at', 0) < 0.04:
            return
        self._wheel_at = now
        if sx is None:
            sx, sy = getattr(event, 'x', 0), getattr(event, 'y', 0)
        self.change_zoom(0.5 * direction, (sx, sy))

    def _wheel_delta(self, direction):
        self.change_zoom(0.5 * direction)

    def _press(self, event):
        self.canvas.focus_set()
        self.drag = (event.x, event.y, self.center)

    def _drag(self, event):
        if not self.drag:
            return
        x0, y0, origin = self.drag
        width = max(1, self.canvas.winfo_width())
        cells = 28 / self.zoom if layer_for_zoom(self.zoom) == 'mbm' else WORLD[0] / self.zoom
        self.center = clamp_center((
            origin[0] - (event.x - x0) / width * cells,
            origin[1] - (event.y - y0) / max(1, self.canvas.winfo_height()) * (cells * WORLD[1] / WORLD[0]),
        ))
        self.draw()

    def _release(self, event):
        start = self.drag
        self.drag = None
        if not start or abs(event.x - start[0]) + abs(event.y - start[1]) > 8:
            return
        hit = self._hit(event.x, event.y)
        if hit:
            self.selected = hit
            kind, row = self._selected_row()
            if row:
                self.detail.set(self._describe(kind, row))
            self.draw()
            return
        point = self._world_at(event.x, event.y)
        for kind, row in live_objects(self.state) if self.state else []:
            if kind != '城关':
                continue
            xy = world_xy(row)
            if max(abs(xy[0] + 0.5 - point[0]), abs(xy[1] + 0.5 - point[1])) <= 1.2:
                self.center = (xy[0] + 0.5, xy[1] + 0.5)
                self.zoom = max(self.zoom, 6.0)
                self.selected = object_key(kind, row)
                self.detail.set(self._describe(kind, row))
                self.draw()
                return

    def _hit(self, x, y):
        limit = max(28, sprite_size('城关', self.zoom) // 2)
        nearby = [(px, py, key) for px, py, key in self.hits if (px - x) ** 2 + (py - y) ** 2 <= limit ** 2]
        if not nearby:
            return None
        nearby.sort(key=lambda item: (item[0] - x) ** 2 + (item[1] - y) ** 2)
        keys = [item[2] for item in nearby]
        return keys[(keys.index(self.selected) + 1) % len(keys)] if self.selected in keys else keys[0]

    def _world_at(self, sx, sy):
        w = max(1, self.canvas.winfo_width())
        h = max(1, self.canvas.winfo_height())
        if layer_for_zoom(self.zoom) == 'mbm':
            box, scale = mbm_view(self.center, self.zoom, w, h)
            px, py = box[0] + sx / scale, box[1] + sy / scale
            best, best_d = self.center, 10 ** 9
            for y in range(max(0, int(self.center[1]) - 8), min(WORLD[1], int(self.center[1]) + 9)):
                for x in range(max(0, int(self.center[0]) - 8), min(WORLD[0], int(self.center[0]) + 9)):
                    tx, ty = world_pixel(x, y)
                    distance = (tx - px) ** 2 + (ty - py) ** 2
                    if distance < best_d:
                        best, best_d = (x + 0.5, y + 0.5), distance
            return best
        ox, oy, vw, vh = map_viewport(w, h)
        return (
            self.center[0] + (sx - w / 2) / vw * WORLD[0] / self.zoom,
            self.center[1] + (sy - h / 2) / vh * WORLD[1] / self.zoom,
        )

    def _project(self, x, y, w, h, layer):
        if layer == 'lbm':
            ox, oy, vw, vh = map_viewport(w, h)
            return (
                w / 2 + (x + 0.5 - self.center[0]) * vw * self.zoom / WORLD[0],
                h / 2 + (y + 0.5 - self.center[1]) * vh * self.zoom / WORLD[1],
            )
        box, scale = mbm_view(self.center, self.zoom, w, h)
        px, py = world_pixel(x, y)
        return ((px - box[0]) * scale, (py - box[1]) * scale)

    def draw(self):
        c = self.canvas
        w, h = c.winfo_width(), c.winfo_height()
        if w < 8:
            w = tk_pixels(c, c.cget('width'))
        if h < 8:
            h = tk_pixels(c, c.cget('height'))
        if w < 8 or h < 8:
            return
        c.delete('all')
        self.hits = []
        layer = layer_for_zoom(self.zoom)
        self.layer.set(f'{LAYER_HINT[layer]} · 倍率 {self.zoom:g} · WASD 移动 · 滚轮缩放 · 主城中心半透明势力色')
        if layer == 'mbm' and self.terrain:
            box, scale = mbm_view(self.center, self.zoom, w, h)
            view = self.terrain.crop(box).resize((w, h), Image.Resampling.NEAREST)
            view = overlay_force_diamonds(view, self._capital_vision_diamonds(w, h, layer, box, scale))
            self.photo = ImageTk.PhotoImage(view, master=c)
            c.create_image(0, 0, image=self.photo, anchor='nw')
        elif self.lbm is not None:
            ox, oy, vw, vh = map_viewport(w, h)
            dx, dy = WORLD[0] / self.zoom / 2, WORLD[1] / self.zoom / 2
            sx, sy = self.lbm.width / WORLD[0], self.lbm.height / WORLD[1]
            box = ((self.center[0] - dx) * sx, (self.center[1] - dy) * sy, (self.center[0] + dx) * sx, (self.center[1] + dy) * sy)
            view = self.lbm.transform((max(1, round(vw)), max(1, round(vh))), Image.Transform.EXTENT, box, resample=Image.Resampling.BILINEAR)
            view = overlay_force_diamonds(view, self._capital_vision_diamonds(w, h, layer, None, None), alpha=56)
            self.photo = ImageTk.PhotoImage(view, master=c)
            c.create_image(ox, oy, image=self.photo, anchor='nw')
        else:
            c.create_text(w / 2, 24, text='底图不可用：' + (self.terrain_error or '缺少 SanInet.lbm / SanInet.mbm'), fill=INK)
        self._draw_supply(w, h, layer)
        self._draw_objects(w, h, layer)
        self._draw_capitals(w, h, layer)
        self._refresh_view_units(w, h)

    def _rgb(self, owner):
        return '#' + ''.join(f'{value:02x}' for value in state_force_rgb(self.state, owner))

    def _project_mbm(self, px, py, w, h, layer, box=None, scale=None):
        if layer == 'mbm':
            if box is None:
                box, scale = mbm_view(self.center, self.zoom, w, h)
            return ((px - box[0]) * scale, (py - box[1]) * scale)
        wx, wy = mbm_to_world(px, py)
        return self._project(wx, wy, w, h, layer)

    def _capital_vision_diamonds(self, w, h, layer, box, scale):
        if not self.state or not self.layers['首都'].get():
            return []
        diamonds = []
        for mark in capital_marks(self.state):
            xy = mark.get('world_xy')
            rgb = state_force_rgb(self.state, mark.get('owner_raw'))
            if xy is None:
                continue
            for cell in vision_cells(xy):
                points = [self._project_mbm(px, py, w, h, layer, box, scale) for px, py in cell_diamond(*cell)]
                if layer != 'mbm':
                    ox, oy, vw, vh = map_viewport(w, h)
                    points = [(x - ox, y - oy) for x, y in points]
                diamonds.append({'points': points, 'rgb': rgb, 'center': cell == xy})
        return diamonds

    def _draw_supply(self, w, h, layer):
        if not self.state or not self.layers['补给线'].get():
            return
        box = scale = None
        if layer == 'mbm':
            box, scale = mbm_view(self.center, self.zoom, w, h)
        width = 3 if layer == 'lbm' else max(3, int(self.zoom * 0.45))
        for line in supply_lines(self.state):
            path = path_for_layer(line['path'], layer)
            points = [self._project_mbm(px, py, w, h, layer, box, scale) for px, py in path]
            xs = [p[0] for p in points]
            ys = [p[1] for p in points]
            if max(xs) < -40 or min(xs) > w + 40 or max(ys) < -40 or min(ys) > h + 40:
                continue
            color = self._rgb(line['owner_raw']) if line['same_owner'] else '#f4efe2'
            stroke = width if line['same_owner'] else max(1, width - 1)
            flat = [value for point in points for value in point]
            self.canvas.create_line(*flat, fill='#2a2c24', width=stroke + 2, capstyle=tk.ROUND, joinstyle=tk.ROUND)
            self.canvas.create_line(*flat, fill=color, width=stroke, capstyle=tk.ROUND, joinstyle=tk.ROUND)

    def _star(self, x, y, outer, inner=None):
        inner = outer * 0.45 if inner is None else inner
        points = []
        for i in range(10):
            radius = outer if i % 2 == 0 else inner
            angle = -math.pi / 2 + i * math.pi / 5
            points.extend((x + radius * math.cos(angle), y + radius * math.sin(angle)))
        return points

    def _draw_capitals(self, w, h, layer):
        if not self.state or not self.layers['首都'].get():
            return
        size = 11 if layer == 'lbm' else min(22, int(10 + self.zoom))
        for mark in capital_marks(self.state):
            x, y = self._project(*mark['world_xy'], w, h, layer)
            if not (-50 <= x <= w + 50 and -50 <= y <= h + 50):
                continue
            color = self._rgb(mark['owner_raw'])
            self.canvas.create_oval(x - size - 4, y - size - 4, x + size + 4, y + size + 4, outline='#f6d36a', width=2)
            self.canvas.create_polygon(*self._star(x, y - size - 8, 8 if layer == 'lbm' else 10), fill=color, outline='#f6d36a')
            if self.layers['文字'].get():
                self.canvas.create_text(
                    x, y + size + 10,
                    text=f"首都 · {mark['force_name']} · {mark['city_name']}",
                    fill='#ffe9a3', font=(self.face, 10, 'bold'),
                )
                self.canvas.create_text(
                    x, y + size + 24,
                    text=f"({mark['world_xy'][0]},{mark['world_xy'][1]})",
                    fill='#d8c27a', font=(self.face, 9),
                )

    def _draw_objects(self, w, h, layer):
        if not self.state:
            return
        scale = mbm_view(self.center, self.zoom, w, h)[1] if layer == 'mbm' else None
        grouped = defaultdict(list)
        for kind, row in live_objects(self.state):
            if kind in self.layers and not self.layers[kind].get():
                continue
            if not show_overlay(self.state, kind, row, self.war_only.get()):
                continue
            grouped[world_xy(row)].append((kind, row))
        for xy, rows in grouped.items():
            x, y = self._project(*xy, w, h, layer)
            if not (-40 <= x <= w + 40 and -40 <= y <= h + 40):
                continue
            for i, (kind, row) in enumerate(rows):
                px = x + (i - (len(rows) - 1) / 2) * 22
                key = object_key(kind, row)
                self.hits.append((px, y, key))
                size = sprite_size(kind, self.zoom, scale)
                color = self._rgb(row.get('owner_raw'))
                if key == self.selected:
                    self.canvas.create_oval(px - size, y - size, px + size, y + size, outline='#ffe27a', width=3)
                if at_war(self.state, row.get('owner_raw')):
                    self.canvas.create_oval(px - size - 3, y - size - 3, px + size + 3, y + size + 3, outline='#c32620', width=2)
                sprite = self.sprites.image(row, size, self.state)
                if sprite:
                    self.canvas.create_image(px, y - 4, image=sprite)
                elif kind == '部队':
                    self.canvas.create_polygon(px, y - 12, px - 10, y + 6, px + 10, y + 6, fill=color, outline='#1d2418')
                else:
                    self.canvas.create_oval(px - 4, y - 4, px + 4, y + 4, fill='#f3e6a6', outline='#3b341f')
                flag = self.sprites.flag(self.state, row.get('owner_raw'), max(14, size // 2))
                if flag:
                    self.canvas.create_image(px + size // 2 + 4, y - size // 2, image=flag)
                if self.layers['文字'].get() and (layer == 'mbm' or kind == '城关'):
                    label = object_label(self.state, kind, row)
                    if kind == '城关' and is_capital(self.state, row):
                        label = '都·' + label
                    if kind == '部队':
                        label_box(self.canvas, px, y + size // 2 + 6, label, color)
                    else:
                        self.canvas.create_text(px + 8, y - size // 2 - 4, text=label, anchor='w', fill='#fff6da', font=(self.face, 10))


class PanoramaApp:
    def __init__(self, root):
        self.root = root
        self.stop = threading.Event()
        self.inbox = queue.Queue()
        self.last_sig = None
        apply_light_defaults(root)
        root.title('全景视窗 · 对手状态')
        root.configure(bg=BG)
        root.minsize(960, 640)
        self.page = PanoramaMap(root)
        self.page.pack(fill='both', expand=True)
        maximize(root)
        root.protocol('WM_DELETE_WINDOW', self.close)
        threading.Thread(target=self._poll, daemon=True, name='panorama-api-reader').start()
        root.after(200, self._tick)

    def _poll(self):
        from portable_client import poll
        poll(self)

    def _tick(self):
        try:
            while True:
                payload = self.inbox.get_nowait()
                from portable_client import invalidate_player, status_text
                if payload.get('fresh') is not True:
                    payload['fresh'] = False
                if payload.get('state'):
                    doc = payload['state'] if payload.get('fresh') else invalidate_player(payload['state'])
                    signature = (
                        doc.get('snapshot_id'),
                        tuple((object_key(kind, row), world_xy(row), row.get('owner_raw'), row.get('soldiers_candidate'))
                              for kind, row in live_objects(doc)),
                    )
                    if signature != self.last_sig:
                        self.last_sig = signature
                        self.page.update_state(doc)
                text, _ = status_text(payload, payload.get('state') or self.page.state)
                self.page.status.set(text)
        except queue.Empty:
            pass
        if not self.stop.is_set():
            self.root.after(250, self._tick)

    def close(self):
        self.stop.set()
        self.root.destroy()


def attach_collector():
    try:
        from connection import CONNECTION
        if CONNECTION.remote:
            return 'remote'
        if sys.platform == 'win32':
            from service_startup import ensure_service
            return ensure_service(
                'http://127.0.0.1:8769/health', 'sgi-crossover-bridge-1',
                [sys.executable, '-B', str(ROOT / 'bridge/windows_bridge.py')],
                ROOT, ROOT / 'logs/native-bridge.log',
            ).get('mode', 'started')
        from bridge_autostart import ensure_bridge
        return ensure_bridge(ROOT).get('mode', 'started')
    except Exception as error:
        return str(error)


def parse_view(argv=None):
    import argparse
    parser = argparse.ArgumentParser(description='SGI panorama')
    parser.add_argument('--center', help='world x,y')
    parser.add_argument('--zoom', type=float)
    args = parser.parse_args(argv)
    center = None
    if args.center:
        x, y = args.center.split(',')
        center = (float(x), float(y))
    return center, args.zoom


def apply_view(page, center=None, zoom=None):
    if center is not None:
        page.center = clamp_center(center)
    if zoom is not None:
        page.zoom = clamp_zoom(zoom)


def main(argv=None):
    lock = acquire_lock()
    if lock is None:
        print('本机已有全景视窗，请使用原窗口。')
        return
    center, zoom = parse_view(argv)
    attach_collector()
    root = tk.Tk()
    apply_dock_icon(root, 'map')
    app = PanoramaApp(root)
    apply_view(app.page, center, zoom)
    try:
        root.mainloop()
    finally:
        app.stop.set()
        lock.close()


if __name__ == '__main__':
    main()
