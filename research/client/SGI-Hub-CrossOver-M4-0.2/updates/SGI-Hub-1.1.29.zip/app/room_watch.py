"""Local-only room observer UI, Windows or macOS Wine; never joins a game."""
import json
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import queue
import subprocess
import sys
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox

ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'app'))
sys.path.insert(0,str(ROOT/'bridge'))
from room_list_model import AlertState
from room_watch_audio import read_play_bgm, resolve_setting_ini, write_play_bgm
from room_watch_settings import load as load_settings, save as save_settings, read_file, update as update_settings

SCHEME='保留游戏的后台静音观察（不是仅大厅查询）'
ALERT_SOUND=Path('/System/Library/Sounds/Ping.aiff')

def ring(root=None):
    if root is not None:
        root.bell()
    if sys.platform=='darwin' and ALERT_SOUND.is_file():
        subprocess.Popen(['afplay',str(ALERT_SOUND)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)

def wine_prefix():
    try:
        from connection import local_config
        runtime=(local_config() or {}).get('wine_runtime') or {}
        prefix=runtime.get('prefix')
        return prefix
    except Exception:
        return None

def command(refresh, quiet=False, reveal=False):
    reader=ROOT/'bridge/room_list_reader.py'
    extra=[]
    if refresh:extra.append('--refresh')
    if quiet:extra.append('--quiet')
    if reveal:extra.append('--reveal')
    if sys.platform=='win32':
        cmd=[str(ROOT/'bridge/python/python.exe') if (ROOT/'bridge/python/python.exe').exists() else sys.executable,
             '-X','utf8','-B',str(reader)]
        cmd.extend(extra)
        return cmd,os.environ.copy()
    from bridge_autostart import configure_local_runtime, bridge_command
    configure_local_runtime(ROOT)
    cmd,_=bridge_command(ROOT)
    argv="sys.argv=[str(p)]"+''.join(f'+[{flag!r}]' for flag in extra)
    cmd=cmd[:-2]+['-c','import runpy,sys; from pathlib import Path; p=Path(sys.executable).resolve().parent.parent/"room_list_reader.py"; '+argv+'; runpy.run_path(str(p),run_name="__main__")']
    env=os.environ.copy()
    env['WINEDEBUG']='-all'
    return cmd,env

def probe(refresh=False, quiet=False, reveal=False):
    cmd,env=command(refresh, quiet=quiet, reveal=reveal)
    result=subprocess.run(cmd,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=20,
                          creationflags=0x08000000 if sys.platform=='win32' else 0)
    if result.returncode:raise RuntimeError('观察进程退出；游戏进程未被终止')
    for line in reversed(result.stdout.splitlines()):
        try:
            value=json.loads(line)
            if isinstance(value,dict) and 'status' in value:return value
        except ValueError:pass
    raise RuntimeError('未收到有效的房间数据')

def acquire_lock():
    path=ROOT/'logs/room-watch.lock';path.parent.mkdir(exist_ok=True)
    stream=path.open('a+b')
    if sys.platform=='win32':
        import msvcrt
        stream.seek(0);stream.write(b'0');stream.flush();stream.seek(0)
        msvcrt.locking(stream.fileno(),msvcrt.LK_NBLCK,1)
    else:
        import fcntl
        fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB)
    return stream

def setting_ini(exe=None):
    return resolve_setting_ini(exe, wine_prefix())

def mute_bgm(settings_path, exe=None):
    ini=setting_ini(exe)
    current,_,_=read_play_bgm(ini)
    stored=read_file(settings_path)
    if stored.get('audio_original') not in (0,1):
        update_settings(settings_path,audio_original=current)
    write_play_bgm(ini,0)
    update_settings(settings_path,audio_muted=True)
    return current

def restore_bgm(settings_path, exe=None):
    stored=read_file(settings_path)
    original=stored.get('audio_original')
    if original not in (0,1):
        raise RuntimeError('没有已保存的原音频设置，未改写')
    write_play_bgm(setting_ini(exe),original)
    update_settings(settings_path,audio_muted=False)
    return original

def main():
    settings_path=ROOT/'room-watch.local.json'
    threshold,minutes=load_settings(settings_path)
    alerts=AlertState(threshold,minutes)
    root=tk.Tk();root.title(f'房间人数观察 · 本机 · 大于 {threshold} 人提示')
    try:lock=acquire_lock()
    except OSError:
        messagebox.showinfo('房间观察','本机已有一个观察窗口，请使用原窗口。');root.destroy();return
    from mac_light_theme import apply_light_defaults
    apply_light_defaults(root)
    root.geometry('700x480');root.minsize(640,420)
    logger=logging.getLogger('room-watch');logger.setLevel(logging.INFO)
    handler=RotatingFileHandler(ROOT/'logs/room-watch.jsonl',maxBytes=1024*1024,backupCount=3,encoding='utf-8')
    logger.addHandler(handler)
    frame=ttk.Frame(root,padding=12);frame.pack(fill='both',expand=True)
    ttk.Label(frame,text=SCHEME).pack(anchor='w')
    status=tk.StringVar(value='正在读取列表缓存… 关闭本窗会停止观察并恢复游戏显示/原音频设置。')
    ttk.Label(frame,textvariable=status,wraplength=660).pack(anchor='w',pady=8)
    tree=ttk.Treeview(frame,columns=('name','count','state'),show='headings',height=6)
    for name,title,width in [('name','房间',285),('count','连接人数 / 上限',125),('state','进场参考',180)]:
        tree.heading(name,text=title);tree.column(name,width=width,minwidth=80)
    tree.tag_configure('ready',background='#d5f1d5',foreground='#153b15');tree.pack(fill='both',expand=True)
    bar=ttk.Frame(frame);bar.pack(fill='x',pady=8)
    running=tk.BooleanVar(value='--watch' in sys.argv)
    sound=tk.BooleanVar(value=True)
    background=tk.BooleanVar(value=True)
    ttk.Checkbutton(bar,text='自动刷新（后台，不弹窗）',variable=running).pack(side='left')
    ttk.Checkbutton(bar,text='达到条件时响铃',variable=sound).pack(side='left',padx=8)
    settings_bar=ttk.Frame(frame);settings_bar.pack(fill='x',pady=(0,8))
    x_var=tk.StringVar(value=str(threshold));y_var=tk.StringVar(value=f'{minutes:g}')
    ttk.Label(settings_bar,text='有房间大于').pack(side='left')
    ttk.Spinbox(settings_bar,from_=0,to=63,textvariable=x_var,width=4).pack(side='left',padx=4)
    ttk.Label(settings_bar,text='人，每').pack(side='left')
    ttk.Spinbox(settings_bar,from_=.1,to=1440,increment=.5,textvariable=y_var,width=6).pack(side='left',padx=4)
    ttk.Label(settings_bar,text='分钟最多响一次').pack(side='left')
    hint=tk.StringVar()
    def update_hint():
        hint.set(f'当前生效：人数 >{alerts.threshold}（至少 {alerts.threshold+1} 人），每 {alerts.minutes:g} 分钟可响一次。\n'
                 '含房主；多人达标合并警报。不会自动加入。大厅本身不能查人数。关闭窗口=退出观察并恢复游戏。')
    def apply_settings():
        try:x,y=save_settings(settings_path,x_var.get(),y_var.get())
        except (OSError,ValueError,TypeError) as error:
            messagebox.showerror('警报设置未保存',str(error));return
        alerts.configure(x,y);x_var.set(str(x));y_var.set(f'{y:g}');update_hint()
        root.title(f'房间人数观察 · 本机 · 大于 {x} 人提示')
        status.set('警报设置已保存；在下一次有效刷新时按新设置判断')
    ttk.Button(settings_bar,text='保存设置',command=apply_settings).pack(side='right')
    update_hint();ttk.Label(frame,textvariable=hint,wraplength=660).pack(anchor='w')
    inbox=queue.Queue();state={'busy':False,'next':0,'closed':False,'exe':None,'restored':False,'muted':False}
    def start(refresh=True, reveal=False):
        if state['busy'] or state['closed']:return
        state['busy']=True
        quiet=background.get() and refresh and not reveal
        if reveal:status.set('正在恢复游戏窗口…')
        elif refresh:status.set('正在后台刷新房间列表（不抢焦点）…')
        else:status.set('读取现有列表（缓存，不报警）…')
        def work():
            try:result=probe(refresh=refresh and not reveal, quiet=quiet, reveal=reveal)
            except Exception as error:result={'status':'unavailable','rooms':[],'message':str(error),'observed_at':time.time()}
            inbox.put(result)
        threading.Thread(target=work,daemon=True).start()
    def apply_mute():
        try:
            original=mute_bgm(settings_path,state.get('exe'))
            status.set(f'已把游戏 PlayBGM 从 {original} 改为 0；观察器响铃不受影响。进入游戏前请先恢复。')
        except Exception as error:
            status.set('游戏静音未生效：'+str(error))
    def restore_game():
        try:
            restore_bgm(settings_path,state.get('exe'));state['muted']=False
        except Exception as error:
            status.set('原音频未恢复：'+str(error)+'；仍尝试显示窗口')
        start(refresh=False, reveal=True)
    def exit_watch():
        if state['closed']:
            close_window();return
        if state['restored']:
            if not state['busy']:close_window()
            return
        state['restored']=True
        running.set(False)
        try:restore_bgm(settings_path,state.get('exe'));state['muted']=False
        except Exception:
            pass
        def finish(tries=0):
            if state['closed']:return
            if state['busy'] and tries<50:
                root.after(200,lambda:finish(tries+1));return
            if tries==0 or state['busy'] is False:
                start(refresh=False, reveal=True)
                root.after(2500,close_window)
        finish()
    actions=ttk.Frame(frame);actions.pack(fill='x',pady=6)
    ttk.Button(actions,text='立即后台刷新',command=lambda:start(True)).pack(side='left')
    ttk.Button(actions,text='恢复游戏显示和声音',command=restore_game).pack(side='left',padx=8)
    ttk.Button(actions,text='退出观察',command=exit_watch).pack(side='right')
    def tick():
        if state['closed']:return
        try:
            value=inbox.get_nowait()
            state['busy']=False;state['next']=time.monotonic()+20
            if value.get('exe'):state['exe']=value['exe']
            logger.info(json.dumps(value,ensure_ascii=False))
            tree.delete(*tree.get_children())
            fresh=value['status']=='fresh'
            for r in value.get('rooms',[]):
                ready=fresh and r['current']>alerts.threshold
                tree.insert('', 'end',values=(r['name'],f"{r['current']} / {r['maximum']}"+('（缓存）' if not fresh else ''),
                    f'已超过 {alerts.threshold} 人' if ready else (f'等待人数 >{alerts.threshold}' if fresh else '未验证更新时间')),tags=('ready',) if ready else ())
            stamp=time.strftime('%H:%M:%S',time.localtime(value['observed_at']))
            events=alerts.update(value,enabled=sound.get())
            if fresh:
                status.set('最近成功查询 '+stamp+' · '+value.get('message',''))
            else:
                status.set(value.get('message') or '读取未成功；未用旧人数报警')
            if fresh and not value['rooms']:status.set('已搜索 '+stamp+' · 当前未发现房间（不代表房间为 0 人）')
            if events:
                status.set(f'人数已超过 {alerts.threshold}：'+'、'.join(f"{r['name']} {r['current']} 人" for r in events))
                root.title(f'≥{alerts.threshold+1} 人 · 可以考虑进场 · 房间观察')
                if sound.get():ring(root)
            elif fresh:root.title(f'房间人数观察 · 本机 · 大于 {alerts.threshold} 人提示')
            if value['status']=='unavailable':
                running.set(False);status.set(value['message']+'；已暂停，不会用过期人数报警')
            elif value.get('quiet') and value.get('status')=='fresh' and not state['restored'] and not state['muted']:
                apply_mute();state['muted']=True
        except queue.Empty:pass
        if running.get() and not state['busy'] and time.monotonic()>=state['next']:start()
        root.after(200,tick)
    def close_window():
        state['closed']=True
        root.destroy()
    def close():
        if not state['restored']:
            exit_watch()
            return
        close_window()
    root.protocol('WM_DELETE_WINDOW',close)
    start(running.get());root.after(200,tick);root.mainloop()
    lock.close()

if __name__=='__main__':
    try:
        main()
    except Exception:
        logging.basicConfig(filename=str(ROOT/'logs/room-watch-ui.log'),level=logging.ERROR)
        logging.exception('room_watch failed')
        raise
