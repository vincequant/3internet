import sys
from pathlib import Path
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'app'))
from training_curves import ATTACK,current_training,curve_values,LinearScale,LogScale,calculator_attack,METRIC,tier_name
from unit_target_attack import BUILD, client_factor, rnd

class Curves(unittest.TestCase):
    def test_matches_client_table_and_iron_cavalry_jumps(self):
        names = {('infantry',93):'步兵',('infantry',300):'重装步兵',('cavalry',221):'铁骑兵',
                 ('cavalry',300):'铁骑兵',('bow',139):'强弓兵',('bow',300):'重装弓兵'}
        for (kind, raw), name in names.items():
            degree = 100 if raw >= 300 else raw % 100
            expected = tuple(rnd(client_factor(name, size, degree) * 100 / 150) for size in range(3))
            self.assertEqual(ATTACK[kind][raw], expected)
        self.assertEqual(calculator_attack('bow',139,1),157)
        self.assertEqual(calculator_attack('cavalry',300,0),150)
        self.assertEqual(calculator_attack('infantry',300,0),127)
        self.assertGreater(calculator_attack('cavalry',200,0), calculator_attack('cavalry',199,0))
        self.assertGreater(calculator_attack('cavalry',100,0), calculator_attack('cavalry',99,0))
        self.assertEqual(tier_name('cavalry',220),'铁骑兵')
        self.assertEqual(curve_values('infantry',METRIC,100,100000),ATTACK['infantry'])
        self.assertGreater(curve_values('bow','每千金保守收益',100,100000)[139][0],0)
    def test_current_unknown_and_local_precedence(self):
        f={'force_id':1,'armament_raw':{'infantry':50,'cavalry':True,'bow':301}}
        s={'build_sha256':BUILD}
        self.assertEqual(current_training(s,f)[0],{'infantry':50,'cavalry':None,'bow':None})
        s.update(player_force_id=1,player_identity={'status':'confirmed','force_id':1},current_local_projection={'player_force_id':1,'armament_raw':{'bow':100}})
        self.assertEqual(current_training(s,f)[0],{'infantry':None,'cavalry':None,'bow':100})
        s['build_sha256']='unknown';self.assertTrue(all(v is None for v in current_training(s,f)[0].values()))

    def test_linear_scale_uses_full_span(self):
        scale=LinearScale([33,153])
        self.assertGreater(scale.fraction(153)-scale.fraction(33),.8)
        self.assertAlmostEqual(scale.tick(0),scale.lo)
        flat=LinearScale([150,150])
        self.assertGreater(flat.hi,flat.lo)

    def test_log_spacing_zero_and_local_zoom(self):
        scale=LogScale([100,200,400])
        self.assertAlmostEqual(scale.fraction(200)-scale.fraction(100),scale.fraction(400)-scale.fraction(200))
        local=LogScale([450,575])
        self.assertGreater(local.fraction(575)-local.fraction(450),.85)
        for scale in [local,LogScale([0,0,0],True),LogScale([0,1,20],True)]:
            for f in [0,.25,.5,1]:self.assertAlmostEqual(scale.fraction(scale.tick(f)),f)
        self.assertEqual(LogScale([0,0],True).fraction(0),0)

if __name__=='__main__':unittest.main()
