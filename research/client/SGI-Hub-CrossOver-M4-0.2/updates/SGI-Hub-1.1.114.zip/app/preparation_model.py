"""Read-only prospective formations. No orders, memory writes or skill-bit claims.

Combat: 3.5 0x477b4f/0x477c24/0x477cd0, same as unit_combat.
Morale: cached 军事作战 tutorial, prestige/4 + combat/2 (rounding unverified).
Capacity: sum of selected officers' observed soldiers, limited by current stock;
this is a planning assumption, not a verified sortie dialog prediction.
"""
from collections import Counter
from itertools import combinations
from force_relations import at_war
from officer_reference import officer_metrics
from player_view import player_id
from state_extensions import training_progress
from unit_target_attack import BUILD, PARAMS, rnd, span, supported_combat_build, unit_factor

KINDS = {'infantry': ('步兵', '强化步兵', '重装步兵'),
         'cavalry': ('骑兵', '强化骑兵', '重装骑兵'),
         'bow': ('弓兵', '强弓兵', '重装弓兵')}
REQUIRED = {'infantry': None, 'cavalry': '骑马', 'bow': '弓箭'}
COMMON = {'无双', '防御', '奇袭', '收拾', '反计', '天变'}
SPELLS = {'火攻', '落石', '混乱', '天雷', '计谋'}
SIZES = ('小队', '中队', '大队')

def valid(n, lo=0, hi=100000):
    return type(n) is int and lo <= n <= hi

def size_index(soldiers):
    return int(soldiers > 20000) + int(soldiers > 35000)

def training_bases(kind, raw):
    degree = training_progress(raw)
    if kind not in KINDS or degree is None:
        return None
    tier = 0 if raw < 100 else 1 if raw < 200 else 2
    name = KINDS[kind][tier]
    ub, bb, uc, bc = PARAMS[name]
    return {'name': name, 'training': degree,
            'unit': [unit_factor(name,s,degree) for s in range(3)],
            'building': [b + rnd(c * degree / 100) for b, c in zip(bb, bc)]}

def combat_power(generals):
    values = []
    for g in generals:
        a = g.get('attributes', {}); flags = g.get('combat_modifier_flags')
        if not valid(flags, 0, 255) or not all(valid(a.get(k), 0, 255) for k in ('lead', 'war')):
            return None
        values.append((a['lead'] + (a['lead'] * 2 // 5 if flags & 0x10 else 0),
                       a['war'] + (a['war'] * 2 // 5 if flags & 0x20 else 0)))
    if not 1 <= len(values) <= 3:
        return None
    lead = values[0][0] if len(values) == 1 else (values[0][0] + sum(v[0] for v in values[1:]) // (len(values)-1)) // 2
    return (max(10, lead) + sum(v[1] for v in values) // len(values)) // 2

def skills_for(g):
    m = officer_metrics(g)
    return set(m['skills'].split(' / ')) - {'网站技能空表'} if m['current_diplomacy'] is not None else set()

def useful_skills(kind, skills):
    return skills & (COMMON | (SPELLS | {'攻城'} if kind == 'infantry' else {REQUIRED[kind]}))

def attack_values(base, power, qualified):
    return [rnd(v * power / 150) for v in ([base] if qualified else [base // 2, base])]

def reference_attack(kind, raw, size, power):
    bases = training_bases(kind, raw)
    if not bases or size not in (0, 1, 2) or not valid(power, 0, 150):
        return None
    factor = bases['unit'][size]
    return None if factor is None else rnd(factor * power / 150)

def unit_reference_attack(unit):
    values = (unit or {}).get('target_attack_components', {}).get('unit')
    power = (unit or {}).get('basic_combat_power')
    if isinstance(values, list) and values and valid(power, 0, 150) and all(valid(v, 0, 10000) for v in values):
        return [rnd(v * power / 150) for v in values]
    fallback = (unit or {}).get('website_attack_power')
    return [fallback] if valid(fallback, 0, 10000) else None

def war_enemy_ceiling(state):
    own = player_id(state)
    if own is None:
        return None
    names = {f.get('force_id'): f.get('name') or '?' for f in (state or {}).get('entities', {}).get('lords', [])}
    best = None
    for u in (state or {}).get('entities', {}).get('field_units', []):
        if not at_war(state, u.get('owner_raw')):
            continue
        attack = unit_reference_attack(u)
        if not attack:
            continue
        value = max(attack)
        if best is None or value > best['value']:
            label = f"{names.get(u.get('owner_raw'), '?')} · {u.get('unit_kind', '部队')} #{u.get('unit_id', '?')}"
            best = {'value': value, 'label': label, 'unit': u}
    return best

def lowest_training_to_beat(kind, size, power, target):
    if not valid(target, 0, 10000) or size not in (0, 1, 2) or not valid(power, 0, 150):
        return None
    for raw in range(0, 301):
        attack = reference_attack(kind, raw, size, power)
        if attack is not None and attack > target:
            bases = training_bases(kind, raw)
            return {'raw': raw, 'attack': attack, 'training': bases['training'], 'name': bases['name']}
    top = reference_attack(kind, 300, size, power)
    bases = training_bases(kind, 300)
    return {'raw': None, 'attack': top, 'training': None if not bases else bases['training'],
            'name': None if not bases else bases['name']}


def training_to_beat(kind, raw_now, size, power, target):
    if not valid(raw_now, 0, 300) or not valid(target, 0, 10000):
        return None
    current = reference_attack(kind, raw_now, size, power)
    if current is not None and current > target:
        return None
    step = lowest_training_to_beat(kind, size, power, target)
    if not step or step.get('raw') is None:
        return step
    return step if step['raw'] > raw_now else None

def parse_target(text):
    if text is None:
        return None
    raw = str(text).strip().replace(',', '').replace('，', '')
    if not raw:
        return None
    try:
        value = int(float(raw))
    except ValueError:
        return None
    return value if 0 <= value <= 10000 else None


def beats(row, target):
    return valid(target, 0, 10000) and bool(row.get('attack')) and min(row['attack']) > target


def names_of(row):
    return ' / '.join(g.get('name', '?') for g in row.get('generals', []))


def training_need_text(step):
    if not step:
        return ''
    if step.get('raw') is None:
        extra = f'满级参考 {step["attack"]}，' if step.get('attack') is not None else ''
        return f'{extra}现有将与库存规模下无法压过（网站口径，非实伤）'
    if step['raw'] == 0:
        return f'未训即可超过，参考攻击 {step["attack"]}'
    return (f'该编制训练到累计 {step["raw"]}（{step["name"]} {step["training"]}/100）即可超过，'
            f'参考攻击 {step["attack"]}')


def versus_current(target, row, step=None):
    text = f'现状已压过 {target}（部队攻击 {span(row.get("attack") or [])}）'
    need = training_need_text(step)
    return f'{text}。{need}' if need else text


def versus_training(target, row, step):
    now = span(row.get('attack') or [])
    if not step or step.get('raw') is None:
        extra = f'满级参考 {step["attack"]}，' if step and step.get('attack') is not None else ''
        return f'现状 {now} 未过 {target}。{extra}现有将与库存规模下无法压过（网站口径，非实伤）。'
    return (f'现状 {now} 未过 {target}。该编制训练升到累计 {step["raw"]}'
            f'（{step["name"]} {step["training"]}/100），参考攻击 {step["attack"]}')


def pick_styles(rows):
    if not rows:
        return []
    def rank(r):
        return (min(r['attack']), max(r['attack']), len(useful_skills(r['kind'], set(r['skills']))),
                -len(r['ids']), r['power'], r['soldiers'])
    best = max(rows, key=rank)
    near = [r for r in rows if min(r['attack']) >= min(best['attack']) * .8]
    complementary = max(near, key=lambda r: (len(useful_skills(r['kind'], set(r['skills']))), *rank(r), len(r['added'])))
    economical = max(rows, key=lambda r: (min(r['attack']) / len(r['ids']), *rank(r)))
    picked, seen = [], set()
    for label, row in (('攻击优先', best), ('技能互补', complementary), ('省将方案', economical)):
        key = frozenset(row['ids'])
        if key in seen:
            continue
        seen.add(key)
        picked.append(dict(row, label=label, source='current'))
    return picked


def pick_training(rows, raw_now, target):
    scored = []
    for row in rows:
        step = training_to_beat(row['kind'], raw_now, row['size'], row['power'], target)
        if not step:
            continue
        scored.append((step['raw'] is None, step['raw'] if step['raw'] is not None else 999,
                       len(row['ids']), -(step['attack'] or 0), row['ids'], row, step))
    scored.sort()
    picked, seen = [], set()
    for _, raw, _ids, _atk, _key, row, step in scored:
        key = frozenset(row['ids'])
        if key in seen:
            continue
        seen.add(key)
        picked.append(dict(row, label='训练倒推', source='training', training_step=step,
                           versus=versus_training(target, row, step)))
        if len(picked) == 3:
            break
    return picked

def advise_gap(kind, raw_now, row, ceiling, pool):
    if not ceiling:
        return '当前无宣战出场部队，没有压过门槛'
    value, label = ceiling['value'], ceiling['label']
    mine = min(row['attack']) if row.get('attack') else None
    if mine is not None and mine > value:
        return f'已高于敌军最高参考 {value}（{label}）'
    same = training_to_beat(kind, raw_now, row['size'], row['power'], value)
    now = [r for r in pool if r['kind'] == kind and r.get('ids') != row.get('ids')
           and r.get('attack') and min(r['attack']) > value]
    bits = []
    if now:
        pick = min(now, key=lambda r: (len(r['ids']), -min(r['attack'])))
        bits.append(f'当前训练改配 {names_of(pick)}，参考攻击 {span(pick["attack"])}')
    if same and same['raw'] is not None:
        bits.append(f'同编制将训练升到累计 {same["raw"]}（{same["name"]} {same["training"]}/100），参考攻击 {same["attack"]}')
    if not now:
        best = None
        for r in pool:
            if r['kind'] != kind or r.get('ids') == row.get('ids'):
                continue
            step = training_to_beat(kind, raw_now, r['size'], r['power'], value)
            if not step or step['raw'] is None:
                continue
            if same and same['raw'] is not None and step['raw'] >= same['raw']:
                continue
            key = (step['raw'], len(r['ids']), -step['attack'])
            if best is None or key < best[0]:
                best = (key, r, step)
        if best:
            _, pick, step = best
            bits.append(f'改配 {names_of(pick)}，训练升到累计 {step["raw"]}'
                        f'（{step["name"]} {step["training"]}/100），参考攻击 {step["attack"]}')
    if bits:
        return f'未超过敌军最高参考 {value}（{label}）。' + '；'.join(bits) + '。'
    top = same['attack'] if same else None
    extra = f'满级参考 {top}，' if top is not None else ''
    return f'未超过敌军最高参考 {value}（{label}）。{extra}现有将与库存规模下无法压过（网站口径，非实战胜负）。'

def formation(force, kind, generals, bases, known_skills):
    if any(v is None for v in bases['unit']):return None
    capacity = sum(g['soldiers'] for g in generals)
    soldiers = min(capacity, force['troop_stock'][kind])
    if soldiers <= 0:
        return None
    size = size_index(soldiers); power = combat_power(generals)
    if power is None or not 0 <= power <= 150:
        return None
    skills = set().union(*(known_skills[g['general_id_raw']] for g in generals))
    required = REQUIRED[kind]; qualified = required is None or required in skills
    attack = attack_values(bases['unit'][size], power, True)
    siege = attack_values(bases['building'][size], power, qualified)
    lead = generals[0]; leader_power = combat_power([lead])
    leader_size = size_index(min(lead['soldiers'], force['troop_stock'][kind]))
    leader_qualified = required is None or required in known_skills[lead['general_id_raw']]
    baseline = attack_values(bases['unit'][leader_size], leader_power, True)
    added = useful_skills(kind, skills - known_skills[lead['general_id_raw']])
    prestige = force.get('prestige')
    morale = min(100, max(0, prestige / 4 + power / 2)) if valid(prestige, 0, 1000) else None
    returning = [g['name'] for g in generals if g.get('status_code') == 2]
    unknown = [g['name'] for g in generals if officer_metrics(g)['current_diplomacy'] is None]
    notes = []
    if size > leader_size:
        notes.append(SIZES[leader_size] + '→' + SIZES[size])
    notes.append(f'战力 {leader_power}→{power}（{power-leader_power:+d}）')
    notes.append('攻击 ' + span(baseline) + '→' + span(attack))
    if added:
        notes.append('副将补 ' + '/'.join(sorted(added)))
    if capacity > soldiers:
        notes.append('受现有库存限制')
    return {'kind': kind, 'troop': bases['name'], 'generals': generals,
            'ids': tuple(g['general_id_raw'] for g in generals), 'capacity': capacity,
            'soldiers': soldiers, 'size': size, 'power': power, 'morale': morale,
            'attack': attack, 'siege': siege, 'baseline': baseline,
            'leader_power': leader_power, 'leader_size': leader_size,
            'skills': sorted(skills), 'added': sorted(added), 'unknown': unknown,
            'qualified': qualified, 'required': required, 'returning': returning,
            'reason': '；'.join(notes), 'training': bases['training']}

def recommend(state, include_field=True, all_candidates=False, target=None):
    out = {'rows': [], 'force': None, 'message': '', 'eligible': 0, 'enemy': None}
    fid = player_id(state)
    if fid is None:
        out['message'] = '我方身份未确认，暂不推荐'; return out
    if not supported_combat_build(state.get('build_sha256')):
        out['message'] = '客户端版本未匹配，暂不计算攻击推荐'; return out
    entities = state.get('entities', {})
    forces = [f for f in entities.get('lords', []) if f.get('force_id') == fid]
    if len(forces) != 1:
        out['message'] = '我方势力记录缺失或不唯一'; return out
    force = out['force'] = forces[0]
    all_g = entities.get('generals', [])
    counts = Counter(g.get('general_id_raw') for g in all_g)
    deployed = {gid for u in entities.get('field_units', []) for gid in u.get('general_ids', []) if gid is not None}
    pool = [g for g in all_g if g.get('owner_raw') == fid
            and valid(g.get('general_id_raw')) and counts[g['general_id_raw']] == 1
            and g.get('status_code') in ((0, 2) if include_field else (0,))
            and (include_field or g['general_id_raw'] not in deployed)
            and valid(g.get('soldiers'), 1) and combat_power([g]) is not None]
    # Include field occupancy even when a transient status byte says otherwise.
    pool = [dict(g, status_code=2) if g['general_id_raw'] in deployed else g for g in pool]
    pool.sort(key=lambda g: g['general_id_raw'])
    out['eligible'] = len(pool)
    if not pool:
        out['message'] = '没有可计算的所属武将（负伤、身份或统武缺失者不参与）'; return out
    known = {g['general_id_raw']: skills_for(g) for g in pool}
    # Bounded per-kind pool: preserve capacity, combat and skill specialists.
    # Ordinary player rosters are enumerated completely (up to 32 officers).
    out['message'] = '步/骑对部队用网站计算器。弓兵无网站参数，仍用原表基值，暂不列入攻击推荐。'
    parsed = None if all_candidates else parse_target(target)
    pool_by_kind = {}
    for kind in ('infantry', 'cavalry'):
        stock = force.get('troop_stock', {}).get(kind)
        bases = training_bases(kind, force.get('armament_raw', {}).get(kind))
        if not valid(stock, 1) or not bases:
            continue
        candidates = pool
        if len(pool) > 32:
            picked = {}
            for key in (lambda g:g['soldiers'], lambda g:combat_power([g]),
                        lambda g:len(useful_skills(kind, known[g['general_id_raw']]))):
                for g in sorted(pool, key=key, reverse=True)[:10]:picked[g['general_id_raw']] = g
            candidates = list(picked.values())
            out['message'] += ' 武将较多：按带兵、统武和技能筛选候选，非全局穷举最优'
        rows = []
        for n in (1, 2, 3):
            for group in combinations(candidates, n):
                for leader in group:
                    ordered = [leader] + [g for g in group if g is not leader]
                    row = formation(force, kind, ordered, bases, known)
                    if row:rows.append(row)
        if not rows:
            continue
        if all_candidates:
            out['rows'].extend(rows)
            continue
        pool_by_kind[kind] = (rows, force.get('armament_raw', {}).get(kind))
    if all_candidates:
        if not out['rows'] and '库存或训练' not in out['message']:
            out['message'] += ' 当前兵种库存或训练数据不足' if out['message'] else '当前兵种库存或训练数据不足'
        return out
    if parsed is None:
        out['message'] += ' 请填写敌军部队攻击数值。'
        return out
    out['enemy'] = {'value': parsed, 'label': '填写数值'}
    out['message'] += f' 对照填写数值 {parsed}。'
    winners = [r for rows, _raw in pool_by_kind.values() for r in rows if beats(r, parsed)]
    if winners:
        for kind in ('infantry', 'cavalry'):
            for row in pick_styles([r for r in winners if r['kind'] == kind]):
                step = lowest_training_to_beat(row['kind'], row['size'], row['power'], parsed)
                out['rows'].append(dict(row, versus=versus_current(parsed, row, step),
                                        training_step=step))
    else:
        out['message'] += ' 现状压不过，按现有将与编制倒推训练。'
        for kind in ('infantry', 'cavalry'):
            if kind not in pool_by_kind:
                continue
            rows, raw_now = pool_by_kind[kind]
            out['rows'].extend(pick_training(rows, raw_now, parsed))
    if not out['rows'] and '库存或训练' not in out['message']:
        out['message'] += ' 当前兵种库存或训练数据不足'
    return out
