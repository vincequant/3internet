"""Military presentation, using status-window name thresholds (not a combat score)."""
import tkinter as tk
from tkinter import ttk
from state_extensions import training_progress
NAMES={'infantry':('步兵','强化步兵','重装步兵'),'cavalry':('骑兵','强化骑兵','铁骑兵'),'bow':('弓兵','弩兵','连弩')}
COLS=('兵种级别','库存兵数量','每年夏季募兵≈','训练度','攻击基值 小/中/大','练兵效率')
def troop_info(kind,raw):
 t=training_progress(raw)
 if t is None:return {'name':'兵种等级未知','training':None,'tier':None}
 tier=0 if raw<100 else 1 if raw<200 else 2
 return {'name':NAMES[kind][tier],'training':t,'tier':tier}
class MilitarySummary(tk.Frame):
 """Compact current-state table; forecasts belong in the decision support page."""
 def __init__(self,parent):
  super().__init__(parent,bg='#f7f4ea');self.tiles={}
  for col,title in enumerate(COLS):
   tk.Label(self,text=title,bg='#eee9d9',fg='#756443',font=('Microsoft YaHei',10),anchor='w').grid(row=0,column=col,sticky='ew',padx=2,pady=(2,1))
   self.columnconfigure(col,weight=1)
  for row,kind in enumerate(('infantry','cavalry','bow'),1):
   cells=[]
   for col in range(len(COLS)):
    cell=tk.Label(self,bg='#f7f4ea',fg='#302c22',font=('Microsoft YaHei',11,'bold' if col==0 else 'normal'),anchor='w',padx=3,pady=1)
    cell.grid(row=row,column=col,sticky='ew',padx=2);cells.append(cell)
   self.tiles[kind]=cells
  self.note=tk.Label(self,text='练兵效率按库存档位，相对1万以下为100%；9万以上最低50%。百分比乘的是单次训练条，不是兵力。人口帽（约人口/10，最多50000）是每种兵各自的单次上限，不是三兵种抢一笔。还可=该兵种相对帽还能建多少；建练兵所不会减骑/弓还可。未扣断线。',bg='#f7f4ea',fg='#786e56',anchor='w',justify='left',wraplength=720,font=('Microsoft YaHei',9))
  self.note.grid(row=4,column=0,columnspan=len(COLS),sticky='ew',padx=3,pady=3)
  box=tk.Frame(self,bg='#f7f4ea');box.grid(row=5,column=0,columnspan=len(COLS),sticky='ew',padx=3,pady=(0,4))
  self.city_tree=ttk.Treeview(box,columns=('city','cap','infantry','cavalry','bow'),show='headings',height=5)
  for key,title,width in (('city','城市',70),('cap','人口帽',80),('infantry','步 相对帽还可',110),('cavalry','骑 相对帽还可',110),('bow','弓 相对帽还可',110)):
   self.city_tree.heading(key,text=title);self.city_tree.column(key,width=width,stretch=True)
  y=ttk.Scrollbar(box,command=self.city_tree.yview);self.city_tree.configure(yscrollcommand=y.set)
  self.city_tree.pack(side='left',fill='x',expand=True);y.pack(side='right',fill='y')
  self.bind('<Configure>',lambda e:self.note.configure(wraplength=max(180,e.width-10)))
 def update_force(self,force,state=None):
  from recruitment_summary import annual_recruitment,city_recruit_rows,recruitment_text
  from training_prediction import describe_stock_efficiency
  totals=annual_recruitment(state,force.get('force_id'))
  from preparation_model import training_bases
  from unit_target_attack import supported_combat_build
  for kind,cells in self.tiles.items():
   name,count,recruits,training,attack=cells[:5]
   recruits.config(text=recruitment_text(totals[kind]))
   info=troop_info(kind,force.get('armament_raw',{}).get(kind));stock=force.get('troop_stock',{}).get(kind)
   name.config(text=info['name']);count.config(text=f'{stock:,}' if type(stock) is int else '未知')
   training.config(text=f"{info['training']} / 100" if info['training'] is not None else '未知')
   bases=training_bases(kind,force.get('armament_raw',{}).get(kind)) if supported_combat_build((state or {}).get('build_sha256')) else None
   attack.config(text=' / '.join(map(str,bases['unit'])) if bases and all(v is not None for v in bases['unit']) else '缺参数' if bases else '未核定')
   if len(cells)>5:cells[5].config(text=describe_stock_efficiency(stock))
  tree=getattr(self,'city_tree',None)
  if tree is not None:
   tree.delete(*tree.get_children())
   for row in city_recruit_rows(state,force.get('force_id')):
    cap='未知' if row['cap'] is None else f"{row['cap']:,}"
    tree.insert('','end',values=(row['name'],cap,row['cells']['infantry'],row['cells']['cavalry'],row['cells']['bow']))
 def update_prediction(self,state,force):
  # Compatibility for older callers; this summary intentionally shows observed data only.
  pass
