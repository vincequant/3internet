import unittest

from match_opening import archive_label, classify_opening, finalize_opening


def rels(*pairs):
    row = [0] * 22
    for fid, value in pairs:
        row[fid] = value
    return row


def lord(fid, name, *ally):
    return {'force_id': fid, 'name': name, 'diplomacy_relations': rels(*((other, 3) for other in ally))}


class OpeningTests(unittest.TestCase):
    def test_three_allies_vs_three_normals_is_player_3v3(self):
        state = {'entities': {'lords': [
            lord(0, '蜀', 1, 2), lord(1, '吴', 0, 2), lord(2, '魏', 0, 1),
            lord(7, '晋'), lord(8, '楚'), lord(9, '齐'),
        ]}}
        info = classify_opening(state)
        self.assertEqual(info['match_kind'], 'player')
        self.assertEqual(info['format'], '3v3')
        self.assertTrue(info['opening_locked'])
        self.assertIn('玩家局 3v3', info['title'])
        self.assertIn('蜀/吴/魏', info['title'])

    def test_two_alliance_blocs(self):
        state = {'entities': {'lords': [
            lord(0, '蜀', 1), lord(1, '吴', 0),
            lord(7, '晋', 8), lord(8, '楚', 7),
        ]}}
        info = classify_opening(state)
        self.assertEqual(info['format'], '2v2')
        self.assertEqual(info['match_kind'], 'player')

    def test_settled_1v1_without_alliance_is_player(self):
        info = classify_opening({'entities': {'lords': [lord(17, '蜀'), lord(7, '晋')]}})
        self.assertEqual(info['title'], '玩家局 1v1 蜀 vs 晋')
        self.assertTrue(info['opening_locked'])

    def test_full_map_without_alliance_is_unlocked_computer(self):
        lords = [lord(i, f'国{i}') for i in range(22)]
        info = classify_opening({'entities': {'lords': lords}})
        self.assertEqual(info['match_kind'], 'computer')
        self.assertFalse(info['opening_locked'])
        sealed = finalize_opening(info, sealed=True)
        self.assertTrue(sealed['opening_locked'])
        self.assertEqual(sealed['title'], '电脑局 22势力')

    def test_label_uses_title(self):
        text = archive_label({
            'title': '玩家局 1v1 蜀 vs 晋',
            'match_kind': 'player',
            'frame_count': 161,
            'completeness': 'complete',
            'last_capture_end': '2026-09-16T01:48:44+00:00',
        })
        self.assertTrue(text.startswith('玩家局 1v1 蜀 vs 晋'))
        self.assertIn('161帧', text)
        self.assertNotIn('采集 ·', text)


if __name__ == '__main__':
    unittest.main()
