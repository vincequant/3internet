"""Selected-force civil/military commands for the latest three quarters."""
import sys
import tkinter as tk
from pathlib import Path


class QuarterOpsPanel(tk.Frame):
    def __init__(self, parent, app=None):
        super().__init__(parent, bg='#f7f4ea')
        self.app = app
        self.busy = False
        face = getattr(app, 'face', 'PingFang SC') if app is not None else 'PingFang SC'
        tk.Label(self, text='点将看属性，点出征看周边', bg='#f7f4ea', fg='#786e56',
                 anchor='w', font=(face, 11)).pack(fill='x', padx=8, pady=(6, 2))
        self.rows = tk.Frame(self, bg='#f7f4ea')
        self.rows.pack(fill='x', padx=8, pady=(0, 8))

    def update_force(self, force, state=None):
        self._fill_ops(state, (force or {}).get('force_id'))

    def _face(self, size=10, weight='normal'):
        face = getattr(self.app, 'face', None) if self.app is not None else None
        return (face or 'PingFang SC', size, weight)

    def _clear_lane(self, frame):
        for child in frame.winfo_children():
            child.destroy()

    def _quarter(self, label):
        row = tk.Frame(self.rows, bg='#fff8ee', highlightbackground='#d4c7a1',
                       highlightthickness=1)
        row.pack(fill='x', pady=3)
        tk.Label(row, text=label, bg='#e8d6a8', fg='#6b5420',
                 font=self._face(11, 'bold'), padx=8, pady=6,
                 anchor='nw').pack(side='left', fill='y')
        body = tk.Text(row, height=1, width=1, wrap='char', bg='#fff8ee',
                       fg='#302c22', font=self._face(11), relief='flat',
                       borderwidth=0, highlightthickness=0, padx=8, pady=6,
                       cursor='arrow', takefocus=False)
        body.pack(side='left', fill='x', expand=True)
        body.tag_configure('civil', background='#e8d6a8', foreground='#6b5420')
        body.tag_configure('military', background='#cdd8e8', foreground='#1e3f6e')
        body.tag_configure('empty', foreground='#8a8474')
        body.tag_configure('action', foreground='#1e3f6e', underline=True)
        body.bind('<Configure>', lambda _e=None: self._fit_row(body))
        return body

    def _fit_row(self, body):
        if body.winfo_exists():
            lines = body.count('1.0', 'end-1c', 'displaylines')
            height = (lines[0] if lines else 0) + 1
            if int(body.cget('height')) != height:
                body.configure(height=height)

    def _chip(self, frame, text, action=None, kind='plain'):
        # Inline text keeps each quarter compact and wraps without clipping commands.
        tags = [kind]
        if action:
            tag = 'command_' + str(len(frame.tag_names()))
            tags.extend(('action', tag))
            frame.tag_bind(tag, '<Button-1>', lambda _e=None: action())
            frame.tag_bind(tag, '<Enter>', lambda _e=None: frame.configure(cursor='hand2'))
            frame.tag_bind(tag, '<Leave>', lambda _e=None: frame.configure(cursor='arrow'))
        frame.insert('end', str(text), tuple(tags))
        frame.insert('end', '  ')

    def _fill_ops(self, state, force_id):
        from officer_reference import hire_command_text, officer_event_text
        bridge = str(Path(__file__).resolve().parent.parent / 'bridge')
        if bridge not in sys.path:
            sys.path.append(bridge)
        from state_history import military_chip_text, split_quarter_lanes
        self.busy = True
        try:
            self._clear_lane(self.rows)
            lanes = split_quarter_lanes((state or {}).get('history') or {}, force_id, 3)
            if not lanes:
                body = self._quarter('—')
                self._chip(body, '暂无指令', kind='empty')
                body.configure(state='disabled')
                return
            for block in reversed(lanes[:3]):
                body = self._quarter(block.get('short') or '—')
                civil = military = body
                self._chip(body, ' 内政 ', kind='civil')
                civil_ops = block.get('civil') or []
                if not civil_ops:
                    self._chip(civil, '—', kind='empty')
                else:
                    hires = [item for item in civil_ops if item.get('field') == '录用']
                    others = [item for item in civil_ops if item.get('field') != '录用']
                    for item in others:
                        self._chip(civil, item.get('line') or item.get('field') or '')
                    for item in hires:
                        record = self.officer_record(item)
                        line = str(item.get('line') or '')
                        city = record.get('location_city_name')
                        if not city and '：' in line:
                            city = line.split('：', 1)[-1].strip() or None
                        self._chip(civil, hire_command_text(record, city),
                                   lambda it=item: self.open_hire(it), 'hire')
                self._chip(body, ' 军事 ', kind='military')
                military_ops = block.get('military') or []
                if not military_ops:
                    self._chip(military, '—', kind='empty')
                else:
                    for item in military_ops:
                        if item.get('field') == '主动加入':
                            record = self.officer_record(item)
                            line = str(item.get('line') or '')
                            city = record.get('location_city_name')
                            if not city and '：' in line:
                                city = line.split('：', 1)[-1].strip() or None
                            self._chip(military, officer_event_text(record, city, '主动加入'),
                                       lambda it=item: self.open_hire(it), 'join')
                        else:
                            self._chip(military, military_chip_text(item),
                                       lambda it=item: self.locate_op(it), 'unit')
                body.configure(state='disabled')
                body.after_idle(lambda box=body: self._fit_row(box))
        finally:
            self.busy = False

    def officer_record(self, item):
        state = getattr(self.app, 'doc', None) or {} if self.app is not None else {}
        gid = (item.get('target') or {}).get('general_id') or item.get('general_id')
        name = item.get('after')
        gens = (state.get('entities') or {}).get('generals') or []
        record = None
        if gid is not None:
            hits = [row for row in gens if row.get('general_id_raw') == gid]
            if len(hits) == 1:
                record = hits[0]
        if record is None and name:
            hits = [row for row in gens if row.get('name') == name]
            if len(hits) == 1:
                record = hits[0]
        if record is None:
            record = {'name': name, 'general_id_raw': gid, 'attributes': {}}
        if not record.get('location_city_name') and record.get('location_city_id') is not None:
            cities = (state.get('entities') or {}).get('cities_and_barriers') or []
            city = next((row for row in cities if row.get('city_id') == record.get('location_city_id')), None)
            if city:
                record = {**record, 'location_city_name': city.get('name')}
        return record

    def open_hire(self, item):
        if self.app is None:
            return
        from original_art_panel import open_officer_record
        open_officer_record(self.app, self.officer_record(item))

    def locate_op(self, item=None):
        if self.busy or self.app is None or not item:
            return
        target = item.get('target') or {}
        state = getattr(self.app, 'doc', None) or {}
        entities = state.get('entities') or {}
        if target.get('kind') == 'field_units' and target.get('unit_id') is not None:
            match = [row for row in entities.get('field_units') or [] if row.get('unit_id') == target.get('unit_id')]
            if len(match) == 1:
                self.app.locate_object('force_units', match[0])
                return
        if target.get('kind') == 'cities_and_barriers' and target.get('city_id') is not None:
            match = [row for row in entities.get('cities_and_barriers') or [] if row.get('city_id') == target.get('city_id')]
            if len(match) == 1:
                self.app.locate_object('cities', match[0])
