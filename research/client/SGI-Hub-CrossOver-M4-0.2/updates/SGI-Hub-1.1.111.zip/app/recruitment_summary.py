"""Conditional annual summer recruitment from already capped city getters.

Engine 0x434df9/0x434e8d/0x434f21 each sum one camp type then min with
0x434fb5. Remain is per-kind slack vs that same numeric ceiling, not
one city-wide pool: building parade grounds does not reduce cavalry/bow slack.
"""
KINDS=('infantry','cavalry','bow')
KIND_LABEL={'infantry':'步','cavalry':'骑','bow':'弓'}
BUILDING_KINDS={'parade_ground':'infantry','horse_farm':'cavalry','bow_studio':'bow'}

def population_cap(population):
 if type(population) is not int or population<0:return None
 return 0 if population<50000 else min(((population+50)//100)*10,50000)

def building_sums(state,city_id):
 totals=dict.fromkeys(KINDS,0)
 for building in (state or {}).get('entities',{}).get('production_buildings') or []:
  kind=BUILDING_KINDS.get(building.get('type'))
  if kind and building.get('linked_city_id')==city_id and type(building.get('building_ui_amount')) is int:
   totals[kind]+=building['building_ui_amount']
 return totals

def format_recruit_cell(built,cap):
 # remain = this kind's camps vs population cap; other kinds do not consume it
 if cap is None:return '帽未知'
 if type(built) is not int:return '未采集'
 slack=cap-built
 if slack>=0:return f'{slack:,}'
 return f'溢{-slack:,}'

def format_recruit_display(built,cap):
 remain=format_recruit_cell(built,cap)
 if type(built) is not int:
  return remain
 return f'{remain} · 已建{built:,}'

def city_recruit_rows(state,force_id):
 # cells[kind] = cap - built[kind]; kinds do not share remaining quota
 cities=[c for c in (state or {}).get('entities',{}).get('cities_and_barriers',[]) if c.get('type')=='city' and c.get('owner_raw')==force_id]
 rows=[]
 for city in cities:
  cap=(city.get('recruitment_capacity') or {}).get('population_cap')
  if cap is None:cap=population_cap(city.get('population'))
  built=building_sums(state,city.get('city_id'))
  rows.append({'name':city.get('name') or '?','cap':cap,'built':built,
               'cells':{k:format_recruit_cell(built[k],cap) for k in KINDS}})
 return rows
def annual_recruitment(state,force_id):
 all_cities=(state or {}).get('entities',{}).get('cities_and_barriers')
 if not isinstance(all_cities,list) or force_id is None:return {k:{'known':0,'missing':1,'cities':0} for k in KINDS}
 cities=[c for c in all_cities if c.get('type')=='city' and c.get('owner_raw')==force_id]
 out={}
 for kind in KINDS:
  values=[(c.get('recruitment_capacity') or {}).get('amounts',{}).get(kind) for c in cities]
  good=[v for v in values if type(v) is int and v>=0]
  out[kind]={'known':sum(good),'missing':len(values)-len(good),'cities':len(cities)}
 return out
def recruitment_text(result):
 if result['missing']:return f"{result['known']:,}＋未知" if result['known'] else '未采集完整'
 return f"≈{result['known']:,}"
