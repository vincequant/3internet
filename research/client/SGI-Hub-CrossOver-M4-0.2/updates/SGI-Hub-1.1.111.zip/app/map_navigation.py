"""Read-only camera movement shared by the two map widgets."""
def move_center(center, dx, dy, step=1, world=(101,202), offset=0):
    return tuple(max(offset,min(world[i]-1+offset,center[i]+d*step))
                 for i,d in enumerate((dx,dy)))

def wheel_direction(delta):
    try:
        value = float(delta)
    except (TypeError, ValueError):
        return 0
    if value == 0:
        return 0
    return 1 if value > 0 else -1

def bind_pointer_wheel(widget, handler):
    """Mac Tk sends the wheel to the focused widget; grab it while the pointer is on the map."""
    def on_wheel(event):
        try:
            sx = int(event.x_root) - widget.winfo_rootx()
            sy = int(event.y_root) - widget.winfo_rooty()
        except Exception:
            return
        if not (0 <= sx < max(1, widget.winfo_width()) and 0 <= sy < max(1, widget.winfo_height())):
            return
        handler(event, sx, sy)
        return 'break'

    def on_button(event, delta):
        event.delta = delta
        return on_wheel(event)

    def grab(_=None):
        try:
            widget.focus_set()
        except Exception:
            pass
        widget.bind_all('<MouseWheel>', on_wheel)
        widget.bind_all('<Shift-MouseWheel>', on_wheel)
        widget.bind_all('<Button-4>', lambda e: on_button(e, 1))
        widget.bind_all('<Button-5>', lambda e: on_button(e, -1))

    def release(_=None):
        widget.unbind_all('<MouseWheel>')
        widget.unbind_all('<Shift-MouseWheel>')
        widget.unbind_all('<Button-4>')
        widget.unbind_all('<Button-5>')

    widget.bind('<Enter>', grab)
    widget.bind('<Leave>', release)
    widget.bind('<MouseWheel>', on_wheel)
    widget.bind('<Button-4>', lambda e: on_button(e, 1))
    widget.bind('<Button-5>', lambda e: on_button(e, -1))

def navigation_bar(parent, move, reset):
    from tkinter import ttk
    bar=ttk.Frame(parent)
    for label,dx,dy in [('↑',0,-1),('↓',0,1),('←',-1,0),('→',1,0)]:
        ttk.Button(bar,text=label,width=3,command=lambda x=dx,y=dy:move(x,y)).pack(side='left')
    ttk.Button(bar,text='回到定位',command=reset).pack(side='left',padx=4)
    return bar

def bind_arrows(canvas, move):
    for key,dx,dy in [('Up',0,-1),('Down',0,1),('Left',-1,0),('Right',1,0)]:
        def handler(event,x=dx,y=dy):move(x,y);return 'break'
        canvas.bind('<'+key+'>',handler)
    canvas.bind('<Button-1>',lambda event:canvas.focus_set(),add='+')
