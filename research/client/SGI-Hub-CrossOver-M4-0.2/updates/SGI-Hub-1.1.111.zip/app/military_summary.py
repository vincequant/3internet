"""Military presentation, using status-window name thresholds (not a combat score)."""
import tkinter as tk
from tkinter import ttk
from state_extensions import training_progress
NAMES={'infantry':('步兵','强化步兵','重装步兵'),'cavalry':('骑兵','强化骑兵','铁骑兵'),'bow':('弓兵','弩兵','连弩')}
COLS=('兵种级别','库存兵数量','每年夏季募兵≈','训练度','攻击基值 小/中/大','练兵效率')
def troop_info(kind,raw):
 t=training_progress(raw)
 if t is None:return {'name':'兵种等级未知','training':None,'tier':None}
 tier=0 if raw<100 else 1 if raw<200 else 2
 return {'name':NAMES[kind][tier],'training':t,'tier':tier}
class MilitarySummary(tk.Frame):
 """Compact current-state table; forecasts belong in the decision support page."""
 def __init__(self,parent,app=None):
  super().__init__(parent,bg='#f7f4ea');self.app=app;self.tiles={};self.busy=False;self.op_rows={}
  face=getattr(app,'face','PingFang SC') if app is not None else 'PingFang SC'
  for col,title in enumerate(COLS):
   tk.Label(self,text=title,bg='#eee9d9',fg='#756443',font=(face,10),anchor='w').grid(row=0,column=col,sticky='ew',padx=2,pady=(2,1))
   self.columnconfigure(col,weight=1)
  for row,kind in enumerate(('infantry','cavalry','bow'),1):
   cells=[]
   for col in range(len(COLS)):
    cell=tk.Label(self,bg='#f7f4ea',fg='#302c22',font=(face,11,'bold' if col==0 else 'normal'),anchor='w',padx=3,pady=1)
    cell.grid(row=row,column=col,sticky='ew',padx=2);cells.append(cell)
   self.tiles[kind]=cells
  self.note=tk.Label(self,text='还可＝人口帽−该种兵营已建。帽是同一个上限，不是三兵种分一笔；练兵所只减步兵还可。',bg='#f4df96',fg='#6b3f12',anchor='w',justify='left',wraplength=720,font=(face,13,'bold'))
  self.note.grid(row=4,column=0,columnspan=len(COLS),sticky='ew',padx=3,pady=(6,4))
  box=tk.Frame(self,bg='#f7f4ea');box.grid(row=5,column=0,columnspan=len(COLS),sticky='ew',padx=3,pady=(0,6))
  style=ttk.Style()
  style.configure('SGIRecruit.Treeview',font=(face,13),rowheight=30,background='#f7f4ea',fieldbackground='#fff8ee')
  style.configure('SGIRecruit.Treeview.Heading',font=(face,12,'bold'))
  self.city_tree=ttk.Treeview(box,columns=('city','cap','infantry','cavalry','bow'),show='headings',height=4,style='SGIRecruit.Treeview')
  for key,title,width in (('city','城市',80),('cap','人口帽',90),('infantry','步还可 / 已建',150),('cavalry','骑还可 / 已建',150),('bow','弓还可 / 已建',150)):
   self.city_tree.heading(key,text=title);self.city_tree.column(key,width=width,stretch=True,anchor='center')
  y=ttk.Scrollbar(box,command=self.city_tree.yview);self.city_tree.configure(yscrollcommand=y.set)
  self.city_tree.pack(side='left',fill='x',expand=True);y.pack(side='right',fill='y')
  self.ops_note=tk.Label(self,text='点将看属性，点出征看周边',bg='#f7f4ea',fg='#786e56',anchor='w',font=(face,12))
  self.ops_note.grid(row=6,column=0,columnspan=len(COLS),sticky='ew',padx=3,pady=(8,4))
  ops_box=tk.Frame(self,bg='#f7f4ea');ops_box.grid(row=7,column=0,columnspan=len(COLS),sticky='nsew',padx=3,pady=(0,8))
  self.rowconfigure(7,weight=1,minsize=320)
  self.civil_lane=tk.Frame(ops_box,bg='#f3efe2',highlightbackground='#d4c7a1',highlightthickness=1)
  self.civil_lane.pack(fill='both',expand=True,pady=(0,10))
  self.military_lane=tk.Frame(ops_box,bg='#eef2f6',highlightbackground='#b7c4d4',highlightthickness=1)
  self.military_lane.pack(fill='both',expand=True)
  self.ops_tree=None
  self.bind('<Configure>',lambda e:self.note.configure(wraplength=max(180,e.width-10)))
 def update_force(self,force,state=None):
  from recruitment_summary import annual_recruitment,city_recruit_rows,format_recruit_display,recruitment_text
  from training_prediction import describe_stock_efficiency
  totals=annual_recruitment(state,force.get('force_id'))
  from preparation_model import training_bases
  from unit_target_attack import supported_combat_build
  for kind,cells in self.tiles.items():
   name,count,recruits,training,attack=cells[:5]
   recruits.config(text=recruitment_text(totals[kind]))
   info=troop_info(kind,force.get('armament_raw',{}).get(kind));stock=force.get('troop_stock',{}).get(kind)
   name.config(text=info['name']);count.config(text=f'{stock:,}' if type(stock) is int else '未知')
   training.config(text=f"{info['training']} / 100" if info['training'] is not None else '未知')
   bases=training_bases(kind,force.get('armament_raw',{}).get(kind)) if supported_combat_build((state or {}).get('build_sha256')) else None
   attack.config(text=' / '.join(map(str,bases['unit'])) if bases and all(v is not None for v in bases['unit']) else '缺参数' if bases else '未核定')
   if len(cells)>5:cells[5].config(text=describe_stock_efficiency(stock))
  tree=getattr(self,'city_tree',None)
  if tree is not None:
   tree.delete(*tree.get_children())
   for row in city_recruit_rows(state,force.get('force_id')):
    cap='未知' if row['cap'] is None else f"{row['cap']:,}"
    built=row.get('built') or {}
    tree.insert('','end',values=(row['name'],cap,format_recruit_display(built.get('infantry'),row['cap']),format_recruit_display(built.get('cavalry'),row['cap']),format_recruit_display(built.get('bow'),row['cap'])))
  if getattr(self,'civil_lane',None) is not None:
   self._fill_ops(state,force.get('force_id'))
 def _face(self,size=10,weight='normal'):
  face=getattr(self.app,'face',None) if self.app is not None else None
  return (face or 'PingFang SC',size,weight)
 def _clear_lane(self,frame):
  for child in frame.winfo_children():
   child.destroy()
 def _prepare_lane(self,frame,label,tone):
  self._clear_lane(frame)
  frame.columnconfigure(0,minsize=96)
  for col in (1,2,3):
   frame.columnconfigure(col,weight=1,uniform='quarter')
  frame.rowconfigure(0,weight=1)
  bg='#e8d6a8' if tone=='civil' else '#cdd8e8'
  fg='#6b5420' if tone=='civil' else '#1e3f6e'
  tk.Label(frame,text=label,bg=bg,fg=fg,font=self._face(15,'bold'),padx=14,pady=22).grid(row=0,column=0,sticky='nsew',padx=8,pady=10)
 def _quarter(self,frame,col,label,tone='civil'):
  paper='#fff8ee' if tone=='civil' else '#f4f7fb'
  bar='#e8d6a8' if tone=='civil' else '#cdd8e8'
  ink='#6b5420' if tone=='civil' else '#1e3f6e'
  edge='#c9b27a' if tone=='civil' else '#8fa4bc'
  card=tk.Frame(frame,bg=paper,highlightbackground=edge,highlightthickness=1)
  card.grid(row=0,column=col,sticky='nsew',padx=8,pady=10)
  tk.Label(card,text=label,bg=bar,fg=ink,font=self._face(15,'bold'),padx=12,pady=8,anchor='w').pack(fill='x')
  body=tk.Frame(card,bg=paper);body.pack(fill='both',expand=True,padx=10,pady=10)
  def fit(event,box=body):
   width=max(160,event.width-12)
   for child in box.winfo_children():
    if isinstance(child,tk.Label):
     child.configure(wraplength=width)
  body.bind('<Configure>',fit)
  return body
 def _chip(self,frame,text,action=None,kind='plain'):
  colors={'hire':('#f3e2b0','#6b3f12'),'unit':('#d9e4f2','#1e3f6e'),'plain':('#fff8ee','#302c22'),'empty':('#efeae0','#8a8474')}
  bg,fg=colors.get(kind,colors['plain'])
  lab=tk.Label(frame,text=text,bg=bg,fg=fg,font=self._face(15,'bold' if action else 'normal'),padx=10,pady=8,cursor='hand2' if action else 'arrow',anchor='w',justify='left',wraplength=220)
  if action:lab.bind('<Button-1>',lambda _e:action())
  lab.pack(fill='x',padx=2,pady=4)
 def _fill_ops(self,state,force_id):
  import sys
  from pathlib import Path
  from officer_reference import officer_title
  bridge=str(Path(__file__).resolve().parent.parent/'bridge')
  if bridge not in sys.path:
   sys.path.append(bridge)
  from state_history import military_chip_text, split_quarter_lanes
  if self.app is not None:
   self.ops_note.configure(font=self._face(12))
   self.note.configure(font=self._face(13,'bold'))
  self.busy=True
  try:
   self._prepare_lane(self.civil_lane,'内政','civil')
   self._prepare_lane(self.military_lane,'军事','military')
   lanes=split_quarter_lanes((state or {}).get('history') or {},force_id,3)
   if not lanes:
    self._chip(self._quarter(self.civil_lane,1,'—','civil'),'—',kind='empty')
    self._chip(self._quarter(self.military_lane,1,'—','military'),'—',kind='empty')
    return
   for index,block in enumerate(lanes[:3],1):
    civil=self._quarter(self.civil_lane,index,block.get('short') or '—','civil')
    military=self._quarter(self.military_lane,index,block.get('short') or '—','military')
    civil_ops=block.get('civil') or []
    if not civil_ops:
     self._chip(civil,'—',kind='empty')
    else:
     hires=[item for item in civil_ops if item.get('field')=='录用']
     others=[item for item in civil_ops if item.get('field')!='录用']
     for item in others:
      self._chip(civil,item.get('line') or item.get('field') or '')
     for item in hires:
      self._chip(civil,officer_title(self.officer_record(item)),lambda it=item:self.open_hire(it),'hire')
    military_ops=block.get('military') or []
    if not military_ops:
     self._chip(military,'—',kind='empty')
    else:
     for item in military_ops:
      self._chip(military,military_chip_text(item),lambda it=item:self.locate_op(it),'unit')
  finally:
   self.busy=False
 def officer_record(self,item):
  state=getattr(self.app,'doc',None) or {} if self.app is not None else {}
  gid=(item.get('target') or {}).get('general_id') or item.get('general_id')
  name=item.get('after')
  gens=(state.get('entities') or {}).get('generals') or []
  record=None
  if gid is not None:
   hits=[row for row in gens if row.get('general_id_raw')==gid]
   if len(hits)==1:record=hits[0]
  if record is None and name:
   hits=[row for row in gens if row.get('name')==name]
   if len(hits)==1:record=hits[0]
  if record is None:
   record={'name':name,'general_id_raw':gid,'attributes':{}}
  if not record.get('location_city_name') and record.get('location_city_id') is not None:
   cities=(state.get('entities') or {}).get('cities_and_barriers') or []
   city=next((row for row in cities if row.get('city_id')==record.get('location_city_id')),None)
   if city:record={**record,'location_city_name':city.get('name')}
  return record
 def open_hire(self,item):
  if self.app is None:return
  from original_art_panel import open_officer_record
  open_officer_record(self.app,self.officer_record(item))
 def locate_op(self,item=None):
  if self.busy or self.app is None or not item:return
  target=item.get('target') or {}
  state=getattr(self.app,'doc',None) or {}
  entities=state.get('entities') or {}
  if target.get('kind')=='field_units' and target.get('unit_id') is not None:
   match=[row for row in entities.get('field_units') or [] if row.get('unit_id')==target.get('unit_id')]
   if len(match)==1:self.app.locate_object('force_units',match[0]);return
  if target.get('kind')=='cities_and_barriers' and target.get('city_id') is not None:
   match=[row for row in entities.get('cities_and_barriers') or [] if row.get('city_id')==target.get('city_id')]
   if len(match)==1:self.app.locate_object('cities',match[0]);return
 def update_prediction(self,state,force):
  # Compatibility for older callers; this summary intentionally shows observed data only.
  pass
