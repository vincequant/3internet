from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class HubTabs(unittest.TestCase):
    def test_force_page_keeps_right_notebook(self):
        text = (ROOT / 'app' / 'omni_window.py').read_text(encoding='utf-8')
        self.assertIn('self.book=ttk.Notebook(right)', text)
        self.assertIn("workspace.add(self.global_page,text='武将资料')", text)
        self.assertIn("self.book.add(overview,text='库存募兵')", text)
        self.assertIn('self.book.add(self.preparation', text)
        self.assertNotIn('self.book=self.workspace', text)
        self.assertNotIn('def _arrange_workspace_tabs', text)
        self.assertIn('前10五维均', text)
        self.assertIn('atk_inf', text)
        self.assertIn("'步 还可'", (ROOT / 'app' / 'military_summary.py').read_text(encoding='utf-8'))
