"""Dedicated Hub tab: pick a lord, sortie city and troop kind, step turns on the MBM map."""
import tkinter as tk
from panorama_map import PanoramaMap
from player_view import player_id
from panorama_model import capital_marks, world_xy
from stealth_raid import (
    KIND_CHOICES, _dest_city_row, cell_walkable, city_ring_cell, format_raid_brief, kind_spec,
    own_cities, plan_stealth_raid, raid_targets,
)

BG = '#1b1d18'
INK = '#efe7cf'
MUTED = '#b7ad8f'
BAR = '#2a2c24'
WELL = '#22241d'


class StealthRaidPage(tk.Frame):
    def __init__(self, parent, app=None):
        super().__init__(parent, bg=BG)
        self.app = app
        self.rows = []
        self.cities = []
        self._sig = None
        self.kind = '骑兵'
        self.plan = None
        self.sim_turn = 0
        self.origin_city = None
        self.origin_cell = None
        self.dest_row = None
        self._user_city = False
        self._filling = False
        face = getattr(app, 'face', None)
        self.hint = tk.StringVar(value='这张图就是全景。点目标君主，再点己方城周边一格放下部队，下一回按路计数。')
        tk.Label(
            self, textvariable=self.hint, bg=BAR, fg='#e4c56a', anchor='w',
            justify='left', font=(face, 11), wraplength=980,
        ).pack(fill='x', padx=8, pady=(8, 4))
        body = tk.PanedWindow(
            self, orient='horizontal', sashwidth=8, bg='#3d3f34',
            sashrelief='raised', opaqueresize=False,
        )
        body.pack(fill='both', expand=True)
        self.map = PanoramaMap(body, title='偷袭主城', mode='raid')
        self.map.on_pick_origin = self._from_map_city
        self.map.on_pick_cell = self._from_map_cell
        side = tk.Frame(body, bg=WELL, width=360)
        body.add(self.map, stretch='always', minsize=420)
        body.add(side, stretch='never', minsize=300)
        tk.Label(side, text='目标君主', bg=WELL, fg=INK, anchor='w', font=(face, 12, 'bold')).pack(fill='x', padx=10, pady=(10, 2))
        self.lords = tk.Listbox(
            side, bg='#2c2f26', fg=INK, selectbackground='#6a5520',
            font=(face, 11), relief='flat', height=8,
        )
        self.lords.pack(fill='x', padx=10, pady=(0, 6))
        self.lords.bind('<<ListboxSelect>>', self._pick_lord)
        tk.Label(side, text='出兵城', bg=WELL, fg=INK, anchor='w', font=(face, 12, 'bold')).pack(fill='x', padx=10, pady=(4, 2))
        self.city_list = tk.Listbox(
            side, bg='#2c2f26', fg=INK, selectbackground='#6a5520',
            font=(face, 11), relief='flat', height=6,
        )
        self.city_list.pack(fill='x', padx=10, pady=(0, 6))
        self.city_list.bind('<<ListboxSelect>>', self._pick_city)
        tk.Label(side, text='出兵种类', bg=WELL, fg=INK, anchor='w', font=(face, 12, 'bold')).pack(fill='x', padx=10, pady=(4, 2))
        kinds = tk.Frame(side, bg=WELL)
        kinds.pack(fill='x', padx=10, pady=(0, 6))
        self.kind_var = tk.StringVar(value='骑兵')
        for label, _klass in KIND_CHOICES:
            tk.Radiobutton(
                kinds, text=label, value=label, variable=self.kind_var,
                command=self._replan, bg=WELL, fg=INK, selectcolor='#3d3f34',
                activebackground=WELL, activeforeground=INK, font=(face, 11),
            ).pack(side='left', padx=2)
        sim = tk.Frame(side, bg=WELL)
        sim.pack(fill='x', padx=10, pady=(4, 4))
        tk.Button(sim, text='重来', command=self._reset, bg='#e7e0c9', fg='#302c22').pack(side='left')
        tk.Button(sim, text='上一回', command=self._prev, bg='#e7e0c9', fg='#302c22').pack(side='left', padx=6)
        tk.Button(sim, text='下一回', command=self._next, bg='#e7e0c9', fg='#302c22').pack(side='left')
        self.sim_text = tk.StringVar(value='尚未出发')
        tk.Label(
            side, textvariable=self.sim_text, bg=WELL, fg='#ffe27a', anchor='w',
            justify='left', font=(face, 12, 'bold'), wraplength=320,
        ).pack(fill='x', padx=10, pady=(4, 4))
        self.note = tk.Label(
            side, text='', bg=WELL, fg=MUTED, justify='left', anchor='nw',
            font=(face, 10), wraplength=320,
        )
        self.note.pack(fill='x', padx=10, pady=(0, 12))
        side.bind('<Configure>', self._wrap)

    def _wrap(self, event=None):
        width = max(200, (event.width if event else self.note.winfo_width()) - 24)
        self.note.configure(wraplength=width)

    def _lord_line(self, row):
        war = '交战 · ' if row.get('war') else ''
        line = f"{war}{row['force_name']}  {row['city_name']}"
        if row.get('ok') and row.get('turns') is not None:
            line += f"  {row['turns']}回"
            if row.get('origin_name'):
                line += f"  从{row['origin_name']}"
        return line

    def _fill_cities(self, rec_id=None):
        self._filling = True
        try:
            self.city_list.delete(0, 'end')
            city_index = 0
            keep_id = self.origin_city.get('city_id') if self.origin_city else None
            for i, city in enumerate(self.cities):
                mark = ' · 推荐' if rec_id is not None and city.get('city_id') == rec_id else ''
                xy = world_xy(city) or ('?', '?')
                self.city_list.insert('end', f"{city.get('name') or '?'} ({xy[0]},{xy[1]}){mark}")
                if keep_id is not None and city.get('city_id') == keep_id:
                    city_index = i
                elif keep_id is None and rec_id is not None and city.get('city_id') == rec_id:
                    city_index = i
            if self.cities:
                self.city_list.selection_clear(0, 'end')
                self.city_list.selection_set(city_index)
                self.city_list.see(city_index)
                self.origin_city = self.cities[city_index]
        finally:
            self._filling = False

    def refresh(self, state):
        sig = None if not state else (state.get('snapshot_id'), player_id(state))
        self.map.update_state(state, lists=False, immediate=False, refresh_view=False)
        if sig == self._sig and self.rows:
            return
        same_player = (
            self._sig is not None and sig is not None and self._sig[1] == sig[1]
            and player_id(state) is not None and self.rows
        )
        self._sig = sig
        if same_player:
            return
        keep_force = None
        if self.lords.curselection() and self.rows:
            keep_force = self.rows[self.lords.curselection()[0]].get('force_id')
        self._filling = True
        try:
            self.lords.delete(0, 'end')
            self.city_list.delete(0, 'end')
            self.rows = []
            self.cities = []
            if player_id(state) is None:
                self.hint.set('未确认我方。地图仍是全景，确认后即可在城周边放兵。')
                self.note.config(text='先在顶栏确认我方。')
                self.plan = None
                self.map.raid_on = False
                self.map.raid_plan = None
                self.sim_text.set('尚未出发')
                return
            self.rows = raid_targets(state)
            self.cities = own_cities(state)
            if not self.rows:
                self.hint.set('这一帧没有其他势力首都。')
                self.plan = None
                self.map.raid_on = False
                self.map.raid_plan = None
                return
            index = 0
            for i, row in enumerate(self.rows):
                self.lords.insert('end', self._lord_line(row))
                if keep_force is not None and row.get('force_id') == keep_force:
                    index = i
            self.lords.selection_clear(0, 'end')
            self.lords.selection_set(index)
            self.lords.see(index)
        finally:
            self._filling = False
        self._fill_cities()

    def _pick_lord(self, _=None):
        if self._filling:
            return
        selection = self.lords.curselection()
        if selection:
            self._user_city = False
            self._apply_lord(selection[0], replan=True)

    def _pick_city(self, _=None):
        if self._filling:
            return
        selection = self.city_list.curselection()
        if not selection or selection[0] >= len(self.cities):
            return
        self.origin_city = self.cities[selection[0]]
        self.origin_cell = city_ring_cell(self.map.state, self.origin_city, self.map.terrain)
        self._user_city = True
        self._replan()

    def _from_map_cell(self, cell):
        cell = (int(cell[0]), int(cell[1]))
        if not cell_walkable(self.map.state, cell, self.map.terrain):
            self.sim_text.set(f'({cell[0]},{cell[1]}) 不能落脚')
            return
        self.origin_cell = cell
        self._user_city = True
        near = None
        for city in self.cities:
            xy = world_xy(city)
            if xy and max(abs(xy[0] - cell[0]), abs(xy[1] - cell[1])) <= 1:
                near = city
                break
        if near:
            self.origin_city = near
            self._filling = True
            try:
                for i, city in enumerate(self.cities):
                    if city.get('city_id') == near.get('city_id'):
                        self.city_list.selection_clear(0, 'end')
                        self.city_list.selection_set(i)
                        self.city_list.see(i)
                        break
            finally:
                self._filling = False
        self._replan()

    def _from_map_city(self, row):
        if player_id(self.map.state) is None or row.get('owner_raw') != player_id(self.map.state):
            return
        for i, city in enumerate(self.cities):
            if city.get('city_id') == row.get('city_id'):
                self._filling = True
                try:
                    self.city_list.selection_clear(0, 'end')
                    self.city_list.selection_set(i)
                    self.city_list.see(i)
                finally:
                    self._filling = False
                self.origin_city = city
                self.origin_cell = city_ring_cell(self.map.state, city, self.map.terrain)
                self._user_city = True
                self._replan()
                return

    def _apply_lord(self, index, replan=False):
        if index < 0 or index >= len(self.rows):
            return
        row = self.rows[index]
        dest = None
        for mark in capital_marks(self.map.state or {}):
            if mark.get('force_id') == row.get('force_id'):
                dest = _dest_city_row(self.map.state, mark)
                break
        self.dest_row = dest
        if dest is None:
            self.plan = None
            self.sim_text.set('首都未解析')
            return
        if replan and (self.origin_cell or self.origin_city):
            self._replan()
        elif dest is not None:
            self.sim_text.set('点己方城周边一格放下部队')

    def _origin_xy(self):
        if self.origin_cell:
            return tuple(self.origin_cell)
        if self.origin_city:
            ring = city_ring_cell(self.map.state, self.origin_city, self.map.terrain)
            if ring:
                self.origin_cell = ring
                return ring
            return world_xy(self.origin_city)
        return None

    def _replan(self):
        self.kind = self.kind_var.get() or '骑兵'
        spec = kind_spec(self.kind)
        origin = self._origin_xy()
        if origin is None or self.dest_row is None or spec is None:
            self.plan = None
            self.map.raid_on = False
            self.map.raid_plan = None
            self.sim_text.set('点目标君主，再点己方城周边放下部队。')
            return
        self.plan = plan_stealth_raid(
            self.map.state, origin, self.dest_row, self.map.terrain, cavalry=spec,
        )
        city_name = (self.origin_city or {}).get('name')
        placed = f"{city_name}旁" if city_name else f"({origin[0]},{origin[1]})"
        self.plan['origin_name'] = placed
        self.plan['origin_reason'] = f"{self.kind}放在{placed} ({origin[0]},{origin[1]})"
        if self.plan.get('ok'):
            self.plan['brief'] = format_raid_brief(self.plan)
        self.sim_turn = 0
        selection = self.lords.curselection()
        if selection and selection[0] < len(self.rows):
            row = self.rows[selection[0]]
            row['ok'] = bool(self.plan.get('ok'))
            row['turns'] = self.plan.get('arrive_calendar') if self.plan.get('ok') else None
            row['origin_name'] = self.plan.get('origin_name') or ''
            row['plan'] = self.plan
            self._filling = True
            try:
                self.lords.delete(selection[0])
                self.lords.insert(selection[0], self._lord_line(row))
                self.lords.selection_set(selection[0])
            finally:
                self._filling = False
        if self.plan.get('ok'):
            self.hint.set(format_raid_brief(self.plan))
            turns = len(self.plan.get('cavalry_turn_cells') or [])
            self.note.config(
                text=(self.plan.get('detail') or '') + f'\n本兵种全程 {turns} 回（移动力{spec["points"]}）。'
            )
        else:
            self.hint.set(self.plan.get('error') or '算不出这条路。')
            self.note.config(text=self.plan.get('error') or '')
        self._paint_sim()

    def _cells(self):
        if not self.plan or not self.plan.get('ok'):
            return []
        return list(self.plan.get('cavalry_turn_cells') or [])

    def _reset(self):
        self.sim_turn = 0
        self._paint_sim()

    def _next(self):
        cells = self._cells()
        if not cells:
            return
        self.sim_turn = min(len(cells), self.sim_turn + 1)
        self._paint_sim()

    def _prev(self):
        self.sim_turn = max(0, self.sim_turn - 1)
        self._paint_sim()

    def _paint_sim(self):
        cells = self._cells()
        total = len(cells)
        if not self.plan or not self.plan.get('ok'):
            self.sim_text.set('没有可走的路')
            self.map.show_raid(None)
            return
        origin = self.plan['origin']
        if self.sim_turn <= 0:
            cell = origin
            self.sim_text.set(f'尚未出发 · {self.kind}全程 {total} 回 · 移动力{self.plan["cavalry"]["points"]}')
        elif self.sim_turn >= total:
            self.sim_turn = total
            cell = cells[-1]
            self.sim_text.set(f'第 {total}/{total} 回抵达邻格 · 停 ({cell[0]},{cell[1]})')
        else:
            cell = cells[self.sim_turn - 1]
            self.sim_text.set(f'第 {self.sim_turn}/{total} 回 · 停 ({cell[0]},{cell[1]})')
        if self.sim_turn > 0 and cell:
            self.map.center = (cell[0] + 0.5, cell[1] + 0.5)
        self.map.show_raid(self.plan, sim_cell=cell, immediate=True)
