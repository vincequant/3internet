"""Selected-force civil/military commands for the latest three quarters."""
import sys
import tkinter as tk
from pathlib import Path


class QuarterOpsPanel(tk.Frame):
    def __init__(self, parent, app=None):
        super().__init__(parent, bg='#f7f4ea')
        self.app = app
        self.busy = False
        face = getattr(app, 'face', 'PingFang SC') if app is not None else 'PingFang SC'
        tk.Label(self, text='点将看属性，点出征看周边', bg='#f7f4ea', fg='#786e56',
                 anchor='w', font=(face, 11)).pack(fill='x', padx=8, pady=(6, 2))
        self.civil_lane = tk.Frame(self, bg='#f3efe2', highlightbackground='#d4c7a1', highlightthickness=1)
        self.civil_lane.pack(fill='both', expand=True, padx=8, pady=(0, 10))
        self.military_lane = tk.Frame(self, bg='#eef2f6', highlightbackground='#b7c4d4', highlightthickness=1)
        self.military_lane.pack(fill='both', expand=True, padx=8, pady=(0, 8))

    def update_force(self, force, state=None):
        self._fill_ops(state, (force or {}).get('force_id'))

    def _face(self, size=10, weight='normal'):
        face = getattr(self.app, 'face', None) if self.app is not None else None
        return (face or 'PingFang SC', size, weight)

    def _clear_lane(self, frame):
        for child in frame.winfo_children():
            child.destroy()

    def _prepare_lane(self, frame, label, tone):
        self._clear_lane(frame)
        frame.columnconfigure(0, minsize=72)
        for col in (1, 2, 3):
            frame.columnconfigure(col, weight=1, uniform='quarter')
        frame.rowconfigure(0, weight=1)
        bg = '#e8d6a8' if tone == 'civil' else '#cdd8e8'
        fg = '#6b5420' if tone == 'civil' else '#1e3f6e'
        tk.Label(frame, text=label, bg=bg, fg=fg, font=self._face(12, 'bold'),
                 padx=10, pady=12).grid(row=0, column=0, sticky='nsew', padx=6, pady=6)

    def _quarter(self, frame, col, label, tone='civil'):
        paper = '#fff8ee' if tone == 'civil' else '#f4f7fb'
        bar = '#e8d6a8' if tone == 'civil' else '#cdd8e8'
        ink = '#6b5420' if tone == 'civil' else '#1e3f6e'
        edge = '#c9b27a' if tone == 'civil' else '#8fa4bc'
        card = tk.Frame(frame, bg=paper, highlightbackground=edge, highlightthickness=1)
        card.grid(row=0, column=col, sticky='nsew', padx=6, pady=6)
        tk.Label(card, text=label, bg=bar, fg=ink, font=self._face(11, 'bold'),
                 padx=8, pady=4, anchor='w').pack(fill='x')
        body = tk.Frame(card, bg=paper)
        body.pack(fill='both', expand=True, padx=8, pady=8)

        def fit(event, box=body):
            width = max(180, event.width - 16)
            for child in box.winfo_children():
                if isinstance(child, tk.Label):
                    child.configure(wraplength=width)
        body.bind('<Configure>', fit)
        return body

    def _chip(self, frame, text, action=None, kind='plain'):
        colors = {
            'hire': ('#f3e2b0', '#6b3f12'),
            'join': ('#dce8dc', '#2d5a38'),
            'unit': ('#d9e4f2', '#1e3f6e'),
            'plain': ('#fff8ee', '#302c22'),
            'empty': ('#efeae0', '#8a8474'),
        }
        bg, fg = colors.get(kind, colors['plain'])
        lab = tk.Label(frame, text=text, bg=bg, fg=fg,
                       font=self._face(11, 'bold' if action else 'normal'),
                       padx=8, pady=4, cursor='hand2' if action else 'arrow',
                       anchor='w', justify='left', wraplength=240)
        if action:
            lab.bind('<Button-1>', lambda _e: action())
        lab.pack(fill='x', padx=2, pady=3)

    def _fill_ops(self, state, force_id):
        from officer_reference import hire_command_text, officer_event_text
        bridge = str(Path(__file__).resolve().parent.parent / 'bridge')
        if bridge not in sys.path:
            sys.path.append(bridge)
        from state_history import military_chip_text, split_quarter_lanes
        self.busy = True
        try:
            self._prepare_lane(self.civil_lane, '内政', 'civil')
            self._prepare_lane(self.military_lane, '军事', 'military')
            lanes = split_quarter_lanes((state or {}).get('history') or {}, force_id, 3)
            if not lanes:
                self._chip(self._quarter(self.civil_lane, 1, '—', 'civil'), '—', kind='empty')
                self._chip(self._quarter(self.military_lane, 1, '—', 'military'), '—', kind='empty')
                return
            for index, block in enumerate(lanes[:3], 1):
                civil = self._quarter(self.civil_lane, index, block.get('short') or '—', 'civil')
                military = self._quarter(self.military_lane, index, block.get('short') or '—', 'military')
                civil_ops = block.get('civil') or []
                if not civil_ops:
                    self._chip(civil, '—', kind='empty')
                else:
                    hires = [item for item in civil_ops if item.get('field') == '录用']
                    others = [item for item in civil_ops if item.get('field') != '录用']
                    for item in others:
                        self._chip(civil, item.get('line') or item.get('field') or '')
                    for item in hires:
                        record = self.officer_record(item)
                        line = str(item.get('line') or '')
                        city = record.get('location_city_name')
                        if not city and '：' in line:
                            city = line.split('：', 1)[-1].strip() or None
                        self._chip(civil, hire_command_text(record, city),
                                   lambda it=item: self.open_hire(it), 'hire')
                military_ops = block.get('military') or []
                if not military_ops:
                    self._chip(military, '—', kind='empty')
                else:
                    for item in military_ops:
                        if item.get('field') == '主动加入':
                            record = self.officer_record(item)
                            line = str(item.get('line') or '')
                            city = record.get('location_city_name')
                            if not city and '：' in line:
                                city = line.split('：', 1)[-1].strip() or None
                            self._chip(military, officer_event_text(record, city, '主动加入'),
                                       lambda it=item: self.open_hire(it), 'join')
                        else:
                            self._chip(military, military_chip_text(item),
                                       lambda it=item: self.locate_op(it), 'unit')
        finally:
            self.busy = False

    def officer_record(self, item):
        state = getattr(self.app, 'doc', None) or {} if self.app is not None else {}
        gid = (item.get('target') or {}).get('general_id') or item.get('general_id')
        name = item.get('after')
        gens = (state.get('entities') or {}).get('generals') or []
        record = None
        if gid is not None:
            hits = [row for row in gens if row.get('general_id_raw') == gid]
            if len(hits) == 1:
                record = hits[0]
        if record is None and name:
            hits = [row for row in gens if row.get('name') == name]
            if len(hits) == 1:
                record = hits[0]
        if record is None:
            record = {'name': name, 'general_id_raw': gid, 'attributes': {}}
        if not record.get('location_city_name') and record.get('location_city_id') is not None:
            cities = (state.get('entities') or {}).get('cities_and_barriers') or []
            city = next((row for row in cities if row.get('city_id') == record.get('location_city_id')), None)
            if city:
                record = {**record, 'location_city_name': city.get('name')}
        return record

    def open_hire(self, item):
        if self.app is None:
            return
        from original_art_panel import open_officer_record
        open_officer_record(self.app, self.officer_record(item))

    def locate_op(self, item=None):
        if self.busy or self.app is None or not item:
            return
        target = item.get('target') or {}
        state = getattr(self.app, 'doc', None) or {}
        entities = state.get('entities') or {}
        if target.get('kind') == 'field_units' and target.get('unit_id') is not None:
            match = [row for row in entities.get('field_units') or [] if row.get('unit_id') == target.get('unit_id')]
            if len(match) == 1:
                self.app.locate_object('force_units', match[0])
                return
        if target.get('kind') == 'cities_and_barriers' and target.get('city_id') is not None:
            match = [row for row in entities.get('cities_and_barriers') or [] if row.get('city_id') == target.get('city_id')]
            if len(match) == 1:
                self.app.locate_object('cities', match[0])
