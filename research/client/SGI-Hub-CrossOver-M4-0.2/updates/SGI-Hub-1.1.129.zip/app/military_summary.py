"""Force stock and training cards. City remain lives on the 城关 tab."""
import tkinter as tk
from state_extensions import training_progress
from preparation_model import GRADE_FG

NAMES={'infantry':('步兵','强化步兵','重装步兵'),'cavalry':('骑兵','强化骑兵','铁骑兵'),'bow':('弓兵','弩兵','连弩')}
KIND_META=(
 ('infantry','步','#efe6d0','#8a6a2a'),
 ('cavalry','骑','#f3e2c4','#8a4e1a'),
 ('bow','弓','#e4ead6','#3f5a2c'),
)
COLS=('兵种级别','库存兵数量','每年夏季募兵≈','训练度','攻击基值 小/中/大','练兵效率')
WELL='#f7f4ea'
INK='#302c22'
MUTED='#756443'

def troop_info(kind,raw):
 t=training_progress(raw)
 if t is None:return {'name':'兵种等级未知','training':None,'tier':None}
 tier=0 if raw<100 else 1 if raw<200 else 2
 return {'name':NAMES[kind][tier],'training':t,'tier':tier}

class MilitarySummary(tk.Frame):
 """Full-page stock cards; city remain is listed under 城关."""
 def __init__(self,parent,app=None):
  super().__init__(parent,bg=WELL);self.app=app;self.tiles={};self.busy=False
  face=getattr(app,'face','PingFang SC') if app is not None else 'PingFang SC'
  try:
   from display_layout import pixels
  except Exception:
   def pixels(value):return value
  self.note=tk.Label(self,text='大字是当前库存。训练度是现在；夏季后预计是下季兵量和训练。募兵人数用各城已封顶合计，实到可能差几十。各城还可在「城关」页。',
                     bg='#eee0c4',fg='#6b3f12',anchor='w',justify='left',wraplength=720,font=(face,12))
  self.note.pack(fill='x',padx=8,pady=(8,4))
  board=tk.Frame(self,bg=WELL);board.pack(fill='both',expand=True,padx=6,pady=(0,8))
  for col in range(3):board.columnconfigure(col,weight=1)
  board.rowconfigure(0,weight=1)
  for col,(kind,short,card_bg,accent) in enumerate(KIND_META):
   card=tk.Frame(board,bg=card_bg,highlightbackground=accent,highlightthickness=2)
   card.grid(row=0,column=col,sticky='nsew',padx=8,pady=8)
   card.columnconfigure(0,weight=1)
   card.rowconfigure(2,weight=1)
   head=tk.Label(card,text=short,bg=accent,fg='#fff8ee',font=(face,12,'bold'),anchor='w',padx=12,pady=6)
   head.grid(row=0,column=0,sticky='ew')
   name=tk.Label(card,bg=card_bg,fg=INK,font=(face,22,'bold'),anchor='w',padx=14,pady=10)
   name.grid(row=1,column=0,sticky='ew')
   count=tk.Label(card,bg=card_bg,fg=INK,font=(face,28,'bold'),anchor='w',padx=14,pady=8)
   count.grid(row=2,column=0,sticky='nsew')
   body=tk.Frame(card,bg=card_bg);body.grid(row=3,column=0,sticky='ew',padx=14,pady=12)
   def field(title):
    tk.Label(body,text=title,bg=card_bg,fg=MUTED,font=(face,10),anchor='w').pack(fill='x',pady=(8,0))
    value=tk.Label(body,bg=card_bg,fg=INK,font=(face,13),anchor='w',justify='left',wraplength=pixels(220))
    value.pack(fill='x')
    return value
   recruits=field('每年夏季募兵')
   training=field('训练度')
   after=field('夏季后预计')
   attack=field('攻击基值 小 / 中 / 大')
   efficiency=field('练兵效率')
   self.tiles[kind]=[name,count,recruits,training,attack,efficiency,after]
  self.bind('<Configure>',lambda e:self.note.configure(wraplength=max(180,e.width-24)))

 def update_force(self,force,state=None):
  from recruitment_summary import annual_recruitment,recruitment_text
  from training_prediction import describe_stock_efficiency
  totals=annual_recruitment(state,force.get('force_id'))
  from preparation_model import training_bases
  from unit_target_attack import supported_combat_build
  for kind,cells in self.tiles.items():
   name,count,recruits,training,attack=cells[:5]
   recruits.config(text=recruitment_text(totals[kind]))
   info=troop_info(kind,force.get('armament_raw',{}).get(kind));stock=force.get('troop_stock',{}).get(kind)
   tier=info['tier'] if info['tier'] in (0,1,2) else 0
   name.config(text=info['name'],fg=GRADE_FG[tier]);count.config(text=f'{stock:,}' if type(stock) is int else '未知')
   training.config(text=f"{info['training']} / 100" if info['training'] is not None else '未知')
   if len(cells)>6:cells[6].config(text=self._after_text(kind,force.get('armament_raw',{}).get(kind),stock,totals[kind]))
   bases=training_bases(kind,force.get('armament_raw',{}).get(kind)) if supported_combat_build((state or {}).get('build_sha256')) else None
   attack.config(text=' / '.join(map(str,bases['unit'])) if bases and all(v is not None for v in bases['unit']) else '缺参数' if bases else '未核定')
   if len(cells)>5:cells[5].config(text=describe_stock_efficiency(stock))

 def _after_text(self,kind,raw,stock,annual):
  from recruitment_summary import mix_after_recruit
  added=annual.get('known') if isinstance(annual,dict) else None
  pred=mix_after_recruit(raw,stock,added if type(added) is int else None)
  if pred is None:
   return '未知'
  info=troop_info(kind,pred['raw'])
  text=f"{pred['stock']:,} · {info['name']} {info['training']}/100"
  if annual.get('missing'):
   return text+' · 募兵未采全'
  if pred['added']==0:
   return text+' · 无新兵'
  return text

 def update_prediction(self,state,force):
  pass
