"""Read the original SGI terrain tile stream, without modifying game assets."""
from pathlib import Path
from functools import lru_cache
import os
from PIL import Image

MBM_SIZE = (9744, 4872)
MIP_STEPS = (8, 16)


def world_pixel(x,y):
    return 48+96*x+48*(y%2),24+24*y


def mip_factor(src_w, dest_w):
    """Pick a downsample so a wide MBM crop is not stitched from 40k tiles."""
    src_w = max(1, int(src_w))
    dest_w = max(1, int(dest_w))
    if src_w <= max(dest_w * 1.6, 900):
        return 1
    for factor in MIP_STEPS:
        if src_w / factor <= dest_w * 2.2:
            return factor
    return MIP_STEPS[-1]


class Terrain:
    def __init__(self,path=None):
        candidates=[Path(path)] if path else []
        if os.environ.get('SGI_TERRAIN_FILE'):candidates.append(Path(os.environ['SGI_TERRAIN_FILE']))
        candidates += [Path(__file__).parent/'assets'/'SanInet.mbm',Path('D:/Coding/sanguo-internet/run-3.5/3I/SanInet.mbm'),Path.home()/'Library/Application Support/CrossOver/Bottles/SanguoInternet/drive_c/sgi/run-3.5/3I/SanInet.mbm']
        self.path=next((p for p in candidates if p.is_file()),None)
        if self.path is None:raise FileNotFoundError('未找到 SanInet.mbm')
        raw=self.path.read_bytes()
        with Image.open(self.path) as im:
            if im.size!=MBM_SIZE or im.mode!='P':raise ValueError('地图规格不匹配，不能使用本坐标配准')
            self.palette=im.getpalette()
        offset=int.from_bytes(raw[10:14],'little');self.data=raw[offset:]
        if len(self.data)<203*203*1152:raise ValueError('地图像素不完整')
        self._mips={}
    @lru_cache(maxsize=512)
    def tile(self,x,y):
        offset=(y*203+x)*1152
        tile=Image.frombytes('P',(48,24),self.data[offset:offset+1152]).transpose(Image.Transpose.FLIP_TOP_BOTTOM)
        tile.putpalette(self.palette)
        return tile.convert('RGB')
    def crop(self,box):
        left,top,right,bottom=map(int,box)
        out=Image.new('RGB',(right-left,bottom-top),'#68724e')
        for y in range(max(0,top//24),min(203,(bottom+23)//24)):
            for x in range(max(0,left//48),min(203,(right+47)//48)):
                out.paste(self.tile(x,y),(x*48-left,y*24-top))
        return out
    def mip(self,factor):
        factor=int(factor)
        if factor<=1:
            return None
        cached=self._mips.get(factor)
        if cached is not None:
            return cached
        width,height=MBM_SIZE[0]//factor,MBM_SIZE[1]//factor
        lut=bytes((self.palette or [])[:768])
        if len(lut)<768:
            lut=lut+bytes(768-len(lut))
        out=bytearray(width*height*3)
        data=self.data
        for dy in range(height):
            sy=dy*factor
            tile_row=(sy//24)*203
            flipped=23-(sy%24)
            row=dy*width
            for dx in range(width):
                sx=dx*factor
                index=data[(tile_row+sx//48)*1152+flipped*48+(sx%48)]
                src=index*3
                dst=(row+dx)*3
                out[dst]=lut[src]
                out[dst+1]=lut[src+1]
                out[dst+2]=lut[src+2]
        image=Image.frombytes('RGB',(width,height),bytes(out))
        self._mips[factor]=image
        return image
    def crop_to(self,box,dest_w,dest_h):
        dest_w=max(1,int(dest_w));dest_h=max(1,int(dest_h))
        left,top,right,bottom=map(int,box)
        src_w=max(1,right-left)
        factor=mip_factor(src_w,dest_w)
        if factor==1:
            return self.crop(box).resize((dest_w,dest_h),Image.Resampling.NEAREST)
        mip=self.mip(factor)
        ml=max(0,left//factor);mt=max(0,top//factor)
        mr=min(mip.width,(right+factor-1)//factor)
        mb=min(mip.height,(bottom+factor-1)//factor)
        if mr<=ml or mb<=mt:
            return Image.new('RGB',(dest_w,dest_h),'#68724e')
        return mip.crop((ml,mt,mr,mb)).resize((dest_w,dest_h),Image.Resampling.NEAREST)
