"""Raid tab: same panorama map. User places a troop and steps turns. No auto-pick."""
import threading
import tkinter as tk
from panorama_map import PanoramaMap
from player_view import player_id
from panorama_model import world_xy
from stealth_raid import (
    KIND_CHOICES, cell_walkable, city_ring_cell, format_raid_brief, kind_spec,
    own_cities, plan_stealth_raid,
)

BG = '#1b1d18'
INK = '#efe7cf'
MUTED = '#b7ad8f'
BAR = '#2a2c24'
WELL = '#22241d'


def _force_name(state, fid):
    for lord in ((state or {}).get('entities') or {}).get('lords') or []:
        if lord.get('force_id') == fid:
            return lord.get('name') or '?'
    return '?'


class StealthRaidPage(tk.Frame):
    def __init__(self, parent, app=None):
        super().__init__(parent, bg=BG)
        self.app = app
        self.cities = []
        self._sig = None
        self.kind = '骑兵'
        self.plan = None
        self.sim_turn = 0
        self.origin_city = None
        self.origin_cell = None
        self.dest_row = None
        self._plan_seq = 0
        face = getattr(app, 'face', None)
        self.hint = tk.StringVar(value='地图同全景。锁定我方后，点己方城周边放兵，再点目标城，结束回合移动。')
        tk.Label(
            self, textvariable=self.hint, bg=BAR, fg='#e4c56a', anchor='w',
            justify='left', font=(face, 11), wraplength=980,
        ).pack(fill='x', padx=8, pady=(8, 4))
        body = tk.PanedWindow(
            self, orient='horizontal', sashwidth=8, bg='#3d3f34',
            sashrelief='raised', opaqueresize=False,
        )
        body.pack(fill='both', expand=True)
        self.map = PanoramaMap(body, title='偷袭主城', mode='raid')
        self.map.on_pick_origin = self._from_map_city
        self.map.on_pick_cell = self._from_map_cell
        side = tk.Frame(body, bg=WELL, width=300)
        body.add(self.map, stretch='always', minsize=420)
        body.add(side, stretch='never', minsize=260)
        tk.Label(side, text='我方势力', bg=WELL, fg=INK, anchor='w', font=(face, 12, 'bold')).pack(fill='x', padx=10, pady=(10, 2))
        self.own_text = tk.StringVar(value='未锁定')
        tk.Label(
            side, textvariable=self.own_text, bg=WELL, fg='#ffe27a', anchor='w',
            font=(face, 13, 'bold'),
        ).pack(fill='x', padx=10, pady=(0, 8))
        tk.Label(side, text='出兵种类', bg=WELL, fg=INK, anchor='w', font=(face, 12, 'bold')).pack(fill='x', padx=10, pady=(4, 2))
        kinds = tk.Frame(side, bg=WELL)
        kinds.pack(fill='x', padx=10, pady=(0, 6))
        self.kind_var = tk.StringVar(value='骑兵')
        for label, _klass in KIND_CHOICES:
            tk.Radiobutton(
                kinds, text=label, value=label, variable=self.kind_var,
                command=self._schedule_plan, bg=WELL, fg=INK, selectcolor='#3d3f34',
                activebackground=WELL, activeforeground=INK, font=(face, 11),
            ).pack(side='left', padx=2)
        self.start_text = tk.StringVar(value='起点：未放兵')
        self.dest_text = tk.StringVar(value='目标：未点城')
        tk.Label(side, textvariable=self.start_text, bg=WELL, fg=INK, anchor='w', font=(face, 11)).pack(fill='x', padx=10, pady=(8, 0))
        tk.Label(side, textvariable=self.dest_text, bg=WELL, fg=INK, anchor='w', font=(face, 11)).pack(fill='x', padx=10, pady=(2, 8))
        sim = tk.Frame(side, bg=WELL)
        sim.pack(fill='x', padx=10, pady=(4, 4))
        tk.Button(sim, text='重来', command=self._reset, bg='#e7e0c9', fg='#302c22').pack(side='left')
        tk.Button(sim, text='上一回', command=self._prev, bg='#e7e0c9', fg='#302c22').pack(side='left', padx=6)
        tk.Button(sim, text='结束回合', command=self._next, bg='#e7e0c9', fg='#302c22').pack(side='left')
        self.sim_text = tk.StringVar(value='尚未出发')
        tk.Label(
            side, textvariable=self.sim_text, bg=WELL, fg='#ffe27a', anchor='w',
            justify='left', font=(face, 12, 'bold'), wraplength=280,
        ).pack(fill='x', padx=10, pady=(4, 4))
        self.note = tk.Label(
            side, text='不代选君主和城。点图即可。', bg=WELL, fg=MUTED, justify='left', anchor='nw',
            font=(face, 10), wraplength=280,
        )
        self.note.pack(fill='x', padx=10, pady=(0, 12))
        side.bind('<Configure>', self._wrap)

    def _wrap(self, event=None):
        width = max(200, (event.width if event else self.note.winfo_width()) - 24)
        self.note.configure(wraplength=width)

    def refresh(self, state):
        sig = None if not state else (state.get('snapshot_id'), player_id(state))
        self.map.update_state(state, lists=False, immediate=False, refresh_view=False)
        if sig == self._sig:
            return
        same_player = (
            self._sig is not None and sig is not None and self._sig[1] == sig[1]
            and player_id(state) is not None
        )
        self._sig = sig
        own = player_id(state)
        if own is None:
            self.own_text.set('未锁定')
            self.cities = []
            self.hint.set('未确认我方。地图仍是全景，先在顶栏锁定我方。')
            return
        self.own_text.set(f'{_force_name(state, own)}（已锁定）')
        self.cities = own_cities(state)
        if same_player:
            return
        self.origin_city = None
        self.origin_cell = None
        self.dest_row = None
        self.plan = None
        self.sim_turn = 0
        self.start_text.set('起点：未放兵')
        self.dest_text.set('目标：未点城')
        self.sim_text.set('点己方城周边放兵，再点目标城')
        self.map.raid_on = False
        self.map.raid_plan = None
        self.hint.set(f'我方 {_force_name(state, own)}。点己方城周边放兵，再点目标城，结束回合。')

    def _from_map_cell(self, cell):
        cell = (int(cell[0]), int(cell[1]))
        if player_id(self.map.state) is None:
            return
        if not cell_walkable(self.map.state, cell, self.map.terrain):
            self.sim_text.set(f'({cell[0]},{cell[1]}) 不能落脚')
            return
        self.origin_cell = cell
        near = None
        for city in self.cities:
            xy = world_xy(city)
            if xy and max(abs(xy[0] - cell[0]), abs(xy[1] - cell[1])) <= 1:
                near = city
                break
        self.origin_city = near
        name = (near or {}).get('name')
        self.start_text.set(f'起点：{name + "旁" if name else ""} ({cell[0]},{cell[1]})')
        self._schedule_plan()

    def _from_map_city(self, row):
        own = player_id(self.map.state)
        if own is None or not row:
            return
        if row.get('owner_raw') == own:
            self.origin_city = row
            ring = city_ring_cell(self.map.state, row, self.map.terrain)
            self.origin_cell = ring
            xy = ring or world_xy(row)
            name = row.get('name') or '?'
            if xy:
                self.start_text.set(f'起点：{name}旁 ({xy[0]},{xy[1]})')
            else:
                self.start_text.set(f'起点：{name}')
        else:
            self.dest_row = row
            name = row.get('name') or '?'
            xy = world_xy(row)
            self.dest_text.set(f'目标：{name}' + (f' ({xy[0]},{xy[1]})' if xy else ''))
        self._schedule_plan()

    def _origin_xy(self):
        if self.origin_cell:
            return tuple(self.origin_cell)
        if self.origin_city:
            ring = city_ring_cell(self.map.state, self.origin_city, self.map.terrain)
            if ring:
                self.origin_cell = ring
                return ring
            return world_xy(self.origin_city)
        return None

    def _schedule_plan(self):
        self.kind = self.kind_var.get() or '骑兵'
        spec = kind_spec(self.kind)
        origin = self._origin_xy()
        dest = self.dest_row
        if origin is None or dest is None or spec is None:
            self.plan = None
            self.map.raid_on = False
            self.map.raid_plan = None
            if origin is None:
                self.sim_text.set('点己方城周边放下部队')
            else:
                self.sim_text.set('再点目标城')
            return
        self._plan_seq += 1
        seq = self._plan_seq
        self.sim_text.set('算路中…可继续拖地图')
        state = self.map.state
        terrain = self.map.terrain
        placed = self.start_text.get()
        threading.Thread(
            target=self._plan_worker,
            args=(state, origin, dest, terrain, spec, seq, placed),
            daemon=True,
            name='sgi-raid-plan',
        ).start()

    def _plan_worker(self, state, origin, dest_row, terrain, spec, seq, placed):
        try:
            plan = plan_stealth_raid(state, origin, dest_row, terrain, cavalry=spec)
        except Exception as error:
            plan = {'ok': False, 'error': str(error)}
        self.after(0, lambda: self._on_plan(plan, spec, origin, seq, placed))

    def _on_plan(self, plan, spec, origin, seq, placed):
        if seq != self._plan_seq:
            return
        self.plan = plan or {'ok': False}
        city_name = (self.origin_city or {}).get('name')
        placed_name = f"{city_name}旁" if city_name else f"({origin[0]},{origin[1]})"
        self.plan['origin_name'] = placed_name
        self.plan['origin_reason'] = f"{self.kind}放在{placed_name} ({origin[0]},{origin[1]})"
        if self.plan.get('ok'):
            self.plan['brief'] = format_raid_brief(self.plan)
            self.hint.set(format_raid_brief(self.plan))
            turns = len(self.plan.get('cavalry_turn_cells') or [])
            self.note.config(text=f'{placed}\n本兵种全程 {turns} 回（移动力{spec["points"]}）。点结束回合往前走。')
        else:
            self.hint.set(self.plan.get('error') or '算不出这条路。')
            self.note.config(text=self.plan.get('error') or '')
        self.sim_turn = 0
        self._paint_sim(immediate=False)

    def _cells(self):
        if not self.plan or not self.plan.get('ok'):
            return []
        return list(self.plan.get('cavalry_turn_cells') or [])

    def _reset(self):
        self.sim_turn = 0
        self._paint_sim(immediate=True)

    def _next(self):
        cells = self._cells()
        if not cells:
            self._schedule_plan()
            return
        self.sim_turn = min(len(cells), self.sim_turn + 1)
        self._paint_sim(immediate=True)

    def _prev(self):
        self.sim_turn = max(0, self.sim_turn - 1)
        self._paint_sim(immediate=True)

    def _paint_sim(self, immediate=False):
        cells = self._cells()
        total = len(cells)
        if not self.plan or not self.plan.get('ok'):
            if self.sim_text.get() != '算路中…可继续拖地图':
                self.sim_text.set('没有可走的路' if self.origin_cell and self.dest_row else self.sim_text.get())
            self.map.show_raid(None)
            return
        origin = self.plan['origin']
        if self.sim_turn <= 0:
            cell = origin
            self.sim_text.set(f'第 0 回 · {self.kind}全程 {total} 回 · 移动力{self.plan["cavalry"]["points"]}')
        elif self.sim_turn >= total:
            self.sim_turn = total
            cell = cells[-1]
            self.sim_text.set(f'第 {total}/{total} 回抵达 · 停 ({cell[0]},{cell[1]})')
        else:
            cell = cells[self.sim_turn - 1]
            self.sim_text.set(f'第 {self.sim_turn}/{total} 回 · 停 ({cell[0]},{cell[1]})')
        if self.sim_turn > 0 and cell:
            self.map.center = (cell[0] + 0.5, cell[1] + 0.5)
        self.map.show_raid(self.plan, sim_cell=cell, immediate=immediate)
