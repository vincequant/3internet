"""Original-art reference and live-ID officer portrait detail."""
import tkinter as tk
from tkinter import ttk
from original_sprites import OriginalSprites,CATALOG
BG='#f7f4ea';FG='#302c22'
class OriginalArtPanel(tk.Frame):
 def __init__(self,parent,app):
  super().__init__(parent,bg=BG);self.images=OriginalSprites(self)
  tk.Label(self,text='原版素材图鉴 · 地图显示静态代表帧；效果图仅供攻略参考，不代表正在交战。',bg=BG,fg=FG,anchor='w').pack(fill='x',padx=10,pady=6)
  canvas=tk.Canvas(self,bg=BG,highlightthickness=0);scroll=ttk.Scrollbar(self,command=canvas.yview);canvas.configure(yscrollcommand=scroll.set);scroll.pack(side='right',fill='y');canvas.pack(fill='both',expand=True)
  grid=tk.Frame(canvas,bg=BG);item=canvas.create_window(0,0,window=grid,anchor='nw');grid.bind('<Configure>',lambda _:canvas.configure(scrollregion=canvas.bbox('all')));canvas.bind('<Configure>',lambda e:canvas.itemconfigure(item,width=e.width))
  entries=[(name,v['file']) for name,v in CATALOG['units'].items()]
  entries += [(name,v[1]['file']) for kind,v in CATALOG['buildings'].items() for name in [{'parade_ground':'练兵所','horse_farm':'牧场','bow_studio':'弓工坊'}[kind]]]
  entries += [('运输队','transport.png'),('舟船','boat.png'),('战船（舰型待实景核对）','warship.png'),('城池','city-0.png'),('关隘与城墙','city-25.png'),('城墙片段','wall.png'),('火焰','fire.png'),('落石','rock.png'),('陷坑','pit.png'),('雷电效果','lightning.png'),('箭矢效果','arrow.png'),('烟雾效果','smoke.png')]
  for i,(name,file) in enumerate(entries):
   box=tk.Frame(grid,bg=BG);box.grid(row=i//4,column=i%4,sticky='nsew',padx=6,pady=8);grid.columnconfigure(i%4,weight=1)
   photo=self.images.named(file,90);tk.Label(box,image=photo or '',bg=BG,height=100).pack();tk.Label(box,text=name,bg=BG,fg=FG,wraplength=200).pack()
  tk.Label(grid,text=f"已载入 {CATALOG['portraits']['count']} 张原版武将头像；在武将列表双击姓名查看。旗帜按本局已读取的势力颜色编号选用。",bg=BG,fg=FG,wraplength=900).grid(row=(len(entries)+3)//4,column=0,columnspan=4,pady=12)

def open_officer(app,key):
 selected=app.tables[key].selection()
 record=app.row_records.get(key,{}).get(selected[0]) if selected else None
 open_officer_record(app,record)

def open_officer_record(app,record):
 if not app or not record:return
 window=tk.Toplevel(app.root);window.title('武将详情 · '+str(record.get('name') or '未知'));window.configure(bg=BG);window.geometry('610x420')
 if not hasattr(app,'combat_windows'):app.combat_windows=[]
 app.combat_windows.append(window)
 images=OriginalSprites(window);window.original_images=images
 photo=images.portrait(record.get('portrait_id'));image=tk.Label(window,image=photo or '',text='' if photo else '头像编号未解析',bg=BG,fg=FG);image.pack(side='left',anchor='n',padx=12,pady=15)
 lords=((getattr(app,'doc',None) or {}).get('entities') or {}).get('lords') or []
 owner=next((f['name'] for f in lords if f.get('force_id')==record.get('owner_raw')),'无归属')
 panel=tk.Frame(window,bg=BG);panel.pack(fill='both',expand=True,padx=10,pady=10)
 title=tk.Label(panel,text=str(record.get('name') or '未知')+' · '+owner,bg=BG,fg=FG,font=(getattr(app,'face','Microsoft YaHei'),16,'bold'),anchor='w');title.pack(fill='x')
 attrs=record.get('attributes') or {};text=tk.Text(panel,bg=BG,fg=FG,font=(getattr(app,'face','Microsoft YaHei'),11),wrap='word',relief='flat',height=15);text.pack(fill='both',expand=True)
 from officer_reference import officer_metrics
 m=officer_metrics(record)
 web=[]
 for label,key in (('网站攻击力','attack'),('网站计略','strategy'),('网站外交力','diplomacy'),('网站技能','skills'),('资料匹配','match')):
  if m.get(key) not in (None,''):web.append(f'{label}：{m[key]}')
 extra='\n'.join(web)
 text.insert('end',f"兵力：{record.get('soldiers','未知')}\n统 {attrs.get('lead','?')} · 武 {attrs.get('war','?')} · 智 {attrs.get('intel','?')} · 政 {attrs.get('pol','?')} · 魅 {attrs.get('cha','?')}\n状态：{record.get('status_label') or record.get('status_code') or '未知'} · 所在：{record.get('location_city_name') or '未知'}\n\n{extra}\n\n头像按游戏当前头像编号读取；网站字段来自武将资料库存档，不是引擎实伤。此窗口为打开时快照。")
 text.config(state='disabled')
