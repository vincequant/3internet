import sys
import unittest
from pathlib import Path
sys.path[:0]=[str(Path(__file__).resolve().parents[1]/'app'),str(Path(__file__).resolve().parents[1]/'bridge')]
from city_production import population_cap as engine_population_cap
from recruitment_summary import city_recruit_rows,format_recruit_cell,population_cap
from training_prediction import describe_stock_efficiency,stock_bracket,stock_training_base
from world_cities import city_values

class TrainingEfficiency(unittest.TestCase):
 def test_stock_brackets(self):
  self.assertEqual(stock_training_base(9999),10)
  self.assertEqual(stock_training_base(10000),9)
  self.assertEqual(stock_training_base(28510),9)
  self.assertEqual(stock_training_base(30000),8)
  self.assertEqual(stock_training_base(100000),5)
  self.assertEqual(stock_bracket(28510)['percent'],90)
  self.assertEqual(stock_bracket(28510)['remain'],1490)
  self.assertIn('90%',describe_stock_efficiency(28510))
  self.assertIn('再募1,490人→80%',describe_stock_efficiency(28510))
  self.assertIn('已是最低档',describe_stock_efficiency(100000))
  self.assertEqual(describe_stock_efficiency(None),'未知')

 def test_engine_cap_matches_city_production(self):
  for pop in (49999,50000,50049,50050,156500,432902,1000000):
   self.assertEqual(population_cap(pop),engine_population_cap(pop))

 def test_city_recruit_cap_and_overflow(self):
  self.assertEqual(format_recruit_cell(500,20680),'20,180')
  self.assertEqual(format_recruit_cell(21670,15650),'溢6,020')
  state={'entities':{'lords':[{'force_id':0,'name':'魏'}],'cities_and_barriers':[
    {'type':'city','owner_raw':0,'city_id':12,'name':'许昌','population':432902,'world_xy_raw':[0,0],
     'recruitment_capacity':{'population_cap':43290,'amounts':{'infantry':500,'cavalry':6000,'bow':500}}},
    {'type':'city','owner_raw':1,'city_id':20,'name':'商丘','population':156500,'world_xy_raw':[1,1],
     'recruitment_capacity':{'population_cap':15650,'amounts':{'infantry':0,'cavalry':0,'bow':15650}}}],
   'production_buildings':[
    {'type':'parade_ground','linked_city_id':12,'building_ui_amount':500},
    {'type':'horse_farm','linked_city_id':12,'building_ui_amount':6000},
    {'type':'bow_studio','linked_city_id':12,'building_ui_amount':500},
    {'type':'bow_studio','linked_city_id':20,'building_ui_amount':11270},
    {'type':'bow_studio','linked_city_id':20,'building_ui_amount':10400}]}}
  wei=city_recruit_rows(state,0)
  self.assertEqual(len(wei),1)
  self.assertEqual(wei[0]['cap'],43290)
  self.assertEqual(wei[0]['cells']['cavalry'],'37,290')
  song=city_recruit_rows(state,1)
  self.assertEqual(song[0]['cells']['bow'],'溢6,020')
  self.assertEqual(song[0]['built']['bow'],21670)
  values=city_values(state,state['entities']['cities_and_barriers'][0])
  self.assertEqual(values[6],'432,902')
  self.assertEqual(values[7],'43,290')

if __name__=='__main__':
 unittest.main()
