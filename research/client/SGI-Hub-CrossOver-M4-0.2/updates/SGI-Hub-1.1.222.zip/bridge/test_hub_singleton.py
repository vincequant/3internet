import types
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'app'


class HubSingletonTests(unittest.TestCase):
    def test_peer_pid_skips_helpers_and_self(self):
        import sys
        sys.path.insert(0, str(APP))
        from hub_singleton import peer_hub_pid, raise_existing_hub, raise_script

        listing = (
            '10 /usr/bin/grep mac_main.py\n'
            '11 /opt/homebrew/bin/python3 -B /hub/app/mac_main.py\n'
            '12 /opt/homebrew/bin/python3 -B /hub/app/wine_nav.py\n'
        )
        self.assertEqual(peer_hub_pid(me=99, listing=listing), 11)
        self.assertIsNone(peer_hub_pid(me=11, listing=listing))
        self.assertIsNone(peer_hub_pid(me=1, listing='10 /usr/bin/pgrep -lf mac_main.py\n'))
        script = raise_script(11)
        self.assertIn('unix id is 11', script)
        self.assertIn('全知情报', script)
        self.assertNotIn('name is "Python"', script)
        self.assertTrue(raise_existing_hub(11, runner=lambda _: types.SimpleNamespace(stdout='yes\n')))
        self.assertFalse(raise_existing_hub(11, runner=lambda _: types.SimpleNamespace(stdout='no\n')))
        self.assertFalse(raise_existing_hub(None, runner=lambda _: types.SimpleNamespace(stdout='yes\n')))

    def test_reload_replaces_this_process_only(self):
        import sys
        sys.path.insert(0, str(APP))
        from hub_singleton import reload_argv, reload_hub

        argv = reload_argv('/usr/bin/python3', '/hub/app/mac_main.py')
        self.assertEqual(argv[:2], ['/usr/bin/python3', '-B'])
        self.assertEqual(Path(argv[2]), Path('/hub/app/mac_main.py'))
        seen = []
        reload_hub(before=lambda: seen.append('before'), executable='/bin/py', script='/hub/app/mac_main.py',
                   execv=lambda exe, args: seen.append((exe, list(args))))
        self.assertEqual(seen[0], 'before')
        self.assertEqual(seen[1][0], '/bin/py')
        self.assertEqual(seen[1][1][:2], ['/bin/py', '-B'])
        self.assertEqual(Path(seen[1][1][2]), Path('/hub/app/mac_main.py'))
        omni = (APP / 'omni_window.py').read_text(encoding='utf-8')
        main = (APP / 'mac_main.py').read_text(encoding='utf-8')
        self.assertIn("text='刷新'", omni)
        self.assertIn("fg='#302c22'", omni)
        self.assertIn('self.version_label', omni)
        self.assertIn('def reload_hub(self):', omni)
        self.assertIn('self.on_reload', omni)
        self.assertIn('pack(side=\'right\'', omni.split("text='刷新'", 1)[1][:400])
        self.assertIn('def restart_hub():', main)
        self.assertIn('app.on_reload=restart_hub', main)
        self.assertIn('Never stop SANPK', main)
        self.assertIn('exec_reload', main)
        self.assertNotIn('os.execv', main)

    def test_mac_main_starts_again_when_raise_fails(self):
        text = (APP / 'mac_main.py').read_text(encoding='utf-8')
        self.assertIn('from hub_singleton import peer_hub_pid, raise_existing_hub', text)
        self.assertIn('原窗口没切上来，再开一个全知情报。', text)
        self.assertIn("_root/'bridge'", text)
        self.assertNotIn('请切回原窗口', text)
        self.assertNotIn('name is "Python"', text)

    def test_wine_nav_can_launch_hub(self):
        import sys
        sys.path.insert(0, str(APP))
        from wine_nav import hub_command
        nav = (APP / 'wine_nav.py').read_text(encoding='utf-8')
        self.assertIn("choices=('rooms', 'quiet', 'panorama', 'replay', 'nav', 'hub')", nav)
        self.assertIn("if args.launch == 'hub':", nav)
        self.assertTrue(hub_command()[-1].endswith('mac_main.py'))
        self.assertIn('hub-title-reload', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('wine-launcher-hub-independent', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('1.1.222', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('stealth-raid-no-path', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('stealth-raid-click-only', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('stealth-raid-same-view', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('stealth-raid-place-around', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('stealth-raid-open-fast', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('training-order-guide', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('cav-50k-skip-200-spring', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('force-kind-stars', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('min-commands-bow-cav', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('stealth-raid-mbm-sim', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('year-pace-in-sim', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('stealth-raid-own-tab', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('camp-train-simulator', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('panorama-stealth-raid-capital', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('training-speed-archive-guide', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('hub-review-time-nodes', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('hub-replay-archive-picker', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('quarter-ops-join-module-import', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('city-talent-click-opens-wild', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('archive-keep-1v1-after-defection', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('hire-join-in-civil-lane', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('officer-skill-ride-bow-ambush-columns', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('panorama-side-pane-min-width', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('wine-protocol-also-enter-lobby', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('hub-status-phase-only', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('move-grid-city-not-mbm-road', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('panorama-city-card-popup', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('panorama-produce-score-rings', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('move-grid-gate-slope-walkable', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('wine-protocol-skip-cold-inspect', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('hub-reload-ink-and-version', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('panorama-no-war-rings', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('move-grid-mountain-impassable', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('panorama-detach-button-ink', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('panorama-produce-rings', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('opening-note-on-stock-tab', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('move-grid-engine-kind-map', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('training-record-kind-tabs', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('wine-protocol-faster-enter', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('training-record-canvas-fit-tab', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('training-record-row-pack-layout', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('wine-protocol-join-ampersand-caption', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('last-frame-stale-open-previous', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('move-grid-engine-terrain-water', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('wine-protocol-nethook-before-sanpk', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('replay-season-merged-ops', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('wine-protocol-search-empty-confirm', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('wine-protocol-search-broadcast-win81', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('city-talent-skill-counts', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('training-record-opening-train-short', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('wine-ui-enter-without-keychain', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('wine-protocol-direct-toggle', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('wine-win81-skip-busy-wineserver', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('wine-protocol-direct-nethook-mutex', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('wine-main-protocol-sanpk-win32-helper', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('wine-main-protocol-enter-game-list', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('wine-main-auto-enter-game-list', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
