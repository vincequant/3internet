"""Raid tab: panorama map, place a troop on a city ring, user walks, count turns."""
import tkinter as tk
from panorama_map import PanoramaMap
from player_view import player_id
from panorama_model import world_xy
from stealth_raid import (
    KIND_CHOICES, cell_walkable, city_ring_cells, kind_spec, own_cities, walk_ring_cells,
)

BG = '#1b1d18'
INK = '#efe7cf'
MUTED = '#b7ad8f'
BAR = '#2a2c24'
WELL = '#22241d'


def _force_name(state, fid):
    for lord in ((state or {}).get('entities') or {}).get('lords') or []:
        if lord.get('force_id') == fid:
            return lord.get('name') or '?'
    return '?'


class StealthRaidPage(tk.Frame):
    def __init__(self, parent, app=None):
        super().__init__(parent, bg=BG)
        self.app = app
        self.cities = []
        self._sig = None
        self.sortie_city = None
        self.ring = []
        self.unit_cell = None
        self.pending = None
        self.log = []
        face = getattr(app, 'face', None)
        self.hint = tk.StringVar(value='地图同全景。点己方城看出兵四格，选兵种点一格放下，自己走，结束回合记一笔。')
        tk.Label(
            self, textvariable=self.hint, bg=BAR, fg='#e4c56a', anchor='w',
            justify='left', font=(face, 11), wraplength=980,
        ).pack(fill='x', padx=8, pady=(8, 4))
        body = tk.PanedWindow(
            self, orient='horizontal', sashwidth=8, bg='#3d3f34',
            sashrelief='raised', opaqueresize=False,
        )
        body.pack(fill='both', expand=True)
        self.map = PanoramaMap(body, title='偷袭主城', mode='raid')
        self.map.on_pick_origin = self._from_map_city
        self.map.on_pick_cell = self._from_map_cell
        side = tk.Frame(body, bg=WELL, width=300)
        body.add(self.map, stretch='always', minsize=420)
        body.add(side, stretch='never', minsize=260)
        tk.Label(side, text='我方势力', bg=WELL, fg=INK, anchor='w', font=(face, 12, 'bold')).pack(fill='x', padx=10, pady=(10, 2))
        self.own_text = tk.StringVar(value='未锁定')
        tk.Label(
            side, textvariable=self.own_text, bg=WELL, fg='#ffe27a', anchor='w',
            font=(face, 13, 'bold'),
        ).pack(fill='x', padx=10, pady=(0, 8))
        tk.Label(side, text='出兵种类', bg=WELL, fg=INK, anchor='w', font=(face, 12, 'bold')).pack(fill='x', padx=10, pady=(4, 2))
        kinds = tk.Frame(side, bg=WELL)
        kinds.pack(fill='x', padx=10, pady=(0, 6))
        self.kind_var = tk.StringVar(value='骑兵')
        for label, _klass in KIND_CHOICES:
            tk.Radiobutton(
                kinds, text=label, value=label, variable=self.kind_var,
                command=self._paint, bg=WELL, fg=INK, selectcolor='#3d3f34',
                activebackground=WELL, activeforeground=INK, font=(face, 11),
            ).pack(side='left', padx=2)
        self.place_text = tk.StringVar(value='未出兵')
        tk.Label(side, textvariable=self.place_text, bg=WELL, fg=INK, anchor='w', font=(face, 11)).pack(fill='x', padx=10, pady=(8, 2))
        sim = tk.Frame(side, bg=WELL)
        sim.pack(fill='x', padx=10, pady=(4, 4))
        tk.Button(sim, text='重来', command=self._reset, bg='#e7e0c9', fg='#302c22').pack(side='left')
        tk.Button(sim, text='上一回', command=self._prev, bg='#e7e0c9', fg='#302c22').pack(side='left', padx=6)
        tk.Button(sim, text='结束回合', command=self._end_turn, bg='#e7e0c9', fg='#302c22').pack(side='left')
        self.sim_text = tk.StringVar(value='点己方城')
        tk.Label(
            side, textvariable=self.sim_text, bg=WELL, fg='#ffe27a', anchor='w',
            justify='left', font=(face, 12, 'bold'), wraplength=280,
        ).pack(fill='x', padx=10, pady=(4, 4))
        self.log_box = tk.Text(
            side, height=10, bg='#2c2f26', fg=INK, relief='flat', font=(face, 10),
            wrap='word',
        )
        self.log_box.pack(fill='both', expand=True, padx=10, pady=(0, 12))
        self.log_box.bind('<Key>', lambda _e=None: 'break')
        side.bind('<Configure>', self._wrap)
        self._paint()

    def _wrap(self, event=None):
        width = max(200, (event.width if event else 280) - 24)
        self.log_box.configure(width=max(20, width // 8))

    def _kind(self):
        return self.kind_var.get() or '骑兵'

    def refresh(self, state):
        sig = None if not state else (state.get('snapshot_id'), player_id(state))
        self.map.update_state(state, lists=False, immediate=False, refresh_view=False)
        if sig == self._sig:
            return
        same_player = (
            self._sig is not None and sig is not None and self._sig[1] == sig[1]
            and player_id(state) is not None
        )
        self._sig = sig
        own = player_id(state)
        if own is None:
            self.own_text.set('未锁定')
            self.cities = []
            self.hint.set('未确认我方。地图仍是全景，先在顶栏锁定我方。')
            return
        self.own_text.set(f'{_force_name(state, own)}（已锁定）')
        self.cities = own_cities(state)
        if same_player:
            self._paint()
            return
        self.sortie_city = None
        self.ring = []
        self.unit_cell = None
        self.pending = None
        self.log = []
        self.hint.set(f'我方 {_force_name(state, own)}。点己方城，周边四格出兵。')
        self.sim_text.set('点己方城')
        self.place_text.set('未出兵')
        self._paint()

    def _from_map_city(self, row):
        own = player_id(self.map.state)
        if own is None or not row or row.get('owner_raw') != own:
            return
        if self.unit_cell is not None:
            return
        self.sortie_city = row
        self.ring = city_ring_cells(self.map.state, row, self.map.terrain)
        if self.unit_cell is None:
            self.pending = None
            name = row.get('name') or '?'
            self.sim_text.set(f'{name}周边 {len(self.ring)} 格，点一格放{self._kind()}')
            self.place_text.set(f'出兵城 {name}')
        self._paint()

    def _from_map_cell(self, cell):
        cell = (int(cell[0]), int(cell[1]))
        if player_id(self.map.state) is None:
            return
        if self.unit_cell is None:
            if cell not in set(self.ring):
                if not self.ring:
                    self.sim_text.set('先点己方城，再点周边四格')
                    return
                self.sim_text.set('请点亮着的周边格放兵')
                return
            if not cell_walkable(self.map.state, cell, self.map.terrain):
                self.sim_text.set(f'({cell[0]},{cell[1]}) 不能落脚')
                return
            self.unit_cell = cell
            self.pending = None
            self.ring = walk_ring_cells(self.map.state, cell, self.map.terrain)
            city = (self.sortie_city or {}).get('name') or ''
            self.place_text.set(f'{self._kind()} 在{city}旁 ({cell[0]},{cell[1]})')
            self.sim_text.set('已放兵。点邻格走路，结束回合记一笔')
            self._paint()
            return
        if cell not in set(self.ring):
            self.sim_text.set('点当前格周边四格走路')
            return
        self.pending = cell
        self.sim_text.set(f'本回走到 ({cell[0]},{cell[1]})，点结束回合记下')
        self._paint()

    def _end_turn(self):
        if self.unit_cell is None:
            self.sim_text.set('还没放兵')
            return
        if self.pending:
            self.unit_cell = self.pending
            self.pending = None
        self.log.append({
            'n': len(self.log) + 1,
            'cell': tuple(self.unit_cell),
            'kind': self._kind(),
        })
        self.ring = walk_ring_cells(self.map.state, self.unit_cell, self.map.terrain)
        cell = self.unit_cell
        self.sim_text.set(f'已记第 {len(self.log)} 回 · 停 ({cell[0]},{cell[1]})')
        self._paint()

    def _prev(self):
        if not self.log:
            return
        last = self.log.pop()
        self.unit_cell = last['cell']
        if self.log:
            self.unit_cell = self.log[-1]['cell']
        self.pending = None
        if self.unit_cell:
            self.ring = walk_ring_cells(self.map.state, self.unit_cell, self.map.terrain)
        self.sim_text.set(f'回到第 {len(self.log)} 回' if self.log else '已放兵，尚未记回')
        self._paint()

    def _reset(self):
        self.unit_cell = None
        self.pending = None
        self.log = []
        if self.sortie_city:
            self.ring = city_ring_cells(self.map.state, self.sortie_city, self.map.terrain)
            name = (self.sortie_city or {}).get('name') or '?'
            self.sim_text.set(f'{name}周边 {len(self.ring)} 格，点一格放兵')
            self.place_text.set(f'出兵城 {name}')
        else:
            self.ring = []
            self.sim_text.set('点己方城')
            self.place_text.set('未出兵')
        self._paint()

    def _paint(self):
        lines = []
        spec = kind_spec(self._kind())
        mp = spec['points'] if spec else '?'
        for row in self.log:
            cell = row['cell']
            lines.append(f"第{row['n']}回 {row['kind']} ({cell[0]},{cell[1]})")
        self.log_box.delete('1.0', 'end')
        if lines:
            self.log_box.insert('end', '\n'.join(lines))
        elif self.unit_cell:
            self.log_box.insert('end', f'已放{self._kind()}，移动力{mp}。结束回合后开始记。')
        else:
            self.log_box.insert('end', '不寻路。点城 → 点四格放兵 → 点邻格走 → 结束回合记录。')
        mark = self.pending or self.unit_cell
        self.map.show_raid(
            {
                'ok': True,
                'ring': list(self.ring),
                'sim_cell': mark,
                'brief': '',
            },
            sim_cell=mark,
            immediate=True,
        )
