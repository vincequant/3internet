"""Return focus after the observer window maps. Mac only; no Win32 foreground calls."""
import os
import re
import subprocess
import sys

GENERIC_BUNDLES = ('org.python.python', 'com.apple.python')


def parse_lsappinfo(text):
    if not text:
        return None
    pid = re.search(r'"pid"=(\d+)', text)
    if not pid:
        return None
    name = re.search(r'"(?:LSDisplayName|CFBundleName)"="([^"]*)"', text)
    bundle = re.search(r'"CFBundleIdentifier"="([^"]*)"', text)
    return {
        'pid': int(pid.group(1)),
        'name': name.group(1) if name else '',
        'bundle': bundle.group(1) if bundle else '',
    }


def capture_frontmost():
    if sys.platform != 'darwin':
        return None
    try:
        front = subprocess.check_output(['lsappinfo', 'front'], text=True, timeout=2).strip()
        info = subprocess.check_output(
            ['lsappinfo', 'info', '-only', 'name,pid,bundleid', front],
            text=True, timeout=2)
        return parse_lsappinfo(info)
    except Exception:
        return None


def is_self_front(info, self_pid=None):
    if not info:
        return False
    self_pid = os.getpid() if self_pid is None else self_pid
    return info.get('pid') == self_pid


def is_self_or_wine(info, self_pid=None):
    if is_self_front(info, self_pid):
        return True
    if not info:
        return False
    name = (info.get('name') or '').lower()
    bundle = (info.get('bundle') or '').lower()
    return 'wine' in name or 'wine' in bundle


def activate_pid(pid):
    try:
        subprocess.run(
            ['osascript', '-e',
             f'tell application "System Events" to set frontmost of first process whose unix id is {int(pid)} to true'],
            check=True, timeout=3, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False


def restore_frontmost(saved, current=None, self_pid=None, activate=activate_pid, stolen_by=is_self_front):
    if sys.platform != 'darwin' or not saved:
        return False
    self_pid = os.getpid() if self_pid is None else self_pid
    if saved.get('pid') == self_pid:
        return False
    current = capture_frontmost() if current is None else current
    if not stolen_by(current, self_pid):
        return False
    if saved.get('pid') and activate(saved['pid']):
        return True
    bundle = saved.get('bundle') or ''
    try:
        if bundle and bundle not in GENERIC_BUNDLES:
            subprocess.run(['open', '-b', bundle], check=True, timeout=3,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
        if saved.get('name') and saved.get('name', '').lower() not in ('python', 'python3', 'python.app'):
            subprocess.run(['open', '-a', saved['name']], check=True, timeout=3,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
    except Exception:
        return False
    return False
