import json
import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / 'app'), str(ROOT / 'bridge')]

from game_archive import build_demo_state, write_demo_archive, write_packed_archive
from history_review import (
    archive_time_nodes, is_live_recording, load_archive_frame, load_last_frame,
    previous_archive, review_archive, review_archives, review_bundle, status_line,
    troop_series_from_archive,
)


def _with_turn(state, turn):
    clock = dict(state.get('clock_candidates') or {})
    clock['turn_u16'] = turn
    state['clock_candidates'] = clock
    return state


class HistoryReviewTests(unittest.TestCase):
    def test_previous_archive_skips_open_and_demo(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            older = write_packed_archive(
                root / '20260101T000000Z-keep',
                [build_demo_state(0, year=200, season=2), build_demo_state(1, year=200, season=3)],
                extra_manifest={'title': '上一局', 'match_id': 'prev-1'},
            )
            write_demo_archive(root / '20260103T000000Z-demo')
            opened = write_packed_archive(
                root / '20260104T000000Z-live',
                [build_demo_state(2)],
                extra_manifest={'title': '进行中', 'match_id': 'live-1'},
            )
            manifest = json.loads((opened / 'manifest.json').read_text(encoding='utf-8'))
            manifest['open'] = True
            (opened / 'manifest.json').write_text(json.dumps(manifest), encoding='utf-8')
            chosen = previous_archive(root)
            self.assertEqual(Path(chosen['directory']), older)
            self.assertEqual(chosen['match_id'], 'prev-1')
            bundle = review_bundle(root)
            self.assertEqual(bundle['seq'], 2)
            self.assertEqual(bundle['state']['entities']['lords'][0]['gold'], 10001)
            self.assertIn('只读历史回放存档节点', (bundle['state'].get('history') or {}).get('banner', ''))
            self.assertIn('末帧 2/2', status_line(bundle))
            self.assertIn('只读历史', status_line(bundle))
            self.assertGreaterEqual(len((bundle['state'].get('history') or {}).get('troop_series') or []), 2)
            path = write_packed_archive(
                root / '20260102T000000Z-curve',
                [build_demo_state(0, year=200, season=0), build_demo_state(1, year=200, season=1),
                 build_demo_state(2, year=200, season=2)],
                extra_manifest={'title': '曲线局', 'match_id': 'curve-1'},
            )
            labels = [row.get('label') for row in troop_series_from_archive(path)]
            self.assertGreaterEqual(len(labels), 2)
            self.assertNotEqual(labels[0], labels[-1])
            same_season = write_packed_archive(
                root / '20260102T120000Z-season-only',
                [
                    _with_turn(build_demo_state(0, year=200, season=1), 0),
                    _with_turn(build_demo_state(1, year=200, season=1), 2),
                    _with_turn(build_demo_state(2, year=200, season=1), 4),
                    _with_turn(build_demo_state(3, year=200, season=2), 0),
                ],
                extra_manifest={'title': '一季三回', 'match_id': 'season-only-1'},
            )
            season_keys = [
                (row.get('year'), row.get('season'))
                for row in troop_series_from_archive(same_season)
            ]
            self.assertEqual(season_keys, [(200, 1), (200, 2)])
            manifest['write_error'] = 'access denied'
            manifest['completeness'] = 'write_error'
            (opened / 'manifest.json').write_text(json.dumps(manifest), encoding='utf-8')
            self.assertEqual(previous_archive(root)['match_id'], 'live-1')
            listed = [row['match_id'] for row in review_archives(root)]
            self.assertIn('prev-1', listed)
            self.assertIn('live-1', listed)
            self.assertNotIn(None, listed)
            picked = review_archive(next(row for row in review_archives(root) if row['match_id'] == 'curve-1'))
            self.assertEqual(picked['archive']['match_id'], 'curve-1')

    def test_stale_open_1v1_beats_older_write_error_3v3(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            older = write_packed_archive(
                root / '20260101T000000Z-3v3',
                [build_demo_state(0), build_demo_state(1)],
                extra_manifest={'title': '玩家局 3v3 韩/周/羌 vs 晋/蜀/南蛮', 'match_id': 'old-3v3', 'format': '3v3'},
            )
            man = json.loads((older / 'manifest.json').read_text(encoding='utf-8'))
            man['open'] = True
            man['write_error'] = 'access denied'
            man['completeness'] = 'write_error'
            (older / 'manifest.json').write_text(json.dumps(man), encoding='utf-8')
            stale = write_packed_archive(
                root / '20260105T000000Z-1v1',
                [build_demo_state(0), build_demo_state(1), build_demo_state(2)],
                extra_manifest={'title': '玩家局 1v1 蜀 vs 汉', 'match_id': 'stale-1v1', 'format': '1v1'},
            )
            man = json.loads((stale / 'manifest.json').read_text(encoding='utf-8'))
            man['open'] = True
            man['ended_utc'] = None
            man['completeness'] = 'recording'
            man['write_error'] = None
            man['last_capture_end'] = (datetime.now(timezone.utc) - timedelta(hours=3)).isoformat()
            (stale / 'manifest.json').write_text(json.dumps(man), encoding='utf-8')
            self.assertFalse(is_live_recording(man))
            chosen = previous_archive(root)
            self.assertEqual(chosen['match_id'], 'stale-1v1')
            self.assertIn('1v1', chosen.get('title') or chosen.get('format') or '')

    def test_fresh_open_recording_is_still_skipped(self):
        row = {
            'open': True, 'completeness': 'recording', 'match_id': 'live',
            'last_capture_end': datetime.now(timezone.utc).isoformat(),
        }
        self.assertTrue(is_live_recording(row))
        self.assertTrue(is_live_recording({'open': True, 'completeness': 'recording', 'match_id': 'live'},
                                          live_match_id='live'))

    def test_empty_root_has_no_previous(self):
        with tempfile.TemporaryDirectory() as tmp:
            self.assertIsNone(previous_archive(Path(tmp)))
            with self.assertRaisesRegex(ValueError, '没有可选取'):
                review_bundle(Path(tmp))
            self.assertEqual(review_archives(Path(tmp)), [])

    def test_load_last_frame_rejects_empty(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'empty'
            path.mkdir()
            (path / 'manifest.json').write_text(json.dumps({
                'format_version': 2, 'open': False, 'frames': [], 'last_seq': 0,
            }), encoding='utf-8')
            (path / 'frames.jsonl').write_text('', encoding='utf-8')
            (path / 'index.json').write_text(json.dumps({'frames': []}), encoding='utf-8')
            with self.assertRaisesRegex(ValueError, '没有帧'):
                load_last_frame(path)

    def test_hub_page_has_review_controls(self):
        text = (ROOT / 'app' / 'omni_window.py').read_text(encoding='utf-8')
        self.assertIn('选取存档', text)
        self.assertNotIn('读取上一局末帧', text)
        self.assertIn('回到实时', text)
        self.assertIn('def pick_history_archive', text)
        self.assertIn('def _choose_history_archive', text)
        self.assertIn('时间节点', text)
        self.assertIn('archive_time_nodes', text)
        self.assertIn("seq=chosen.get('seq')", text)
        self.assertIn('if self.review:', text)
        self.assertIn('存档末帧只读，不改我方身份。', text)
        self.assertIn('选取历史回放存档', text)
        self.assertIn('if live and live!=review:', text)
        self.assertIn('hub-last-frame-review', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('keep-player-1v1-2v2-3v3-archives', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('troop-series-collector-path', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('training-record-split-kind-charts', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('drop-archives-under-1000-frames', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('capture-buildings-not-construction', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('officer-city-nation-map', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('change-tab-round-labels', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('training-record-heavy-cavalry', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('keep-write-error-player-archives', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('review-troop-series-from-archive', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('training-record-season-only', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('panorama-city-hp-unit-move', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        review = (ROOT / 'app' / 'history_review.py').read_text(encoding='utf-8')
        self.assertIn("reader.index.get('quarters')", review)
        self.assertIn('first_seq', review)
        self.assertIn('is_live_recording', review)
        self.assertIn('stale_s', review)
        self.assertIn('def review_archives', review)
        self.assertIn('def review_archive', review)
        self.assertIn('def archive_time_nodes', review)
        self.assertIn('def load_archive_frame', review)
        self.assertIn('hub-replay-archive-picker', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
        self.assertIn('hub-review-time-nodes', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))

    def test_review_can_open_a_season_node(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            path = write_packed_archive(
                root / '20260106T000000Z-nodes',
                [
                    build_demo_state(0, year=200, season=0),
                    build_demo_state(1, year=200, season=1),
                    build_demo_state(2, year=200, season=2),
                    build_demo_state(3, year=200, season=3),
                ],
                extra_manifest={'title': '节点局', 'match_id': 'nodes-1', 'format': '1v1'},
            )
            nodes = archive_time_nodes(path)
            labels = [row['label'] for row in nodes]
            self.assertIn('开局', labels)
            self.assertIn('末帧', labels)
            self.assertTrue(any('200年' in label for label in labels))
            first = load_archive_frame(path, nodes[0]['seq'])
            last = load_last_frame(path)
            self.assertEqual(first['seq'], nodes[0]['seq'])
            self.assertEqual(last['seq'], last['frame_count'])
            self.assertNotEqual(first['state']['snapshot_id'], last['state']['snapshot_id'])
            mid = review_archive(path, seq=nodes[1]['seq'])
            self.assertEqual(mid['seq'], nodes[1]['seq'])
            self.assertEqual(mid['node_label'], nodes[1]['label'])
            self.assertIn(nodes[1]['label'], status_line(mid))
            self.assertNotIn('末帧 4/4', status_line(mid))
