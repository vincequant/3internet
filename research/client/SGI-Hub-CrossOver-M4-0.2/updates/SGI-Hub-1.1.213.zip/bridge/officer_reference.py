"""Website reference fields, isolated from runtime attributes and probabilities."""
import json,math
from pathlib import Path
from collections import defaultdict
DATA=json.loads(Path(__file__).with_name('officer_web_reference.json').read_text(encoding='utf8'))
INDEX=defaultdict(list)
for r in DATA['generals']:INDEX[r['name']].append(r)
KEYS={'lead':'leadership','war':'power','intel':'intelligence','pol':'politics','cha':'charm'}
STAT_LABELS=(('lead','统'),('war','武'),('intel','智'),('pol','政'),('cha','魅'))

def website_attributes(name):
 refs=INDEX.get(name) or []
 if len(refs)!=1:
  return {}
 stats=refs[0].get('stats') or {}
 return {key:stats[web] for key,web in KEYS.items() if isinstance(stats.get(web),(int,float))}

def display_attributes(officer):
 attrs=dict((officer or {}).get('attributes') or {})
 if any(isinstance(attrs.get(key),(int,float)) for key,_ in STAT_LABELS):
  return attrs
 return website_attributes((officer or {}).get('name'))

def standout_stat(officer):
 scored=[(label,attrs[key]) for attrs in (display_attributes(officer),) for key,label in STAT_LABELS if isinstance(attrs.get(key),(int,float))]
 if not scored:
  return None
 top=max(value for _,value in scored)
 for label,value in scored:
  if value==top:
   number=int(value) if float(value).is_integer() else value
   return {'label':label,'value':number}
 return None

def officer_title(officer):
 name=(officer or {}).get('name') or '未知'
 stand=standout_stat(officer)
 return f"{name}({stand['label']}:{stand['value']})" if stand else name

def officer_event_text(officer, city=None, field='录用'):
 title=officer_title(officer)
 place=city or (officer or {}).get('location_city_name')
 prefix='录用' if field=='录用' else '加入'
 return f'{prefix} {title}：{place}' if place else f'{prefix} {title}'

def hire_command_text(officer, city=None):
 return officer_event_text(officer, city, '录用')
def diplomacy(pol,cha,skills):
 return math.floor((pol+cha)*1.2+.5) if '提案' in skills else pol+cha

def officer_metrics(g):
 a=g.get('attributes',{});total=sum(a[k] for k in KEYS) if all(type(a.get(k)) in (int,float) for k in KEYS) else None
 out={'total':total,'attack':None,'strategy':None,'diplomacy':None,'skills':'未匹配','reference_total':None,'current_diplomacy':None,'match':'网站未收录同名；非无技能'}
 refs=INDEX.get(g.get('name'),[])
 if len(refs)!=1:
  if refs:out['match']='网站重名，未自动匹配'
  return out
 ref=refs[0];s=ref['stats'];skills=[x if isinstance(x,str) else x['name'] for x in ref.get('skills',[])]
 same=all(a.get(k)==s.get(v) for k,v in KEYS.items())
 out.update(attack=s.get('attack'),strategy=s.get('strategy'),diplomacy=diplomacy(s['politics'],s['charm'],skills),skills=' / '.join(skills) or '网站技能空表',reference_total=sum(s[v] for v in KEYS.values()),match='同名唯一 / 五维一致；技能为网站资料' if same else '同名参考 / 五维不同；请核对版本')
 if isinstance(out['strategy'],str):
  try:out['strategy']=float(out['strategy'].replace('%',''))
  except ValueError:out['strategy']=None
 if same:out['current_diplomacy']=diplomacy(a['pol'],a['cha'],skills)
 return out

def cells(g):
 m=officer_metrics(g)
 return tuple('—' if m[k] is None else m[k] for k in ('total','attack','strategy','diplomacy','reference_total','skills','match'))
COLUMNS=[('total','本局五维合计',105),('ref_attack','网站攻击力',100),('ref_strategy','网站计略 %',100),('ref_diplomacy','网站外交力',100),('ref_total','网站五维合计',105),('ref_skills','网站技能',380),('ref_match','资料匹配',260)]

SKILL_OPTIONS=['全部技能']+sorted({x if isinstance(x,str) else x['name'] for r in DATA['generals'] for x in r.get('skills',[])})
def eligible_wild(g,skill='全部技能'):
 m=officer_metrics(g)
 return m['diplomacy'] is not None and (skill=='全部技能' or skill in m['skills'].split(' / '))
