import sys
import unittest
from pathlib import Path
sys.path[:0] = [str(Path(__file__).resolve().parents[1] / 'app'), str(Path(__file__).resolve().parent)]

from city_talent import COLS, city_five_averages, city_for_officer, city_wild_officers, format_five_avg, summarize, SKILL_COLS


def officer(gid, city_id, name='甲', status=1, owner=65535, **attrs):
    return {
        'general_id_raw': gid, 'name': name, 'status_code': status, 'owner_raw': owner,
        'location_city_id': city_id, 'attributes': {'lead': 80, 'war': 80, 'intel': 80, 'pol': 80, 'cha': 80, **attrs},
    }


class CityTalentTests(unittest.TestCase):
    def test_city_for_officer_skips_barriers(self):
        state = {'entities': {'cities_and_barriers': [
            {'city_id': 1, 'name': '陈留', 'type': 'city'},
            {'city_id': 2, 'name': '武关', 'type': 'barrier'},
        ]}}
        self.assertEqual(city_for_officer(state, officer(9, 1))['name'], '陈留')
        self.assertIsNone(city_for_officer(state, officer(8, 2)))
        self.assertIsNone(city_for_officer(state, officer(7, None)))

    def test_city_wild_lists_same_city_only(self):
        city = {'city_id': 1, 'name': '陈留', 'type': 'city'}
        state = {'entities': {
            'cities_and_barriers': [city],
            'generals': [
                officer(1, 1, '孙尚香'),
                officer(2, 1, '黄月英', war=94),
                officer(3, 9, '别人'),
                officer(4, 1, '已仕', status=0, owner=3),
            ],
        }}
        names = [row['name'] for row in city_wild_officers(state, city)]
        self.assertEqual(names, ['黄月英', '孙尚香'])

    def test_city_avg_uses_known_five_and_drops_unknown_column(self):
        keys = [key for key, _title, _width in COLS]
        self.assertEqual(keys, ['name', 'owner', 'total', 'ride', 'bow', 'ambush', 'raid', 'thunder', 'navy', 'max', 'avg'])
        self.assertEqual([title for _key, title, _width in SKILL_COLS], ['骑', '弓', '埋伏', '突击', '天雷', '水军'])
        self.assertNotIn('n450', keys)
        self.assertNotIn('unknown', keys)
        source = (Path(__file__).resolve().parents[1] / 'app' / 'city_talent.py').read_text(encoding='utf-8')
        self.assertIn("bind('<ButtonRelease-1>',self.locate)", source)
        self.assertIn('show_city_wild=True', source)
        self.assertIn('identify_row', source)
        self.assertNotIn("bind('<<TreeviewSelect>>',self.locate)", source)
        self.assertNotIn('>450人数', source)
        self.assertNotIn('占本城%', source)
        self.assertNotIn('优先比较', source)
        self.assertEqual(format_five_avg(400), '400')
        self.assertEqual(format_five_avg(400.5), '400.5')
        city = {'city_id': 1, 'name': '陈留', 'type': 'city'}
        state = {'entities': {
            'cities_and_barriers': [city],
            'lords': [{'force_id': 3, 'name': '吴'}],
            'generals': [
                officer(1, 1, '完整甲'),
                officer(2, 1, '完整乙', lead=90, war=90, intel=90, pol=90, cha=90),
                officer(3, 1, '缺属性', cha=None),
                officer(4, 1, '已仕', status=0, owner=3),
            ],
        }}
        rows, meta = summarize(state)
        self.assertEqual(meta['total'], 3)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['total'], 3)
        self.assertEqual(rows[0]['max'], 450)
        self.assertEqual(rows[0]['avg'], 425)
        self.assertNotIn('unknown', rows[0])
        self.assertEqual(city_five_averages(state), {1: 425})
        self.assertEqual(rows[0]['ride'], 0)
        hub = (Path(__file__).resolve().parents[1] / 'app' / 'omni_window.py').read_text(encoding='utf-8')
        self.assertIn('if record is None and self.rendering_tables:return', hub)
        self.assertIn("('city_avg','平均五维',90)", hub)
        self.assertIn('format_five_avg(city_avgs.get(cid)', hub)
        self.assertNotIn('属性缺失', hub)

    def test_skill_counts_use_matched_website_skills(self):
        city = {'city_id': 1, 'name': '陈留', 'type': 'city'}
        wei_ge = officer(1, 1, '威哥', lead=115, war=70, intel=105, pol=95, cha=100)
        si_ma = officer(2, 1, '司马错', lead=87, war=82, intel=90, pol=63, cha=66)
        unmatched = officer(3, 1, '诸葛亮')
        state = {'entities': {
            'cities_and_barriers': [city],
            'lords': [{'force_id': 3, 'name': '吴'}],
            'generals': [wei_ge, si_ma, unmatched],
        }}
        row = summarize(state)[0][0]
        self.assertEqual(row['total'], 3)
        self.assertEqual(row['ride'], 2)
        self.assertEqual(row['bow'], 1)
        self.assertEqual(row['ambush'], 2)
        self.assertEqual(row['raid'], 2)
        self.assertEqual(row['thunder'], 1)
        self.assertEqual(row['navy'], 1)


if __name__ == '__main__':
    unittest.main()
