"""Read-only archive snapshot for Hub. Does not write the game."""
import copy
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BRIDGE = ROOT / 'bridge'
if str(BRIDGE) not in sys.path:
    sys.path.insert(0, str(BRIDGE))
if str(ROOT / 'app') not in sys.path:
    sys.path.insert(0, str(ROOT / 'app'))

from game_archive import IDLE_SEAL_S, ArchiveReader, list_archives
from match_opening import clamp_replay_seq, listed_archive
from state_history import calendar_label, phase_label


def _parse_utc(text):
    if not text:
        return None
    try:
        stamp = datetime.fromisoformat(str(text).replace('Z', '+00:00'))
    except ValueError:
        return None
    if stamp.tzinfo is None:
        stamp = stamp.replace(tzinfo=timezone.utc)
    return stamp


def is_live_recording(row, live_match_id=None, now=None, stale_s=IDLE_SEAL_S):
    """True only for the match still being written. Stuck open files are previous."""
    row = row or {}
    if live_match_id and row.get('match_id') == live_match_id:
        return True
    if not row.get('open'):
        return False
    if row.get('write_error') or row.get('completeness') == 'write_error':
        return False
    if row.get('completeness') not in (None, 'recording'):
        return True
    stamp = _parse_utc(row.get('last_capture_end'))
    if stamp is None:
        return True
    now = now or datetime.now(timezone.utc)
    return (now - stamp).total_seconds() < stale_s


def review_archives(root=None, live_match_id=None, now=None):
    """Same set as standalone 历史回放, minus the match still being written."""
    rows = []
    for row in list_archives(root):
        if not listed_archive(row):
            continue
        if is_live_recording(row, live_match_id=live_match_id, now=now):
            continue
        if not (row.get('last_seq') or row.get('frame_count')):
            continue
        rows.append(row)
    return rows


def previous_archive(root=None, live_match_id=None, now=None):
    rows = review_archives(root, live_match_id=live_match_id, now=now)
    return rows[0] if rows else None


def _archive_span(directory, reader=None):
    manifest = (reader.manifest if reader is not None else {}) or {}
    if reader is None:
        path = Path(directory) / 'manifest.json'
        manifest = json.loads(path.read_text(encoding='utf8')) if path.is_file() else {}
    count = int(manifest.get('frame_count') or manifest.get('last_seq') or 0)
    if reader is not None and count <= 0:
        count = reader.frame_count()
    start = manifest.get('opening_first_seq')
    if not isinstance(start, int) or start < 1:
        start = 1
    if count < 1:
        count = 1
    return start, count


def archive_time_nodes(directory):
    """Season (and opening/end) jump points. Reads index.json; does not decode frames."""
    path = Path(directory)
    start, count = _archive_span(path)
    index = {}
    idx_path = path / 'index.json'
    if idx_path.is_file():
        try:
            index = json.loads(idx_path.read_text(encoding='utf8'))
        except (OSError, json.JSONDecodeError, TypeError):
            index = {}
    nodes = []
    seen = set()

    def add(seq, label, kind, *, force=False):
        seq = clamp_replay_seq(seq, start, count)
        if seq in seen and not force:
            return
        if not force:
            seen.add(seq)
        nodes.append({'seq': seq, 'label': label, 'kind': kind})

    add(start, '开局', 'opening')
    rows = index.get('quarters') or []
    if not rows:
        rows = index.get('rounds') or []
    for row in rows:
        first = row.get('first_seq') or row.get('last_seq')
        if not isinstance(first, int) or first < start:
            continue
        pretty = calendar_label(row.get('year_u16'), row.get('season_u16'))
        rnd = row.get('round_u8')
        if pretty and rnd in (0, 1, 2):
            label = f'{pretty} 第{rnd + 1}回合'
        else:
            label = pretty or str(row.get('label') or f'帧{first}')
        add(first, label, 'quarter')
    add(count, '末帧', 'end', force=True)
    nodes.sort(key=lambda item: (item['seq'], 0 if item['kind'] != 'end' else 1))
    return nodes


def load_archive_frame(directory, seq=None):
    with ArchiveReader(directory) as reader:
        start, count = _archive_span(directory, reader)
        if reader.frame_count() <= 0:
            raise ValueError('档案没有帧')
        if seq is None:
            seq = count
        seq = clamp_replay_seq(seq, start, count)
        state = reader.load_frame(seq)
        return {
            'state': state,
            'seq': seq,
            'frame_count': count,
            'meta': reader.meta(seq),
            'manifest': dict(reader.manifest),
            'directory': str(reader.directory),
        }


def load_last_frame(directory):
    return load_archive_frame(directory, None)


def troop_series_from_archive(directory, until_seq=None):
    from force_troop_totals import append_troop_series, troop_series_point
    series = []
    with ArchiveReader(directory) as reader:
        seqs = []
        rows = reader.index.get('quarters') or []
        if not rows:
            rows = reader.index.get('rounds') or []
        for row in rows:
            seq = row.get('first_seq') or row.get('last_seq')
            if isinstance(seq, int):
                seqs.append(seq)
        count = reader.frame_count()
        if count:
            seqs.append(count)
        if isinstance(until_seq, int):
            seqs = [item for item in seqs if item <= until_seq]
            seqs.append(until_seq)
        for seq in sorted({item for item in seqs if 1 <= item <= count}):
            series = append_troop_series(series, troop_series_point(reader.load_frame(seq, clone=False)))
    return series


def attach_frame_history(state, directory=None, until_seq=None):
    doc = copy.deepcopy(state) if state else {}
    try:
        from force_troop_totals import append_troop_series, troop_series_point
        series = troop_series_from_archive(directory, until_seq=until_seq) if directory else []
        series = append_troop_series(series, troop_series_point(doc))
    except Exception:
        series = []
    history = dict(doc.get('history') or {})
    history['troop_series'] = series
    history['banner'] = '只读历史回放存档节点；档案不存逐季指令账，变化页可能空。完整指令用历史回放。'
    doc['history'] = history
    return doc


def attach_last_frame_history(state, directory=None):
    return attach_frame_history(state, directory)


def review_archive(archive, root=None, seq=None):
    if archive is None:
        raise ValueError('没有可选取的历史回放存档。')
    if isinstance(archive, (str, Path)):
        directory = Path(archive)
        target = directory.resolve() if directory.exists() else directory
        lookup = root or directory.parent
        row = next((item for item in list_archives(lookup)
                    if Path(item['directory']).resolve() == target
                    or Path(item['directory']) == directory), None)
        if row is None:
            row = {'directory': str(directory)}
    else:
        row = archive
        directory = row.get('directory')
        if not directory:
            raise ValueError('没有可选取的历史回放存档。')
    nodes = archive_time_nodes(directory)
    if seq is None and nodes:
        seq = nodes[-1]['seq']
    bundle = load_archive_frame(directory, seq)
    matches = [item['label'] for item in nodes if item['seq'] == bundle['seq']]
    label = matches[-1] if matches else None
    if bundle['seq'] == bundle['frame_count']:
        label = '末帧'
    bundle['node_label'] = label or f"帧{bundle['seq']}"
    bundle['archive'] = row
    bundle['state'] = attach_frame_history(bundle['state'], directory, until_seq=bundle['seq'])
    return bundle


def review_bundle(root=None, live_match_id=None, now=None):
    archive = previous_archive(root, live_match_id=live_match_id, now=now)
    if archive is None:
        raise ValueError('没有可选取的历史回放存档。')
    return review_archive(archive, root=root)


def status_line(bundle):
    manifest = (bundle or {}).get('manifest') or {}
    state = (bundle or {}).get('state') or {}
    title = manifest.get('title') or manifest.get('match_id') or '未标题'
    phase = phase_label(state.get('phase_candidate'))
    seq = bundle.get('seq') or 0
    count = bundle.get('frame_count') or 0
    node = bundle.get('node_label') or ('末帧' if seq == count else f'帧{seq}')
    return f'只读历史 · {node} {seq}/{count} · {title} · {phase}'
