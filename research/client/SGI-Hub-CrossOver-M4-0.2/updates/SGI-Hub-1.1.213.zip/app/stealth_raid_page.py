"""Dedicated Hub tab: pick a lord, show stealth turns and a slim route map."""
import tkinter as tk
from tkinter import ttk

from panorama_map import PanoramaMap
from player_view import player_id
from stealth_raid import format_raid_brief, raid_board

BG = '#1b1d18'
INK = '#efe7cf'
MUTED = '#b7ad8f'
BAR = '#2a2c24'
WELL = '#22241d'


class StealthRaidPage(tk.Frame):
    def __init__(self, parent, app=None):
        super().__init__(parent, bg=BG)
        self.app = app
        self.rows = []
        self._sig = None
        self.hint = tk.StringVar(value='确认我方后，点左侧君主看偷袭回合。地图只画城、部队和路线。')
        tk.Label(
            self, textvariable=self.hint, bg=BAR, fg='#e4c56a', anchor='w',
            justify='left', font=(getattr(app, 'face', None), 11), wraplength=980,
        ).pack(fill='x', padx=8, pady=(8, 4))
        body = tk.PanedWindow(
            self, orient='horizontal', sashwidth=8, bg='#3d3f34',
            sashrelief='raised', opaqueresize=False,
        )
        body.pack(fill='both', expand=True)
        self.map = PanoramaMap(body, title='偷袭主城', mode='raid')
        side = tk.Frame(body, bg=WELL, width=360)
        body.add(self.map, stretch='always', minsize=360)
        body.add(side, stretch='never', minsize=280)
        tk.Label(
            side, text='点君主看回合', bg=WELL, fg=INK, anchor='w',
            font=(getattr(app, 'face', None), 12, 'bold'),
        ).pack(fill='x', padx=10, pady=(10, 4))
        self.lords = tk.Listbox(
            side, bg='#2c2f26', fg=INK, selectbackground='#6a5520',
            font=(getattr(app, 'face', None), 11), relief='flat',
        )
        self.lords.pack(fill='both', expand=True, padx=10, pady=(0, 8))
        self.lords.bind('<<ListboxSelect>>', self._pick)
        self.note = tk.Label(
            side, text='', bg=WELL, fg=MUTED, justify='left', anchor='nw',
            font=(getattr(app, 'face', None), 10), wraplength=320,
        )
        self.note.pack(fill='x', padx=10, pady=(0, 12))
        side.bind('<Configure>', self._wrap)

    def _wrap(self, event=None):
        width = max(200, (event.width if event else self.note.winfo_width()) - 24)
        self.note.configure(wraplength=width)

    def refresh(self, state):
        sig = None if not state else (state.get('snapshot_id'), player_id(state))
        self.map.update_state(state, lists=False, refresh_view=False)
        if sig == self._sig and self.rows:
            return
        self._sig = sig
        keep = None
        if self.lords.curselection() and self.rows:
            keep = self.rows[self.lords.curselection()[0]].get('force_id')
        self.rows = raid_board(state)
        self.lords.delete(0, 'end')
        if player_id(state) is None:
            self.hint.set('未确认我方，不能算偷袭。')
            self.note.config(text='先在顶栏确认我方。')
            self.map.show_raid(None)
            return
        if not self.rows:
            self.hint.set('这一帧没有其他势力首都。')
            self.note.config(text='')
            self.map.show_raid(None)
            return
        index = 0
        for i, row in enumerate(self.rows):
            turns = f"{row['turns']}回" if row.get('ok') and row.get('turns') is not None else '无路'
            origin = row.get('origin_name') or ''
            war = '交战 · ' if row.get('war') else ''
            line = f"{war}{row['force_name']}  {row['city_name']}  {turns}"
            if origin:
                line += f"  从{origin}"
            self.lords.insert('end', line)
            if keep is not None and row.get('force_id') == keep:
                index = i
        self.lords.selection_clear(0, 'end')
        self.lords.selection_set(index)
        self.lords.see(index)
        self._apply(index)

    def _pick(self, _=None):
        selection = self.lords.curselection()
        if not selection:
            return
        self._apply(selection[0])

    def _apply(self, index):
        if index < 0 or index >= len(self.rows):
            return
        row = self.rows[index]
        plan = row.get('plan')
        self.map.show_raid(plan if row.get('ok') else None)
        if row.get('ok'):
            self.hint.set(format_raid_brief(plan))
            self.note.config(text=plan.get('detail') or row.get('reason') or '')
            origin = plan.get('origin')
            dest = plan.get('dest')
            if origin and dest:
                self.map.center = ((origin[0] + dest[0]) / 2 + 0.5, (origin[1] + dest[1]) / 2 + 0.5)
                span = max(abs(origin[0] - dest[0]), abs(origin[1] - dest[1]), 16)
                self.map.zoom = max(0.4, min(2.4, 36 / span))
                self.map.draw(refresh_view=False)
        else:
            self.hint.set(row.get('reason') or '算不出这条偷袭。')
            self.note.config(text=row.get('reason') or '')
