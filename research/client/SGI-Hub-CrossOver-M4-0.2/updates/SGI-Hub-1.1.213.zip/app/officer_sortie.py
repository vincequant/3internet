"""Single-officer sortie preview from current troop size. Not engine damage."""
from preparation_model import combat_power, size_index, skills_for, training_bases
from unit_target_attack import rnd, supported_combat_build

KINDS = ('infantry', 'cavalry', 'bow')
KIND_LABEL = {'infantry': '步', 'cavalry': '骑', 'bow': '弓'}
SIZES = ('小队', '中队', '大队')
KIND_SKILL = {'cavalry': '骑马', 'bow': '弓箭'}
AMBUSH_SKILLS = frozenset({'埋伏', '伏兵'})
PINNED_SKILL_NAMES = frozenset({'骑马', '弓箭'}) | AMBUSH_SKILLS
PINNED_SKILL_GROUPS = (
    ('ride', frozenset({'骑马'})),
    ('bow', frozenset({'弓箭'})),
    ('ambush', AMBUSH_SKILLS),
)
ALL_SKILLS = '全技能'
AMBUSH_INK = '#8a5a00'
AMBUSH_INK_DARK = '#d4a017'


def kind_skill_flags(officer):
    skills = skills_for(officer)
    return {kind: name in skills for kind, name in KIND_SKILL.items()}


def _skill_parts(skills_text):
    return {part.strip() for part in str(skills_text or '').split(' / ') if part.strip()}


def pinned_skill_flags_from_text(skills_text):
    parts = _skill_parts(skills_text)
    all_on = ALL_SKILLS in parts
    return {key: all_on or bool(parts & names) for key, names in PINNED_SKILL_GROUPS}


def pinned_skill_cells(skills_text):
    flags = pinned_skill_flags_from_text(skills_text)
    return {key: ('●' if on else '—') for key, on in flags.items()}


def remaining_skill_text(skills_text):
    parts = [part.strip() for part in str(skills_text or '').split(' / ') if part.strip()]
    if not parts:
        return '—'
    kept = [part for part in parts if part not in PINNED_SKILL_NAMES]
    return ' / '.join(kept) if kept else '—'


def has_ambush_skill(officer):
    skills = skills_for(officer)
    return ALL_SKILLS in skills or bool(skills & AMBUSH_SKILLS)


def resolved_officers(state, general_ids):
    by_id = {}
    for officer in ((state or {}).get('entities') or {}).get('generals') or []:
        by_id.setdefault(officer.get('general_id_raw'), []).append(officer)
    found = []
    for gid in general_ids or []:
        matches = by_id.get(gid) or []
        if len(matches) == 1:
            found.append(matches[0])
    return found


def unit_has_ambush(state, unit):
    return any(has_ambush_skill(officer) for officer in resolved_officers(state, (unit or {}).get('general_ids')))


def taken_soldiers(officer, force, kind):
    soldiers = (officer or {}).get('soldiers')
    if type(soldiers) is not int or soldiers <= 0:
        return None
    stock = ((force or {}).get('troop_stock') or {}).get(kind)
    if type(stock) is int:
        taken = min(soldiers, stock)
        if taken <= 0:
            return None
        return taken, soldiers, stock, stock < soldiers
    return soldiers, soldiers, None, False


def kind_preview(officer, force, kind):
    taken = taken_soldiers(officer, force, kind)
    if not taken:
        return None
    soldiers, capacity, stock, capped = taken
    power = combat_power([officer])
    bases = training_bases(kind, ((force or {}).get('armament_raw') or {}).get(kind))
    size = size_index(soldiers)
    if not bases or power is None or not 0 <= power <= 150:
        return None
    factor = bases['unit'][size]
    if factor is None:
        return None
    return {
        'kind': kind, 'name': bases['name'], 'training': bases['training'],
        'soldiers': soldiers, 'capacity': capacity, 'stock': stock,
        'size': size, 'size_label': SIZES[size], 'power': power,
        'factor': factor, 'attack': rnd(factor * power / 150), 'capped': capped,
    }


def officer_previews(officer, force, state=None):
    if state is not None and not supported_combat_build(state.get('build_sha256')):
        return {kind: None for kind in KINDS}
    return {kind: kind_preview(officer, force, kind) for kind in KINDS}


def format_preview(preview):
    if not preview or preview.get('attack') is None:
        return '—'
    return str(preview['attack'])


def officer_cells(officer, force, state=None):
    previews = officer_previews(officer, force, state)
    return {kind: format_preview(previews[kind]) for kind in KINDS}
