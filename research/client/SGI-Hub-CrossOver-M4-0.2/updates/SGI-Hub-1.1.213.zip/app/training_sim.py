"""Force-level camp/train simulator. Opening stocks from archives; four missing nations from website."""
import copy
from training_prediction import COEFF, muldiv, stock_training_base

KINDS = ('infantry', 'cavalry', 'bow')
KIND_CN = {'infantry': '步', 'cavalry': '骑', 'bow': '弓'}
CAMP_CN = {'infantry': '练兵所', 'cavalry': '牧场', 'bow': '弓工坊'}
SEASON_CN = ('春', '夏', '秋', '冬')
NAMES = {
    'infantry': ('步兵', '强化步兵', '重装步兵'),
    'cavalry': ('骑兵', '强化骑兵', '铁骑兵'),
    'bow': ('弓兵', '弩兵', '连弩'),
}
# Archive-measured medians (9 player matches).
CAMP_YIELD = {'infantry': 14165, 'cavalry': 3225, 'bow': 9240}
GOAL_STOCK = 100000
GOAL_RAW = 200
COMMANDS_PER_SEASON = 3
START_YEAR = 200
POL = 100
# 9 player matches, complete force-years only (saw a later year or all four seasons).
YEAR_PACE = {
    'year1': {'n': 38, 'build_mean': 0.58, 'train_mean': 4.29, 'build_median': 0, 'train_median': 4, 'civil_mean': 4.87},
    'later': {'n': 64, 'build_mean': 0.44, 'train_mean': 4.31, 'build_median': 0, 'train_median': 4, 'civil_mean': 4.75},
}
PACE_NOTE = (
    '存档节奏：一国一年大约盖 0.5 座、练 4 次；第一年 0.58/4.3，之后 0.44/4.3，几乎一样。'
    '一年 12 格，大约 5 格用在盖营或训练。推算按每年最多练 4；第一年最多盖 1，之后隔年盖 1。'
)

# force_id, name, stock, raw, summer camp, source
OPENING = (
    (0, '魏', (30000, 10000, 20000), (190, 130, 130), (1500, 6500, 1500), 'archive'),
    (1, '赵', (20000, 40000, 0), (101, 150, 0), (4300, 500, 0), 'archive'),
    (2, '韩', (20000, 6000, 30000), (200, 100, 160), (5800, 500, 4000), 'archive'),
    (3, '齐', (40000, 30000, 0), (190, 150, 0), (1600, 3000, 0), 'archive'),
    (4, '楚', (20000, 20000, 20000), (150, 150, 130), (1000, 1500, 1500), 'archive'),
    (5, '燕', (5000, 30000, 0), (50, 180, 0), (4800, 6000, 0), 'archive'),
    (6, '秦', (40000, 5000, 3000), (300, 0, 230), (2100, 1000, 0), 'archive'),
    (7, '晋', (30000, 30000, 0), (180, 150, 0), (1100, 2000, 0), 'archive'),
    (8, '吴', (20000, 2000, 40000), (110, 230, 180), (0, 0, 0), 'website'),
    (9, '越', (10000, 20000, 20000), (130, 150, 130), (1000, 3500, 1500), 'archive'),
    (10, '周', (30000, 20000, 20000), (180, 120, 130), (5700, 1100, 0), 'archive'),
    (11, '宋', (30000, 10000, 20000), (200, 100, 180), (500, 1000, 5800), 'archive'),
    (12, '鲁', (20000, 30000, 0), (150, 180, 0), (1000, 3000, 0), 'archive'),
    (13, '义渠', (20000, 45000, 0), (70, 200, 0), (0, 4000, 0), 'archive'),
    (14, '西凉', (10000, 20000, 20000), (0, 240, 120), (0, 0, 0), 'website'),
    (15, '中山', (30000, 20000, 0), (240, 150, 0), (0, 0, 0), 'website'),
    (16, '代', (20000, 30000, 0), (150, 170, 0), (0, 0, 0), 'website'),
    (17, '蜀', (30000, 10000, 40000), (160, 150, 150), (4200, 500, 4500), 'archive'),
    (18, '巴', (35000, 30000, 0), (150, 150, 0), (3100, 500, 500), 'archive'),
    (19, '南蛮', (30000, 30000, 0), (150, 180, 0), (2000, 3500, 5000), 'archive'),
    (20, '汉', (20000, 20000, 20000), (100, 150, 150), (2000, 9500, 2000), 'archive'),
    (21, '羌', (20000, 30000, 0), (100, 200, 0), (500, 4000, 1000), 'archive'),
)
BY_ID = {row[0]: row for row in OPENING}
BY_NAME = {row[1]: row for row in OPENING}

ACTIONS = (
    ('train:infantry', '练步'),
    ('train:cavalry', '练骑'),
    ('train:bow', '练弓'),
    ('build:infantry', '盖练兵所'),
    ('build:cavalry', '盖牧场'),
    ('build:bow', '盖弓工坊'),
    ('other', '其他指令'),
)


def pack_kinds(values):
    return {kind: int(values[i]) for i, kind in enumerate(KINDS)}


def troop_label(kind, raw):
    if not isinstance(raw, int) or not 0 <= raw <= 300:
        return '未知'
    tier = 0 if raw < 100 else 1 if raw < 200 else 2
    degree = 100 if raw >= 300 else raw % 100
    return f"{NAMES[kind][tier]} {degree}/100"


def train_gain(kind, stock):
    base = stock_training_base(stock if isinstance(stock, int) else 0)
    a, b = COEFF[kind]
    return muldiv(base, a * POL, b * 50)


def mix_recruit(raw, stock, added):
    if not isinstance(added, int) or added <= 0:
        return raw, stock
    incoming = raw * 3 // 5
    new_stock = stock + added
    return (raw * stock + incoming * added) // new_stock, new_stock


def opening_state(force_id=None, name=None):
    row = BY_ID.get(force_id) if force_id is not None else None
    if row is None:
        row = BY_NAME.get(name)
    if row is None:
        return None
    fid, fname, stock, raw, camp, source = row
    return {
        'force_id': fid,
        'name': fname,
        'source': source,
        'year': START_YEAR,
        'season': 0,
        'slot': 0,
        'stock': pack_kinds(stock),
        'raw': pack_kinds(raw),
        'camp': pack_kinds(camp),
        'build': 0,
        'train': 0,
        'other': 0,
        'log': [],
        'reached': {},
    }


def phase_text(state):
    return f"{state['year']}年{SEASON_CN[state['season']]} 第{state['slot'] + 1}/{COMMANDS_PER_SEASON} 指令"


def counts(state):
    return state['build'] + state['train']


def goal_hit(state, kind):
    return state['stock'][kind] >= GOAL_STOCK and state['raw'][kind] >= GOAL_RAW


def _mark_reached(state, note):
    for kind in KINDS:
        if kind in state['reached'] or not goal_hit(state, kind):
            continue
        state['reached'][kind] = {
            'build': state['build'],
            'train': state['train'],
            'other': state['other'],
            'total': counts(state),
            'year': state['year'],
            'season': state['season'],
            'note': note,
        }


def _advance(state):
    state['slot'] += 1
    if state['slot'] < COMMANDS_PER_SEASON:
        return
    state['slot'] = 0
    state['season'] += 1
    if state['season'] >= 4:
        state['season'] = 0
        state['year'] += 1
    if state['season'] == 1:
        _summer(state)


def _summer(state):
    bits = []
    for kind in KINDS:
        added = state['camp'][kind]
        before_raw, before_stock = state['raw'][kind], state['stock'][kind]
        state['raw'][kind], state['stock'][kind] = mix_recruit(before_raw, before_stock, added)
        if added:
            bits.append(
                f"{KIND_CN[kind]}+{added:,} {before_raw}→{state['raw'][kind]} 库存{before_stock:,}→{state['stock'][kind]:,}"
            )
    line = f"{state['year']}年夏 收兵 " + ('；'.join(bits) if bits else '无新增')
    state['log'].append(line)
    _mark_reached(state, line)


def apply_action(state, action):
    state = copy.deepcopy(state)
    kind = None
    if action.startswith('train:') or action.startswith('build:'):
        kind = action.split(':', 1)[1]
        if kind not in KINDS:
            raise ValueError(action)
    label = dict(ACTIONS).get(action, action)
    when = phase_text(state)
    if action.startswith('train:'):
        gain = train_gain(kind, state['stock'][kind])
        raw0 = state['raw'][kind]
        state['raw'][kind] = min(300, raw0 + gain)
        state['train'] += 1
        note = f"{when} {label} {raw0}→{state['raw'][kind]}（+{state['raw'][kind] - raw0}，库存{state['stock'][kind]:,}）"
    elif action.startswith('build:'):
        add = CAMP_YIELD[kind]
        state['camp'][kind] += add
        state['build'] += 1
        note = f"{when} {label} +{add:,} 夏募→{state['camp'][kind]:,}"
    elif action == 'other':
        state['other'] += 1
        note = f"{when} {label}"
    else:
        raise ValueError(action)
    state['log'].append(note)
    _mark_reached(state, note)
    _advance(state)
    return state


def year_build_cap(year):
    if not isinstance(year, int):
        return 1
    if year <= START_YEAR:
        return 1
    return 1 if (year - START_YEAR) % 2 == 0 else 0


def year_train_cap(year):
    return 4


def project_goal(state, kind):
    """Build/train this kind with archive yearly pace, wait for summer, then train to 200."""
    if kind not in KINDS:
        raise ValueError(kind)
    if goal_hit(state, kind):
        return {
            'ok': True, 'build': 0, 'train': 0, 'other': 0, 'total': 0,
            'year': state['year'], 'season': state['season'],
            'stock': state['stock'][kind], 'raw': state['raw'][kind],
        }
    cur = copy.deepcopy(state)
    used = {'year': cur['year'], 'build': 0, 'train': 0}
    steps = 0
    while steps < 960:
        if goal_hit(cur, kind):
            hit = cur['reached'][kind]
            return {
                'ok': True,
                'build': hit['build'] - state['build'],
                'train': hit['train'] - state['train'],
                'other': hit['other'] - state['other'],
                'total': (hit['build'] - state['build']) + (hit['train'] - state['train']),
                'year': hit['year'],
                'season': hit['season'],
                'stock': cur['stock'][kind],
                'raw': cur['raw'][kind],
            }
        if cur['year'] != used['year']:
            used = {'year': cur['year'], 'build': 0, 'train': 0}
        need = GOAL_STOCK - cur['stock'][kind]
        if need > 0 and cur['camp'][kind] < need and used['build'] < year_build_cap(cur['year']):
            action = 'build:' + kind
            used['build'] += 1
        elif need <= 0 and used['train'] < year_train_cap(cur['year']):
            action = 'train:' + kind
            used['train'] += 1
        else:
            action = 'other'
        cur = apply_action(cur, action)
        steps += 1
    return {'ok': False, 'build': None, 'train': None, 'total': None}


def from_live_force(force, recruit=None):
    if not force:
        return None
    stock = force.get('troop_stock') or {}
    raw = force.get('armament_raw') or {}
    camp = {}
    for kind in KINDS:
        if not isinstance(stock.get(kind), int) or not isinstance(raw.get(kind), int):
            return None
        known = (recruit or {}).get(kind) or {}
        camp[kind] = known.get('known') if isinstance(known.get('known'), int) else 0
    return {
        'force_id': force.get('force_id'),
        'name': force.get('name') or '当前',
        'source': 'live',
        'year': START_YEAR,
        'season': 0,
        'slot': 0,
        'stock': {k: stock[k] for k in KINDS},
        'raw': {k: raw[k] for k in KINDS},
        'camp': camp,
        'build': 0,
        'train': 0,
        'other': 0,
        'log': [],
        'reached': {},
    }
