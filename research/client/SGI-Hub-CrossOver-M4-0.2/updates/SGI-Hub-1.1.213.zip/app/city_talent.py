"""City talent: wild concentration plus website-matched skill counts."""
import math
import tkinter as tk
from tkinter import ttk
from preparation_model import skills_for
from wild_locations import wild_location_groups
ALL_SKILLS='全技能'
SKILL_COLS=(
 ('ride','骑',frozenset({'骑马'})),
 ('bow','弓',frozenset({'弓箭'})),
 ('ambush','埋伏',frozenset({'埋伏','伏兵'})),
 ('raid','突击',frozenset({'奇袭'})),
 ('thunder','天雷',frozenset({'天雷'})),
 ('navy','水军',frozenset({'水军'})),
)
KEYS=('lead','war','intel','pol','cha')
WILD_COLS=(
    ('name','姓名',90),('id','将ID',60),
    ('lead','统',40),('war','武',40),('intel','智',40),('pol','政',40),('cha','魅',40),
    ('total','五维',55),
)


def five_total(officer):
    attrs = officer.get('attributes') or {}
    values = [attrs.get(key) for key in KEYS]
    if all(type(value) in (int, float) and math.isfinite(value) and value >= 0 for value in values):
        return sum(values)
    return None


def known_five_totals(officers):
    return [total for total in (five_total(officer) for officer in officers or []) if total is not None]


def city_five_avg(officers):
    totals = known_five_totals(officers)
    if not totals:
        return None
    return sum(totals) / len(totals)


def format_five_avg(value):
    if value is None:
        return '—'
    if abs(value - round(value)) < 1e-9:
        return str(int(round(value)))
    return f'{value:.1f}'


def city_five_averages(state):
    rows, _meta = summarize(state)
    return {row['city'].get('city_id'): row['avg'] for row in rows}


def city_for_officer(state, officer):
    city_id = (officer or {}).get('location_city_id')
    if type(city_id) is not int:
        return None
    for city in ((state or {}).get('entities') or {}).get('cities_and_barriers') or []:
        if city.get('city_id') == city_id and city.get('type') != 'barrier':
            return city
    return None


def city_wild_officers(state, city):
    """Wild officers currently located in this city. Barriers stay excluded."""
    city_id = city.get('city_id') if city else None
    if type(city_id) is not int:
        return []
    wild, _hidden = wild_location_groups(state or {})
    rows = [officer for officer in wild if officer.get('location_city_id') == city_id]
    rows.sort(key=lambda officer: (five_total(officer) is not None, five_total(officer) or 0,
                                   officer.get('general_id_raw') or 0), reverse=True)
    return rows


def listed_skill_count(officers, names):
 n=0
 for officer in officers or []:
  skills=skills_for(officer)
  if ALL_SKILLS in skills or skills & names:
   n+=1
 return n
def summarize(state):
 entities=state.get('entities',{});wild,hidden=wild_location_groups(state)
 cities=entities.get('cities_and_barriers',[]);ids=[c.get('city_id') for c in cities]
 unique={i for i in ids if i is not None and ids.count(i)==1};groups={i:[] for i in unique};unlocated=0
 for g in wild:
  cid=g.get('location_city_id')
  if cid in groups:groups[cid].append(g)
  else:unlocated+=1
 forces={f['force_id']:f.get('name','未知') for f in entities.get('lords',[])};rows=[]
 for c in cities:
  if c.get('city_id') not in unique or c.get('type')=='barrier':continue
  gs=groups[c['city_id']];totals=known_five_totals(gs)
  row={'city':c,'name':c.get('name','?'),'owner':forces.get(c.get('owner_raw'),'无主/未知'),'total':len(gs),'max':max(totals) if totals else None,'avg':city_five_avg(gs)}
  for key,_title,names in SKILL_COLS:
   row[key]=listed_skill_count(gs, names)
  rows.append(row)
 return rows,{'total':len(wild),'unlocated':unlocated,'hidden_barriers':len(hidden)}
COLS=[('name','城池',85),('owner','势力',60),('total','在野总数',85)]
COLS.extend((key,title,55) for key,title,_names in SKILL_COLS)
COLS.extend([('max','最高五维',90),('avg','平均五维',90)])
class CityTalent(tk.Frame):
 def __init__(self,parent,app):
  super().__init__(parent,bg='#f7f4ea');self.app=app;self.rows={};self.order=('total',True);self.busy=False
  bar=tk.Frame(self,bg='#f7f4ea');bar.pack(fill='x',padx=8,pady=6)
  tk.Label(bar,text='城池 / 势力',bg='#f7f4ea').pack(side='left');self.query=tk.StringVar();tk.Entry(bar,textvariable=self.query).pack(side='left',fill='x',expand=True,padx=6);self.query.trace_add('write',lambda *_:self.refresh())
  self.note=tk.Label(self,bg='#f7f4ea',fg='#675937',anchor='w',justify='left',wraplength=1050);self.note.pack(fill='x',padx=8,pady=4)
  box=tk.Frame(self);box.pack(fill='both',expand=True);self.tree=ttk.Treeview(box,columns=[k for k,_,_ in COLS],show='headings')
  for k,title,width in COLS:self.tree.heading(k,text=title,command=lambda key=k:self.sort(key));self.tree.column(k,width=width,stretch=False)
  y=ttk.Scrollbar(box,command=self.tree.yview);x=ttk.Scrollbar(box,orient='horizontal',command=self.tree.xview);self.tree.configure(yscrollcommand=y.set,xscrollcommand=x.set);x.pack(side='bottom',fill='x');y.pack(side='right',fill='y');self.tree.pack(fill='both',expand=True)
  self.tree.bind('<ButtonRelease-1>',self.locate);self.tree.bind('<Double-1>',self.locate)
 def sort(self,key):self.order=(key,not self.order[1] if self.order[0]==key else True);self.refresh()
 def refresh(self):
  if not self.app.doc:return
  rows,meta=summarize(self.app.doc);q=self.query.get().strip().lower();rows=[r for r in rows if not q or q in (r['name']+' '+r['owner']).lower()]
  key,reverse=self.order
  def value(r):return (r.get(key) is not None,r[key] if r.get(key) is not None else 0,r['total'],r['max'] or 0)
  rows.sort(key=value,reverse=reverse)
  self.note.configure(text=f"全图在野 {meta['total']} 人 · 已隐藏关隘 {meta['hidden_barriers']} 人 · 所在城未确认 {meta['unlocated']} 人。骑/弓/埋伏/突击/天雷/水军是本城在野里网站资料具备该技能的人数；突击按奇袭计，全技能计入各项。未同名且五维一致的不计入。点列头排序，点城池打开本城在野武将。")
  self.busy=True;self.tree.delete(*self.tree.get_children());self.rows={}
  for i,row in enumerate(rows):
   vals=['—' if row[k] is None else format_five_avg(row[k]) if k=='avg' else row[k] for k,_,_ in COLS]
   self.tree.insert('','end',iid=str(i),values=vals);self.rows[str(i)]=row
  self.busy=False
 def locate(self,event=None):
  if self.busy:return
  iid=None
  if event is not None and getattr(event,'y',None) is not None:
   iid=self.tree.identify_row(event.y)
   if iid:self.tree.selection_set(iid)
  if not iid:
   ids=self.tree.selection();iid=ids[0] if ids else None
  if iid and iid in self.rows:
   self.app.locate_object('cities',self.rows[iid]['city'],show_city_wild=True,nation_view=True)


class CityWildPanel(tk.Frame):
 def __init__(self,parent,app=None):
  super().__init__(parent,bg='#f7f4ea')
  self.app=app;self.rows={};self.city=None;self.state=None;self.busy=False
  self.heading=tk.Label(self,bg='#f7f4ea',fg='#3f3420',anchor='w',justify='left',font=('Microsoft YaHei',12,'bold'))
  self.heading.pack(fill='x',padx=10,pady=(10,2))
  self.note=tk.Label(self,bg='#f7f4ea',fg='#675937',anchor='w',justify='left',wraplength=1080)
  self.note.pack(fill='x',padx=10)
  self.detail=tk.Label(self,bg='#f4efe0',fg='#3f3420',anchor='w',justify='left',wraplength=1080)
  self.detail.pack(fill='x',padx=10,pady=6)
  box=tk.Frame(self);box.pack(fill='both',expand=True,padx=8,pady=(0,8))
  self.tree=ttk.Treeview(box,columns=[key for key,_,_ in WILD_COLS],show='headings')
  for key,title,width in WILD_COLS:
   self.tree.heading(key,text=title);self.tree.column(key,width=width,stretch=False)
  y=ttk.Scrollbar(box,command=self.tree.yview);self.tree.configure(yscrollcommand=y.set)
  y.pack(side='right',fill='y');self.tree.pack(fill='both',expand=True)
  self.tree.bind('<<TreeviewSelect>>',self.pick)
  self.clear()

 def clear(self,text='点城池后列出该城在野武将及统武智政魅。'):
  self.city=None;self.state=None;self.rows={}
  self.heading.configure(text='本城在野')
  self.note.configure(text=text)
  self.detail.configure(text='')
  self.busy=True;self.tree.delete(*self.tree.get_children());self.busy=False

 def focus(self,state,city,officer=None):
  self.state=state;self.city=dict(city or {})
  officers=city_wild_officers(state,self.city)
  name=self.city.get('name') or '该城'
  self.heading.configure(text=f'{name} · 在野 {len(officers)} 人')
  self.note.configure(text='只含当前采集到的在野（不含关隘隐藏、已仕、俘虏）。点一行看完整属性；可再切到全图定位或城周边。')
  self.busy=True;self.tree.delete(*self.tree.get_children());self.rows={}
  selected='0'
  want=None if officer is None else officer.get('general_id_raw')
  for index,row in enumerate(officers):
   attrs=row.get('attributes') or {}
   total=five_total(row)
   values=(
    row.get('name') or '姓名未解码',
    row.get('general_id_raw') if row.get('general_id_raw') is not None else '—',
    *[attrs[key] if type(attrs.get(key)) in (int,float) else '—' for key in KEYS],
    total if total is not None else '—',
   )
   iid=str(index);self.tree.insert('','end',iid=iid,values=values);self.rows[iid]=row
   if want is not None and row.get('general_id_raw')==want:
    selected=iid
  self.busy=False
  self.detail.configure(text='点列表中的武将查看属性。' if officers else f'{name} 当前没有可显示的在野武将。')
  if officers:
   self.tree.selection_set(selected);self.tree.see(selected);self.pick()

 def pick(self,_=None):
  if self.busy:return
  ids=self.tree.selection()
  if not ids or ids[0] not in self.rows:return
  officer=self.rows[ids[0]]
  attrs=officer.get('attributes') or {}
  total=five_total(officer)
  parts=[f"{officer.get('name') or '姓名未解码'}  ID {officer.get('general_id_raw','?')}"]
  parts.append('  '.join(f'{label} {attrs[key] if type(attrs.get(key)) in (int,float) else "—"}'
                         for key,label in (('lead','统'),('war','武'),('intel','智'),('pol','政'),('cha','魅'))))
  if total is not None:
   parts.append(f'五维合计 {total}')
  self.detail.configure(text='　'.join(parts))
  locator=getattr(self.app,'object_locator',None)
  if locator is not None and self.state is not None:
   locator.update_state(self.state)
   locator.focus_officer(officer,recenter=False)
