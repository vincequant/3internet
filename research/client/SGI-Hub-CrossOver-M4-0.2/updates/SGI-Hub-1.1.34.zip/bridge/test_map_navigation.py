import sys,unittest
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'app'))
from map_navigation import move_center
from city_tactical import CityTactical,nearby
from native_city_map import CityLocator

class NavigationTests(unittest.TestCase):
 def test_bounds_and_directions(self):
  self.assertEqual(move_center((0,201),-1,1),(0,201))
  self.assertEqual(move_center((50,100),1,-1,2),(52,98))
 def test_tactical_pan_keeps_anchor_and_moves_visible_entities(self):
  anchor={'world_xy_raw':[20,20]}
  view=SimpleNamespace(city=anchor,view_center=None,render=lambda:None)
  CityTactical.pan(view,0,-1);self.assertEqual(view.view_center,(20,18))
  CityTactical.pan(view,1,0);self.assertEqual(view.view_center,(21,18))
  self.assertEqual(anchor['world_xy_raw'],[20,20])
  CityTactical.return_target(view);self.assertIsNone(view.view_center)
 def test_selected_unit_recenters(self):
  view=SimpleNamespace(selected='u',items={'u':('部队',{'world_xy_raw':[45,60]},'u')},render=lambda:None)
  CityTactical.recenter_selected(view);self.assertEqual(view.view_center,(45,60))
 def test_fullmap_click_unit(self):
  record={'type':'field_unit','unit_id':8,'world_xy_raw':[20,20]}
  calls=[]
  view=SimpleNamespace(state={'entities':{'cities_and_barriers':[],'field_units':[record]}},
       show_units=SimpleNamespace(get=lambda:True),project=lambda x,y:(x,y),entity_target=None,
       entity_key=CityLocator.entity_key,focus_entity=lambda k,r:calls.append((k,r)))
  CityLocator.click_city(view,SimpleNamespace(x=20,y=20))
  self.assertEqual(calls,[('field_units',record)])
 def test_fullmap_pan_and_reset(self):
  view=SimpleNamespace(center=(50.5,100.5),zoom=2,world=(101,202),draw=lambda:None,
       target_record={'world_xy_raw':[40,60]})
  CityLocator.pan(view,-1,0);self.assertEqual(view.center,(44.5,100.5))
  CityLocator.return_target(view);self.assertEqual(view.center,(40.5,60.5))
