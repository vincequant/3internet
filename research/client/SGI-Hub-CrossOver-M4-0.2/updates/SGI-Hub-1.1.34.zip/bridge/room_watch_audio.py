"""Restore PlayBGM from Setting.ini. Never delete music files or guess defaults."""
import re
from pathlib import Path


def decode_ini(raw):
    for encoding in ('gbk', 'utf-8-sig', 'utf-8'):
        try:
            return raw.decode(encoding), encoding
        except UnicodeDecodeError:
            continue
    raise ValueError('无法解码 Setting.ini')


def read_play_bgm(path):
    text, encoding = decode_ini(Path(path).read_bytes())
    match = re.search(r'(?m)^PlayBGM\s*=\s*(\d+)\s*$', text)
    if not match:
        raise ValueError('Setting.ini 没有 PlayBGM')
    value = int(match.group(1))
    if value not in (0, 1):
        raise ValueError('PlayBGM 不是可恢复的 0/1')
    return value, text, encoding


def write_play_bgm(path, value):
    if value not in (0, 1):
        raise ValueError('只能写入 PlayBGM=0 或 1')
    path = Path(path)
    text, encoding = decode_ini(path.read_bytes())
    new, count = re.subn(r'(?m)^(PlayBGM\s*=\s*)\d+(\s*)$', rf'\g<1>{value}\2', text, count=1)
    if count != 1:
        raise ValueError('无法唯一改写 PlayBGM')
    temp = path.with_name(path.name + '.room-watch-tmp')
    temp.write_bytes(new.encode(encoding))
    temp.replace(path)
    return value


def setting_candidates(exe_path=None, prefix=None):
    found = []
    if exe_path:
        found.append(Path(exe_path).with_name('Setting.ini'))
    if prefix:
        found.append(Path(prefix) / 'drive_c/sgi/run-3.5/3I/Setting.ini')
    return found


def resolve_setting_ini(exe_path=None, prefix=None):
    for path in setting_candidates(exe_path, prefix):
        if path.is_file():
            return path
    raise FileNotFoundError('找不到游戏 Setting.ini')
