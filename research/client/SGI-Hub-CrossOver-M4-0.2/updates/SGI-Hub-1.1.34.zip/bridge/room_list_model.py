"""Audited KOEINM room records and conservative notification policy."""
import struct
import math
import time

def validate_alert_settings(threshold, minutes):
    x=float(threshold); y=float(minutes)
    if not math.isfinite(x) or not x.is_integer() or not 0<=x<=63:
        raise ValueError('X 必须是 0–63 的整数')
    if not math.isfinite(y) or not .1<=y<=1440:
        raise ValueError('Y 必须在 0.1–1440 分钟之间')
    return int(x),y

def decode_room(raw):
    if len(raw) != 80:
        raise ValueError('房间记录长度不匹配')
    maximum, current, version = struct.unpack_from('<III', raw, 68)
    if not 1 <= current <= maximum <= 64:
        raise ValueError('房间人数数据不合法')
    def name(part):
        if b'\0' not in part:
            raise ValueError('房间名称未结束')
        return part.split(b'\0')[0].decode('gbk', 'replace')
    room, host = name(raw[4:35]), name(raw[35:66])
    if not room or not host:
        raise ValueError('房间名称为空')
    return {'id':str(struct.unpack_from('<I',raw)[0]), 'name':f'{room}[{host}]',
            'current':current, 'maximum':maximum, 'version':version}

class AlertState:
    def __init__(self, threshold=4, minutes=1):
        self.configure(threshold,minutes)
        self.last_alert = None

    def configure(self, threshold, minutes):
        self.threshold,self.minutes=validate_alert_settings(threshold,minutes)

    def update(self, snapshot, now=None, enabled=True):
        if snapshot.get('status') != 'fresh' or not enabled:
            return []
        if 'observed_at' in snapshot and not 0<=time.time()-snapshot['observed_at']<=45:
            return []
        now=time.monotonic() if now is None else now
        events = [r for r in snapshot['rooms'] if r['current'] > self.threshold]
        if not events or (self.last_alert is not None and now-self.last_alert < self.minutes*60):
            return []
        # One shared cooldown: multiple rooms or fluctuating counts cannot
        # produce more than one alarm within the configured interval.
        self.last_alert=now
        return events
