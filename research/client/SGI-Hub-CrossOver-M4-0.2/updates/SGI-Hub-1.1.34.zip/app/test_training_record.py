import json
import tempfile
import unittest
from pathlib import Path

from training_record import (
    capture_pair, draft_pending, find_unit, infer_action_from_loss, list_units,
    load_session, save_pending, save_session, troops_of,
)


def state():
    return {
        'snapshot_id': 'snap-1',
        'player_force_id': 1,
        'player_identity': {'status': 'confirmed', 'force_id': 1},
        'entities': {
            'field_units': [
                {'unit_id': 10, 'owner_raw': 1, 'soldiers_candidate': 100, 'morale': 80,
                 'unit_kind': '骑', 'world_xy_raw': [1, 2]},
                {'unit_id': 20, 'owner_raw': 2, 'soldiers_candidate': 90, 'morale': 70,
                 'unit_kind': '步', 'world_xy_raw': [3, 4]},
                {'unit_id': 21, 'owner_raw': 2, 'soldiers_candidate': 40, 'morale': None,
                 'unit_kind': '弓', 'world_xy_raw': [5, 6]},
            ],
        },
    }


def pair(own_id=10, enemy_id=20, step=1, **overrides):
    shot = capture_pair(state(), own_id, enemy_id)
    shot['step'] = step
    shot.update(overrides)
    return shot


class TrainingRecordTests(unittest.TestCase):
    def test_never_infer_action_from_troop_loss(self):
        before = pair(step=1)
        after = pair(step=2, own_troops=80, enemy_troops=50)
        self.assertIsNone(infer_action_from_loss(before, after))
        self.assertIsNone(infer_action_from_loss({'own_troops': 100}, {'own_troops': 1}))

    def test_draft_stays_pending(self):
        row = draft_pending({'game_id': 'game-a'}, pair(step=1), pair(step=2, own_troops=90),
                            'attack', player_visible_both=True)
        self.assertEqual(row['label_status'], 'pending')
        self.assertFalse(row['action']['single_action_confirmed'])
        self.assertEqual(row['visibility'], 'player_visible')
        self.assertFalse(row['synthetic'])
        self.assertEqual(row['game_id'], 'game-a')
        self.assertEqual(row['action']['kind'], 'attack')

    def test_unseen_units_are_unverified(self):
        row = draft_pending({'game_id': 'game-a'}, pair(step=1), pair(step=2), 'defend')
        self.assertEqual(row['visibility'], 'unverified')

    def test_reject_reinforcement_and_mismatched_units(self):
        with self.assertRaisesRegex(ValueError, '增援'):
            draft_pending({'game_id': 'g'}, pair(step=1), pair(step=2, own_troops=120), 'attack')
        with self.assertRaisesRegex(ValueError, '同一对部队'):
            draft_pending({'game_id': 'g'}, pair(step=1), pair(10, 21, step=2), 'retreat')
        with self.assertRaisesRegex(ValueError, 'after.step'):
            draft_pending({'game_id': 'g'}, pair(step=2), pair(step=2), 'attack')
        with self.assertRaisesRegex(ValueError, 'game_id'):
            draft_pending({'game_id': '  '}, pair(step=1), pair(step=2), 'attack')

    def test_capture_requires_unique_opposite_units(self):
        self.assertEqual(troops_of(find_unit(state(), 10)), 100)
        self.assertEqual(len(list_units(state(), 2)), 2)
        with self.assertRaisesRegex(ValueError, '同一势力'):
            capture_pair(state(), 20, 21)
        with self.assertRaisesRegex(ValueError, '唯一对上'):
            capture_pair(state(), 99, 20)

    def test_save_pending_refuses_confirmed_and_keeps_game_id(self):
        with tempfile.TemporaryDirectory() as directory:
            save_session({'game_id': 'keep-me', 'step': 3}, directory)
            self.assertEqual(load_session(directory)['game_id'], 'keep-me')
            row = draft_pending({'game_id': 'keep-me'}, pair(step=1), pair(step=2, own_troops=90), 'attack')
            dest = save_pending(row, directory)
            written = json.loads(dest.read_text(encoding='utf-8').splitlines()[0])
            self.assertEqual(written['label_status'], 'pending')
            self.assertFalse(written['action']['single_action_confirmed'])
            assist = json.loads((Path(directory) / 'assist.jsonl').read_text(encoding='utf-8'))
            self.assertIn('not_training', assist['note'])
            row['label_status'] = 'confirmed'
            with self.assertRaisesRegex(ValueError, 'pending'):
                save_pending(row, directory)
            row['label_status'] = 'pending'
            row['action']['single_action_confirmed'] = True
            with self.assertRaisesRegex(ValueError, 'pending'):
                save_pending(row, directory)


if __name__ == '__main__':
    unittest.main()
