"""Values transcribed from the tutorial image040.gif; a is NOT assumed zero."""
TABLE={
 '步兵':([50,150,250],[50,150,250]),
 '强化步兵':([150,250,350],[150,250,350]),
 '重装步兵':([190,300,400],[190,300,400]),
 '骑兵':([100,250,450],[50,130,230]),
 '强化骑兵':([150,300,500],[80,160,260]),
 '重装骑兵':([200,350,550],[110,190,290]),
 '铁骑兵':([200,350,550],[110,190,290]),
 '弓兵':([80,140,200],[40,80,120]),
 '强弓兵':([120,180,240],[80,120,160]),
 '弩兵':([120,180,240],[80,120,160]),
 '重装弓兵':([220,300,400],[120,190,280]),
 '连弩':([220,300,400],[120,190,280]),
 '水军':([50,150,250],[50,150,250])}
BOW={'弓兵','强弓兵','弩兵','重装弓兵','连弩'}
def attack_reference(u):
 kind=u.get('unit_kind');s=u.get('size_index')
 if s not in (0,1,2):
  n=u.get('soldiers_candidate');s=(int(n>20000)+int(n>35000)) if type(n) is int and 0<=n<=100000 else None
 if kind not in TABLE or s is None:return ('未提供','未提供','—','—')
 unit,building=TABLE[kind];suffix='' if kind=='水军' else ' + a'
 return (str(unit[s])+suffix,str(building[s])+suffix,str([30,60,90][s]) if kind in BOW else '同前',str([20,60,100][s]) if kind in BOW else '同前')
NOTE='攻略基础表；弓系前两列为远射，后两列为肉搏。a为未完全核定的训练/规模加成，不是0；不等同完整攻击或扣血。红字修订行优先，连弩大队沿用“未改”值。'
