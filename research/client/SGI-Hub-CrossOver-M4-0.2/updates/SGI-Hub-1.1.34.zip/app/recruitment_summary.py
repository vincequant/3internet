"""Conditional annual summer recruitment from already capped city getters."""
KINDS=('infantry','cavalry','bow')
def annual_recruitment(state,force_id):
 all_cities=(state or {}).get('entities',{}).get('cities_and_barriers')
 if not isinstance(all_cities,list) or force_id is None:return {k:{'known':0,'missing':1,'cities':0} for k in KINDS}
 cities=[c for c in all_cities if c.get('type')=='city' and c.get('owner_raw')==force_id]
 out={}
 for kind in KINDS:
  values=[(c.get('recruitment_capacity') or {}).get('amounts',{}).get(kind) for c in cities]
  good=[v for v in values if type(v) is int and v>=0]
  out[kind]={'known':sum(good),'missing':len(values)-len(good),'cities':len(cities)}
 return out
def recruitment_text(result):
 if result['missing']:return f"{result['known']:,}＋未知" if result['known'] else '未采集完整'
 return f"≈{result['known']:,}"
