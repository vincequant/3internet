"""Hub tab: mark before/after for later human confirmation. No auto-labels."""
import tkinter as tk
from tkinter import ttk, messagebox
from player_view import player_id
from training_record import (
    KINDS, capture_pair, draft_pending, infer_action_from_loss, records_dir,
    load_session, save_pending, save_session, unit_id, unit_label,
)

BG = '#f7f4ea'
INK = '#2c281c'
MUTED = '#7a7464'
WARN = '#8a3030'


class TrainingRecordPanel(tk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent, bg=BG)
        self.app = app
        self.own = {}
        self.enemy = {}
        self.before = None
        session = load_session()
        self.game_id = tk.StringVar(value=session.get('game_id') or '')
        self.own_choice = tk.StringVar()
        self.enemy_choice = tk.StringVar()
        self.kind = tk.StringVar(value='attack')
        self.seen = tk.BooleanVar(value=False)
        tk.Label(self, text='训练采集 · 只写待确认', bg=BG, fg=INK,
                 font=(app.face, 14, 'bold')).pack(anchor='w', padx=10, pady=(10, 2))
        tk.Label(self, text='Hub 是全知视图。这里记下的兵数只是草稿，不能当攻击标签，也不能直接进训练集。\n'
                            '同一局存读档、崩溃恢复必须沿用同一个 game_id。兵力变少不等于发生了攻击。',
                 bg=BG, fg=WARN, justify='left').pack(anchor='w', padx=10)
        bar = tk.Frame(self, bg=BG)
        bar.pack(fill='x', padx=10, pady=8)
        tk.Label(bar, text='本局 game_id', bg=BG).pack(side='left')
        tk.Entry(bar, textvariable=self.game_id, width=28).pack(side='left', padx=6)
        tk.Button(bar, text='沿用/保存局号', command=self.keep_game, bg='#eee9d9').pack(side='left')
        tk.Button(bar, text='新开一局', command=self.new_game, bg='#eee9d9').pack(side='left', padx=6)
        pick = tk.Frame(self, bg=BG)
        pick.pack(fill='x', padx=10, pady=4)
        tk.Label(pick, text='己方部队', bg=BG).grid(row=0, column=0, sticky='w')
        self.own_box = ttk.Combobox(pick, textvariable=self.own_choice, state='readonly', width=52)
        self.own_box.grid(row=0, column=1, sticky='ew', padx=6)
        tk.Label(pick, text='对方部队（须你看得见）', bg=BG).grid(row=1, column=0, sticky='w')
        self.enemy_box = ttk.Combobox(pick, textvariable=self.enemy_choice, state='readonly', width=52)
        self.enemy_box.grid(row=1, column=1, sticky='ew', padx=6, pady=4)
        pick.columnconfigure(1, weight=1)
        acts = tk.Frame(self, bg=BG)
        acts.pack(fill='x', padx=10, pady=6)
        tk.Button(acts, text='1. 记下行动前', command=self.mark_before, bg='#eee9d9').pack(side='left')
        tk.Button(acts, text='2. 记下行动后', command=self.mark_after, bg='#eee9d9').pack(side='left', padx=8)
        ttk.Combobox(acts, textvariable=self.kind, values=list(KINDS), state='readonly', width=10).pack(side='left')
        tk.Checkbutton(acts, text='这两支部队决策时我都看得见', variable=self.seen, bg=BG).pack(side='left', padx=8)
        tk.Button(acts, text='3. 保存待确认', command=self.save_draft, bg='#eee9d9').pack(side='left')
        self.note = tk.Label(self, text='尚未记下行动前。待确认写入：' + str(records_dir() / 'pending.jsonl'),
                             bg=BG, fg=MUTED, justify='left', anchor='w', wraplength=900)
        self.note.pack(fill='x', padx=10, pady=8)
        self.after_shot = None

    def keep_game(self):
        session = load_session()
        session['game_id'] = self.game_id.get().strip()
        save_session(session)
        self.note.config(text='已保存局号。存读档请继续用这个 ID。')

    def new_game(self):
        from datetime import datetime, timezone
        gid = datetime.now(timezone.utc).strftime('game-%Y%m%d-%H%M')
        self.game_id.set(gid)
        save_session({'game_id': gid, 'step': 0})
        self.before = None
        self.after_shot = None
        self.note.config(text='已开新局 ' + gid)

    def refresh(self):
        state = self.app.doc
        player = player_id(state)
        units = ((state or {}).get('entities') or {}).get('field_units') or []
        if player is None:
            self.own, self.enemy = {}, {}
            self.own_box.configure(values=[])
            self.enemy_box.configure(values=[])
            self.own_choice.set('')
            self.enemy_choice.set('')
            if not self.before:
                self.note.config(text='先在 Hub 确认玩家势力。全知列表里的隐藏部队不能当训练特征。待确认：' +
                                 str(records_dir() / 'pending.jsonl'))
            return
        own = {unit_label(u): u for u in units if u.get('owner_raw') == player}
        enemy = {unit_label(u): u for u in units if u.get('owner_raw') != player}
        self.own, self.enemy = own, enemy
        self.own_box.configure(values=list(own))
        self.enemy_box.configure(values=list(enemy))
        if self.own_choice.get() not in own:
            self.own_choice.set(next(iter(own), ''))
        if self.enemy_choice.get() not in enemy:
            self.enemy_choice.set(next(iter(enemy), ''))

    def _pair(self):
        if infer_action_from_loss(None, None) is not None:
            raise RuntimeError('loss inference must stay disabled')
        return capture_pair(self.app.doc, unit_id(self.own.get(self.own_choice.get())),
                            unit_id(self.enemy.get(self.enemy_choice.get())))

    def mark_before(self):
        try:
            shot = self._pair()
            session = load_session()
            session['step'] = int(session.get('step') or 0) + 1
            shot['step'] = session['step']
            save_session(dict(session, game_id=self.game_id.get().strip() or session.get('game_id')))
            self.before = shot
            self.after_shot = None
            self.note.config(text=f"行动前已记 step={shot['step']} 己方{shot['own_troops']} 对方{shot['enemy_troops']}。去游戏里做那一下，再点行动后。")
        except Exception as error:
            messagebox.showerror('无法记下行动前', str(error))

    def mark_after(self):
        if not self.before:
            messagebox.showerror('还没有行动前', '先记下行动前，再做动作。')
            return
        try:
            shot = self._pair()
            shot['step'] = self.before['step'] + 1
            self.after_shot = shot
            self.note.config(text=f"行动后已记 己方{shot['own_troops']} 对方{shot['enemy_troops']}。核对动作种类后保存待确认。")
        except Exception as error:
            messagebox.showerror('无法记下行动后', str(error))

    def save_draft(self):
        if not self.before or not self.after_shot:
            messagebox.showerror('不完整', '必须先有行动前和行动后。')
            return
        try:
            session = load_session()
            session['game_id'] = self.game_id.get().strip()
            row = draft_pending(session, self.before, self.after_shot, self.kind.get(),
                                player_visible_both=self.seen.get())
            path = save_pending(row)
            self.note.config(text='已写入待确认（不是训练集）：' + str(path) + '  id=' + row['sample_id'])
            self.before = None
            self.after_shot = None
        except Exception as error:
            messagebox.showerror('未保存', str(error))
