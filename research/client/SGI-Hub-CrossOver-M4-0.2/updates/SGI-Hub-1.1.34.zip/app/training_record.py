"""Draft player-visible action notes. Never auto-confirms or infers attacks from diffs."""
import json
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path

SCHEMA = 1
KINDS = ('attack', 'retreat', 'defend')


def records_dir(home=None):
    home = Path(home or Path.home())
    if os.name == 'nt':
        base = Path(os.environ.get('APPDATA') or (home / 'AppData' / 'Roaming'))
        return base / 'SGI-Hub' / 'training-records'
    return home / 'Library' / 'Application Support' / 'SGI-Hub' / 'training-records'


def _int_or_none(value):
    if value is None:
        return None
    try:
        number = int(value)
    except (TypeError, ValueError):
        return None
    return number if number >= 0 else None


def _finite_or_none(value):
    if value is None:
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if number != number or number in (float('inf'), float('-inf')) or number < 0:
        return None
    return number


def unit_id(unit):
    if not unit:
        return None
    value = unit.get('unit_id')
    return None if value is None else str(value)


def troops_of(unit):
    if not unit:
        return None
    return _int_or_none(unit.get('soldiers_candidate', unit.get('soldiers')))


def morale_of(unit):
    if not unit:
        return None
    return _finite_or_none(unit.get('morale'))


def find_unit(state, uid):
    if uid is None:
        return None
    uid = str(uid)
    units = ((state or {}).get('entities') or {}).get('field_units') or []
    hits = [u for u in units if str(u.get('unit_id')) == uid]
    return hits[0] if len(hits) == 1 else None


def list_units(state, force_id):
    units = ((state or {}).get('entities') or {}).get('field_units') or []
    return [u for u in units if force_id is not None and u.get('owner_raw') == force_id]


def unit_label(unit):
    if not unit:
        return '?'
    name = unit.get('unit_kind') or unit.get('kind') or '部队'
    xy = unit.get('world_xy_raw') or []
    where = ','.join(map(str, xy)) if xy else '?'
    return f"ID{unit.get('unit_id')} {name} {where} 兵{troops_of(unit)}"


def capture_pair(state, own_id, enemy_id):
    own = find_unit(state, own_id)
    enemy = find_unit(state, enemy_id)
    if own is None or enemy is None:
        raise ValueError('必须各选一支仍能在当前快照里唯一对上的己方/对方部队')
    if own.get('owner_raw') == enemy.get('owner_raw'):
        raise ValueError('己方与对方不能是同一势力')
    return {
        'own_id': unit_id(own),
        'enemy_id': unit_id(enemy),
        'own_troops': troops_of(own),
        'enemy_troops': troops_of(enemy),
        'own_morale': morale_of(own),
        'enemy_morale': morale_of(enemy),
        'snapshot_id': (state or {}).get('snapshot_id'),
        'hub_only': True,
    }


def infer_action_from_loss(before, after):
    """Always None. Troop loss is not an attack label."""
    return None


def draft_pending(session, before, after, kind, *, player_visible_both=False):
    if kind not in KINDS:
        raise ValueError('动作只能是 attack / retreat / defend')
    if not session.get('game_id') or not str(session['game_id']).strip():
        raise ValueError('先填写本局 game_id；存读档必须沿用')
    if before.get('own_id') != after.get('own_id') or before.get('enemy_id') != after.get('enemy_id'):
        raise ValueError('行动前后必须是同一对部队')
    if (after.get('step') or 0) <= (before.get('step') or 0):
        raise ValueError('after.step 必须大于 before.step')
    for side in ('own_troops', 'enemy_troops'):
        a, b = before.get(side), after.get(side)
        if a is not None and b is not None and b > a:
            raise ValueError('兵数变多：可能换队或增援，不能当损失样本')
    now = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    return {
        'schema_version': SCHEMA,
        'sample_id': 'pending-' + uuid.uuid4().hex[:12],
        'game_id': str(session['game_id']).strip(),
        'scenario_id': session.get('scenario_id') or 'unspecified',
        'client_version': session.get('client_version') or 'SANPK-3.5',
        'ruleset_id': session.get('ruleset_id') or 'unspecified',
        'battle_id': session.get('battle_id') or ('b-' + now),
        'evidence_ref': after.get('evidence_ref') or ('hub-pending/' + now),
        'source': 'manual_observation',
        'visibility': 'player_visible' if player_visible_both else 'unverified',
        'label_status': 'pending',
        'synthetic': False,
        'action': {
            'kind': kind,
            'actor_id': before['own_id'],
            'single_action_confirmed': False,
        },
        'before': {
            'step': before['step'],
            'own_troops': before.get('own_troops'),
            'enemy_troops': before.get('enemy_troops'),
            'own_morale': before.get('own_morale'),
            'enemy_morale': before.get('enemy_morale'),
        },
        'after': {
            'step': after['step'],
            'own_troops': after.get('own_troops'),
            'enemy_troops': after.get('enemy_troops'),
            'own_morale': after.get('own_morale'),
            'enemy_morale': after.get('enemy_morale'),
        },
    }


def append_jsonl(path, row):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a', encoding='utf-8') as handle:
        handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + '\n')
    return path


def save_pending(row, directory=None):
    if row.get('label_status') != 'pending' or row.get('action', {}).get('single_action_confirmed') is True:
        raise ValueError('Hub 只能写 pending；禁止自动 confirmed')
    root = Path(directory or records_dir())
    dest = root / 'pending.jsonl'
    append_jsonl(dest, row)
    append_jsonl(root / 'assist.jsonl', {
        'sample_id': row['sample_id'],
        'game_id': row['game_id'],
        'note': 'hub_assist_not_training; do not export',
    })
    return dest


def load_session(directory=None):
    path = Path(directory or records_dir()) / 'current_game.json'
    if not path.exists():
        return {'game_id': '', 'step': 0}
    return json.loads(path.read_text(encoding='utf-8'))


def save_session(session, directory=None):
    path = Path(directory or records_dir()) / 'current_game.json'
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(session, ensure_ascii=False, indent=2), encoding='utf-8')
    return path
