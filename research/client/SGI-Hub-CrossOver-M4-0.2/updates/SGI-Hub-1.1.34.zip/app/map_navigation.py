"""Read-only camera movement shared by the two map widgets."""
def move_center(center, dx, dy, step=1, world=(101,202), offset=0):
    return tuple(max(offset,min(world[i]-1+offset,center[i]+d*step))
                 for i,d in enumerate((dx,dy)))

def navigation_bar(parent, move, reset):
    from tkinter import ttk
    bar=ttk.Frame(parent)
    for label,dx,dy in [('↑',0,-1),('↓',0,1),('←',-1,0),('→',1,0)]:
        ttk.Button(bar,text=label,width=3,command=lambda x=dx,y=dy:move(x,y)).pack(side='left')
    ttk.Button(bar,text='回到定位',command=reset).pack(side='left',padx=4)
    return bar

def bind_arrows(canvas, move):
    for key,dx,dy in [('Up',0,-1),('Down',0,1),('Left',-1,0),('Right',1,0)]:
        def handler(event,x=dx,y=dy):move(x,y);return 'break'
        canvas.bind('<'+key+'>',handler)
    canvas.bind('<Button-1>',lambda event:canvas.focus_set(),add='+')
