"""Single-officer sortie preview from current troop size. Not engine damage."""
from preparation_model import combat_power, size_index, span, training_bases
from unit_target_attack import rnd, supported_combat_build

KINDS = ('infantry', 'cavalry', 'bow')
KIND_LABEL = {'infantry': '步', 'cavalry': '骑', 'bow': '弓'}
SIZES = ('小队', '中队', '大队')
ROLE_ORDER = {'攻击优先': 0, '技能互补': 1, '省将方案': 2}


def taken_soldiers(officer, force, kind):
    soldiers = (officer or {}).get('soldiers')
    if type(soldiers) is not int or soldiers <= 0:
        return None
    stock = ((force or {}).get('troop_stock') or {}).get(kind)
    if type(stock) is int:
        taken = min(soldiers, stock)
        if taken <= 0:
            return None
        return taken, soldiers, stock, stock < soldiers
    return soldiers, soldiers, None, False


def kind_preview(officer, force, kind):
    taken = taken_soldiers(officer, force, kind)
    if not taken:
        return None
    soldiers, capacity, stock, capped = taken
    power = combat_power([officer])
    bases = training_bases(kind, ((force or {}).get('armament_raw') or {}).get(kind))
    size = size_index(soldiers)
    if not bases or power is None or not 0 <= power <= 150:
        return None
    factor = bases['unit'][size]
    if factor is None:
        return None
    return {
        'kind': kind, 'name': bases['name'], 'training': bases['training'],
        'soldiers': soldiers, 'capacity': capacity, 'stock': stock,
        'size': size, 'size_label': SIZES[size], 'power': power,
        'factor': factor, 'attack': rnd(factor * power / 150), 'capped': capped,
    }


def officer_previews(officer, force, state=None):
    if state is not None and not supported_combat_build(state.get('build_sha256')):
        return {kind: None for kind in KINDS}
    return {kind: kind_preview(officer, force, kind) for kind in KINDS}


def format_preview(preview):
    if not preview:
        return '—'
    text = f"≈{preview['attack']} · 系数{preview['factor']} · {preview['size_label']}/{preview['name']}"
    if preview.get('capped'):
        text += '（库存限）'
    return text


def officer_cells(officer, force, state=None):
    previews = officer_previews(officer, force, state)
    return {kind: format_preview(previews[kind]) for kind in KINDS}


def recommendation_index(result):
    buckets = {}
    for row in (result or {}).get('rows') or []:
        generals = row.get('generals') or []
        attack = row.get('attack')
        if not generals or not attack:
            continue
        names = [g.get('name') or '?' for g in generals]
        label = row.get('label') or '推荐'
        troop = row.get('troop') or '?'
        shown = span(attack)
        for index, general in enumerate(generals):
            gid = general.get('general_id_raw')
            role = '主将' if index == 0 else '副将'
            others = [name for i, name in enumerate(names) if i != index]
            extra = (' +' + '/'.join(others)) if others else ' 单出'
            text = f"{role}·{label} {troop} 部队攻击 {shown}{extra}"
            buckets.setdefault(gid, []).append((ROLE_ORDER.get(label, 9), index, text))
    return {gid: '；'.join(item[2] for item in sorted(items)) for gid, items in buckets.items()}
