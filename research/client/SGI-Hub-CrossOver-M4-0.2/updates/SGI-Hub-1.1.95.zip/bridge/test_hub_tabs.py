from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class HubTabs(unittest.TestCase):
    def test_force_and_officer_tabs_live_on_workspace(self):
        text = (ROOT / 'app' / 'omni_window.py').read_text(encoding='utf-8')
        self.assertIn('def _arrange_workspace_tabs', text)
        self.assertIn('self.book=self.workspace', text)
        self.assertIn('self.global_book=self.workspace', text)
        self.assertNotIn('ttk.Notebook(right)', text)
        self.assertNotIn("workspace.add(self.global_page,text='武将资料')", text)
        self.assertIn("self.frames['officers']", text)
        self.assertIn("self.preparation", text)
        self.assertIn("点右侧标签直接切换", text)
        self.assertIn("前10五维均", text)
        self.assertIn("atk_inf", text)
