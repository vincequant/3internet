import os,sys,tkinter as tk
from pathlib import Path
from omni_window import OmniWindow
from bridge_autostart import ensure_bridge
from connection import CONNECTION,local_config
local_source=local_config()
if local_source:
 os.environ['SGI_SOURCE_ID']=local_source.get('expected_source',local_source['label'])
 if sys.platform=='win32':
  os.environ.setdefault('SGI_GAME_EXE',local_source.get('game_path',r'D:\Coding\sanguo-internet\run-3.5\3I\SANPK.exe'))
  from service_startup import ensure_service
  ensure_service('http://127.0.0.1:8769/health','sgi-crossover-bridge-1',
                 [sys.executable,'-B',str(Path(__file__).resolve().parent.parent/'bridge/windows_bridge.py')],
                 Path(__file__).resolve().parent.parent,
                 Path(__file__).resolve().parent.parent/'logs/native-bridge.log')
 else:
  bridge_start=ensure_bridge(Path(__file__).resolve().parent.parent)
  print('采集桥：'+bridge_start['mode'],flush=True)
root=tk.Tk()
from mac_light_theme import apply_light_defaults
apply_light_defaults(root)
from display_layout import configure as configure_display,save as save_display,CHOICES
display_choice=configure_display(root)
app=OmniWindow(root)
from connection import source_options, select_source
sources=source_options()
if sources:
 from tkinter import ttk, messagebox
 bar=ttk.Frame(root)
 bar.pack(side='top',fill='x',before=root.winfo_children()[0],padx=12,pady=5)
 ttk.Label(bar,text='游戏数据源：').pack(side='left')
 choice=ttk.Combobox(bar,values=list(sources),state='readonly',width=30)
 choice.set(CONNECTION.cfg.get('selected_source',''))
 choice.pack(side='left',padx=8)
 def switch_source(event=None):
  if choice.get()==CONNECTION.cfg.get('selected_source'):return
  try:select_source(choice.get())
  except Exception as error:
   messagebox.showerror('切换失败',str(error));return
  # A new interpreter discards all old snapshots, child windows and reader
  # threads. Close only this viewer's SSH tunnel; never touch a collector.
  app.stop.set();CONNECTION.close();root.destroy()
  os.execv(sys.executable,[sys.executable,'-B',str(Path(__file__).resolve())])
 choice.bind('<<ComboboxSelected>>',switch_source)
from tkinter import ttk,messagebox
density_bar=bar if sources else ttk.Frame(root)
if not sources:density_bar.pack(side='top',fill='x',before=root.winfo_children()[0],padx=12,pady=2)
ttk.Label(density_bar,text='界面缩放：').pack(side='left')
density=ttk.Combobox(density_bar,values=CHOICES,state='readonly',width=7)
density.set(display_choice);density.pack(side='left')
def switch_density(event=None):
 if density.get()==display_choice:return
 try:save_display(density.get())
 except Exception as error:messagebox.showerror('缩放设置失败',str(error));return
 app.stop.set();CONNECTION.close();root.destroy()
 os.execv(sys.executable,[sys.executable,'-B',str(Path(__file__).resolve())])
density.bind('<<ComboboxSelected>>',switch_density)
version=__import__('json').loads((Path(__file__).resolve().parent.parent/'RELEASE.json').read_text(encoding='utf8'))['version']
root.title('三国志全知情报 '+version+' · '+('远端 · ' if CONNECTION.remote else '')+CONNECTION.cfg['label'])
app.status.config(text='正在连接 '+CONNECTION.cfg['label'])
def close():
 app.stop.set();CONNECTION.close();root.destroy()
root.protocol('WM_DELETE_WINDOW',close)
from graceful_shutdown import install as install_shutdown
install_shutdown(root,close)
from verify_gui import install
install(root,app)
try:
 root.mainloop()
finally:
 CONNECTION.close()
