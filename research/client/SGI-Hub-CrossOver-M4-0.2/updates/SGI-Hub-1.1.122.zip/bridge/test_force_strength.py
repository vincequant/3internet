import sys
import unittest
from pathlib import Path

sys.path[:0] = [str(Path(__file__).resolve().parent.parent / 'app')]
from force_strength import five_stat_total, format_average, top_five_stat_average


def officer(*stats):
    lead, war, intel, pol, cha = stats
    return {'attributes': dict(lead=lead, war=war, intel=intel, pol=pol, cha=cha)}


class ForceStrength(unittest.TestCase):
    def test_total_and_top10_average(self):
        self.assertEqual(five_stat_total(officer(90, 80, 70, 60, 50)), 350)
        self.assertIsNone(five_stat_total({'attributes': {'lead': 90}}))
        highs = [officer(100, 100, 100, 100, 100 - i) for i in range(10)]
        lows = [officer(10, 10, 10, 10, i) for i in range(8)]
        self.assertEqual(top_five_stat_average(lows + highs), 495.5)
        self.assertEqual(format_average(495.5), '495.5')
        self.assertEqual(format_average(400.0), '400')
        self.assertEqual(format_average(None), '—')

    def test_fewer_than_ten_uses_available(self):
        officers = [officer(80, 80, 80, 80, 80), officer(70, 70, 70, 70, 70)]
        self.assertEqual(top_five_stat_average(officers), 375)
        self.assertIsNone(top_five_stat_average([]))
        self.assertIsNone(top_five_stat_average([{'attributes': {}}]))
