import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'app'))

from city_roads import load_road_edges, path_for_layer, rdp, stride
from unit_memory import memory_line
from panorama_map import apply_view, parse_view, tk_pixels
from wine_nav import panorama_command
from panorama_model import (
    SWITCH_ZOOM, capital_marks, catalog_cities, clamp_zoom,
    is_capital, layer_for_zoom, live_objects, mbm_view, nearest_city, object_key,
    opponent_brief, show_overlay, supply_lines, units_in_view, view_unit_line,
    world_xy,
)


class PanoramaResearchTests(unittest.TestCase):
    def test_zoom_switches_from_lbm_to_mbm(self):
        self.assertEqual(layer_for_zoom(1), 'lbm')
        self.assertEqual(layer_for_zoom(SWITCH_ZOOM - 0.1), 'lbm')
        self.assertEqual(layer_for_zoom(SWITCH_ZOOM), 'mbm')
        self.assertEqual(layer_for_zoom(6), 'mbm')

    def test_zoom_stays_in_range(self):
        self.assertEqual(clamp_zoom(0), 1.0)
        self.assertEqual(clamp_zoom(99), 12.0)

    def test_mbm_box_follows_jiangling(self):
        box, scale = mbm_view((52.5, 124.5), 6, 800, 480)
        self.assertGreater(scale, 0)
        self.assertLess(box[0], box[2])
        self.assertLess(box[1], box[3])
        self.assertLess(box[2] - box[0], 4000)

    def test_historical_cities_include_jiangling(self):
        cities = catalog_cities()
        match = [row for row in cities if row['name'] == '江陵']
        self.assertEqual(len(match), 1)
        self.assertEqual(match[0]['world_xy'], (52, 124))
        self.assertEqual(nearest_city((52.4, 124.2), cities)['name'], '江陵')

    def test_wine_nav_and_hub_tab(self):
        hub = (ROOT / 'app/omni_window.py').read_text(encoding='utf-8')
        nav = (ROOT / 'app/wine_nav.py').read_text(encoding='utf-8')
        swift = ROOT.parents[2] / 'scripts/wine-launcher/main.swift'
        self.assertIn("text='全景地图'", hub)
        self.assertIn('PanoramaMap', hub)
        self.assertIn("text='全景地图'", nav)
        self.assertIn('房间观察', nav)
        if swift.is_file():
            self.assertIn('全景地图', swift.read_text(encoding='utf-8'))
        self.assertIn('panorama_map.py', nav)
        cmd = panorama_command((74.5, 63.5), 6)
        self.assertEqual(cmd[-4:], ['--center', '74.5,63.5', '--zoom', '6.0'])
        center, zoom = parse_view(['--center', '74.5,63.5', '--zoom', '6'])
        self.assertEqual(center, (74.5, 63.5))
        self.assertEqual(zoom, 6.0)
        page = type('P', (), {'center': (1, 1), 'zoom': 1.0})()
        apply_view(page, (74.5, 63.5), 6)
        self.assertEqual(page.center, (74.5, 63.5))
        self.assertEqual(page.zoom, 6.0)
        locator = (ROOT / 'app/native_city_map.py').read_text(encoding='utf-8')
        self.assertIn('打开全景视窗', locator)
        self.assertIn('self.zoom=6.', locator)
        self.assertIn('bind_pointer_wheel', locator)
        self.assertIn('bind_pointer_wheel', (ROOT / 'app/panorama_map.py').read_text(encoding='utf-8'))
        self.assertIn('bind_all', (ROOT / 'app/map_navigation.py').read_text(encoding='utf-8'))
        self.assertNotIn('unbind_all', (ROOT / 'app/map_navigation.py').read_text(encoding='utf-8'))
        self.assertIn("<' + key + '>'", (ROOT / 'app/map_navigation.py').read_text(encoding='utf-8'))
        self.assertIn('vision_cells', (ROOT / 'app/native_city_map.py').read_text(encoding='utf-8'))
        self.assertIn('滚轮缩放', (ROOT / 'app/panorama_map.py').read_text(encoding='utf-8'))
        self.assertIn('本视野部队', (ROOT / 'app/panorama_map.py').read_text(encoding='utf-8'))
        self.assertIn('units_in_view', (ROOT / 'app/panorama_map.py').read_text(encoding='utf-8'))

    def test_live_overlays_and_opponent_filter(self):
        relations = [0] * 22
        relations[2] = 1
        state = {
            'player_force_id': 1,
            'player_identity': {'status': 'confirmed', 'force_id': 1},
            'entities': {
                'lords': [
                    {'force_id': 1, 'name': '我军', 'diplomacy_relations': relations},
                    {'force_id': 2, 'name': '敌军'},
                ],
                'cities_and_barriers': [
                    {'city_id': 31, 'name': '江陵', 'type': 'city', 'owner_raw': 2, 'world_xy_raw': [52, 124]},
                ],
                'production_buildings': [
                    {'object_id_candidate': 8, 'type': 'parade_ground', 'owner_raw': 2, 'world_xy_raw': [53, 124]},
                ],
                'traps': [
                    {'trap_id': 4, 'type': 'trap', 'trap_kind': '落石', 'owner_raw': 2, 'world_xy_raw': [54, 124]},
                ],
                'field_units': [
                    {'unit_id': 9, 'unit_kind': '骑兵', 'owner_raw': 2, 'world_xy_raw': [52, 125]},
                    {'unit_id': 10, 'unit_kind': '步兵', 'owner_raw': 3, 'world_xy_raw': [10, 10]},
                ],
            },
        }
        kinds = [kind for kind, _ in live_objects(state)]
        self.assertEqual(kinds, ['城关', '建筑', '陷阱', '部队', '部队'])
        self.assertEqual(world_xy(state['entities']['cities_and_barriers'][0]), (52, 124))
        self.assertTrue(show_overlay(state, '部队', state['entities']['field_units'][0], True))
        self.assertFalse(show_overlay(state, '部队', state['entities']['field_units'][1], True))
        self.assertIn('敌军', opponent_brief(state))
        self.assertIn('部队 1', opponent_brief(state))
        self.assertEqual(object_key('城关', state['entities']['cities_and_barriers'][0]), ('城关', 'city', 31))
        near = units_in_view(state, (51, 123, 55, 127))
        self.assertEqual([row['unit_id'] for row in near], [9])
        far = units_in_view(state, (0, 0, 15, 15))
        self.assertEqual([row['unit_id'] for row in far], [10])
        self.assertEqual([row['unit_id'] for row in units_in_view(state, (0, 0, 100, 200), True)], [9])
        self.assertIn('敌军', view_unit_line(state, state['entities']['field_units'][0]))
        self.assertIn('骑兵', view_unit_line(state, state['entities']['field_units'][0]))

    def test_supply_lines_and_capitals(self):
        cities = [
            {'city_id': 1, 'name': '甲', 'type': 'city', 'owner_raw': 4, 'world_xy_raw': [10, 10]},
            {'city_id': 2, 'name': '乙', 'type': 'city', 'owner_raw': 4, 'world_xy_raw': [20, 10]},
            {'city_id': 3, 'name': '丙', 'type': 'city', 'owner_raw': 5, 'world_xy_raw': [20, 20]},
            {'city_id': 4, 'name': '丁', 'type': 'city', 'owner_raw': 5, 'world_xy_raw': [10, 20]},
        ]
        state = {
            'entities': {
                'lords': [
                    {'force_id': 4, 'name': '楚', 'capital_city_id': 1},
                    {'force_id': 5, 'name': '吴', 'capital_city_id': 3},
                    {'force_id': 6, 'name': '空', 'capital_city_id': 99},
                ],
                'cities_and_barriers': cities,
            }
        }
        edges = [
            {'a': 1, 'b': 2, 'path': [[0, 0], [10, 4], [20, 0]]},
            {'a': 2, 'b': 3, 'path': [[20, 0], [20, 20]]},
            {'a': 3, 'b': 4, 'path': [[20, 20], [10, 20]]},
            {'a': 1, 'b': 4, 'path': [[0, 0], [10, 20]]},
        ]
        lines = supply_lines(state, edges)
        same = {(line['a_id'], line['b_id'], line['owner_raw']) for line in lines if line['same_owner']}
        split = {(line['a_id'], line['b_id']) for line in lines if not line['same_owner']}
        self.assertEqual(same, {(1, 2, 4), (3, 4, 5)})
        self.assertEqual(split, {(2, 3), (1, 4)})
        self.assertGreater(len(lines[0]['path']), 2)
        self.assertEqual(rdp([(0, 0), (5, 0), (10, 0)], 1), [(0, 0), (10, 0)])
        self.assertEqual(len(rdp([(0, 0), (5, 8), (10, 0)], 1)), 3)
        self.assertEqual(stride([(0, 0), (1, 1), (2, 2), (3, 3)], 2), [(0, 0), (2, 2), (3, 3)])
        gentle = [(0, 0), (20, 4), (40, 6), (80, 4), (120, 0)]
        self.assertEqual(path_for_layer(gentle, 'lbm'), [(0, 0), (120, 0)])
        self.assertEqual(path_for_layer(gentle, 'mbm'), gentle)
        corner = [(0, 0), (200, 0), (200, 200)]
        self.assertEqual(path_for_layer(corner, 'lbm'), [(0, 0), (200, 0), (200, 200)])
        marks = capital_marks(state)
        self.assertEqual([(m['force_name'], m['city_name'], m['world_xy']) for m in marks], [
            ('楚', '甲', (10, 10)),
            ('吴', '丙', (20, 20)),
        ])
        self.assertTrue(is_capital(state, cities[0]))
        self.assertFalse(is_capital(state, cities[1]))
        nav = (ROOT / 'app/wine_nav.py').read_text(encoding='utf-8')
        self.assertIn('沿路补给线', nav)
        self.assertIn('首都位置', nav)
        baked = [edge for edge in load_road_edges() if {edge.get('a_name'), edge.get('b_name')} & {'汉昌', '江陵'}]
        self.assertTrue(baked)
        self.assertTrue(all(len(edge['path']) > 4 for edge in baked))
        anding = next(edge for edge in load_road_edges() if {edge.get('a_name'), edge.get('b_name')} == {'安定', '北地'})
        ys = [point[1] for point in anding['path']]
        self.assertGreater(len(anding['path']), 20)
        self.assertGreater(max(ys) - min(ys), 40)

    def test_unit_memory_line_includes_rice(self):
        text = memory_line({
            'soldiers_candidate': 2969,
            'rice_candidate': 2969,
            'morale': 100,
            'basic_combat_power': 69,
            'target_attack_unit': 90,
        })
        self.assertIn('粮食 2,969（约6天）', text)
        self.assertIn('战力 69', text)
        self.assertIn('士气 100', text)
        self.assertNotIn('训练', text)
        nav = (ROOT / 'app/omni_window.py').read_text(encoding='utf-8')
        self.assertIn("('rice','粮食 / 约可吃',130)", nav)
        self.assertIn("('attack','部队攻击系数*',130)", nav)
        self.assertNotIn("('training','本级武装值',95)", nav)
        locator = (ROOT / 'app/native_city_map.py').read_text(encoding='utf-8')
        self.assertIn('layer_for_zoom', locator)
        self.assertIn('supply_lines', locator)
        self.assertIn('mbm_view', locator)

    def test_tk9_canvas_width_with_centimeter_unit(self):
        class Fake:
            def winfo_fpixels(self, value):
                text = str(value)
                if text.endswith('c'):
                    return float(text[:-1]) * 37.8
                return float(text)
        self.assertEqual(tk_pixels(Fake(), '10c'), 378)
        self.assertEqual(tk_pixels(Fake(), '800'), 800)
        self.assertEqual(tk_pixels(Fake(), ''), 0)
        self.assertNotIn("int(c.cget('width')", (ROOT / 'app/panorama_map.py').read_text(encoding='utf-8'))


if __name__ == '__main__':
    unittest.main()
