"""Launch the read-only bridge in the game's selected Wine environment."""
from pathlib import Path
import os,json
from service_startup import ensure_service,probe
URL='http://127.0.0.1:8769/health'
SERVICE='sgi-crossover-bridge-1'

def configure_local_runtime(root):
 config=Path(os.environ.get('SGI_CONNECTION_CONFIG',Path(root)/'connection.local.json'))
 if not config.is_file():return
 from connection import local_config
 runtime=(local_config() or {}).get('wine_runtime') or json.loads(config.read_text(encoding='utf8')).get('wine_runtime')
 if not runtime:return
 for key,field in [('SGI_WINE_BINARY','wine'),('WINEPREFIX','prefix'),('SGI_RUNTIME_ID','runtime_id'),('DYLD_FALLBACK_LIBRARY_PATH','dependency_lib')]:
  if runtime.get(field):os.environ.setdefault(key,runtime[field])
 os.environ.setdefault('WINEDEBUG','-all,err+all')
 os.environ.setdefault('LANG','zh_CN.UTF-8')
 os.environ.setdefault('LC_ALL','zh_CN.UTF-8')
 os.environ.setdefault('WINEDLLOVERRIDES','winegstreamer=d')
def bridge_command(root):
 root=Path(root)
 python=root/'bridge/python/python.exe'
 if not python.is_file():raise RuntimeError('缺少环境内 Python：'+str(python))
 code='import pathlib,runpy,sys; runpy.run_path(str(pathlib.Path(sys.executable).resolve().parent.parent / "windows_bridge.py"),run_name="__main__")'
 standalone=os.environ.get('SGI_WINE_BINARY')
 if standalone:
  wine=Path(standalone).expanduser()
  prefix=Path(os.environ.get('WINEPREFIX','')).expanduser()
  if not wine.is_file() or not os.access(wine,os.X_OK):raise RuntimeError('找不到 Wine 运行程序：'+str(wine))
  if not prefix.is_absolute() or not (prefix/'system.reg').is_file():raise RuntimeError('独立 Wine 环境尚未初始化')
  return [str(wine),str(python),'-X','utf8','-B','-c',code],'wine-bridge-auto.log'
 bottle=os.environ.get('SGI_BOTTLE','SanguoInternet')
 wine=Path(os.environ.get('SGI_CX_WINE','/Applications/CrossOver.app/Contents/SharedSupport/CrossOver/bin/wine'))
 bottle_path=Path.home()/'Library/Application Support/CrossOver/Bottles'/bottle
 if not wine.is_file() or not os.access(wine,os.X_OK):raise RuntimeError('找不到CrossOver运行程序：'+str(wine))
 if not bottle_path.is_dir():raise RuntimeError('找不到游戏容器：'+str(bottle_path))
 return [str(wine),'--bottle',bottle,str(python),'-X','utf8','-B','-c',code],'crossover-bridge-auto.log'

def ensure_bridge(root):
 root=Path(root)
 configure_local_runtime(root)
 health=probe(URL,SERVICE)
 if health is not None:
  if os.environ.get('SGI_WINE_BINARY') and health.get('runtime_id')!=os.environ.get('SGI_RUNTIME_ID','wine-standalone'):
   raise RuntimeError('已有采集服务属于另一运行环境，请先关闭旧采集服务再切换 Wine')
  return {'mode':'reused','health':health}
 command,log=bridge_command(root)
 return ensure_service(URL,SERVICE,command,root,root/'logs'/log)
if __name__=='__main__':
 import json
 print(json.dumps(ensure_bridge(Path(__file__).resolve().parent.parent),ensure_ascii=False))
