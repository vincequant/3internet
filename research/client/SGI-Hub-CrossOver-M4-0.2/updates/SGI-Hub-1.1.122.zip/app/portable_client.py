import json,urllib.request
from connection import CONNECTION
URL=CONNECTION.base_url+'/api/state'

def snapshot_age_text(age):
 if age is None:return '无快照'
 try:return f'{int(age)}秒'
 except (TypeError,ValueError):return '无快照'

def _status_text(payload,doc=None):
 p=payload or {}
 doc=doc if doc is not None else p.get('state')
 age=p.get('snapshot_age_s')
 if age is None and doc and doc.get('capture_end'):
  from datetime import datetime,timezone
  try:age=(datetime.now(timezone.utc)-datetime.fromisoformat(doc['capture_end'])).total_seconds()
  except (TypeError,ValueError):age=None
 age_txt=snapshot_age_text(age)
 phase=p.get('phase') or ''
 err=p.get('error')
 if p.get('fresh') and not p.get('error') and doc:
  ms=(doc.get('timing') or {}).get('capture_ms')
  snap=doc.get('snapshot_id') or ''
  if isinstance(ms,(int,float)):return f'采集实时 · {ms:.1f} ms · {snap}','#d2edb9'
  return f'采集实时 · {snap}','#d2edb9'
 if phase=='waiting_for_player':
  return '等待游戏进入对局并选定玩家','#ffd08a'
 if phase=='waiting_for_game':
  return ('等待游戏 · 旧快照 '+age_txt)+(f' · {err}' if err else ''),'#ffc0a0'
 if phase=='map_not_ready':
  return ('等待地图就绪 · 旧快照 '+age_txt)+(f' · {err}' if err else ''),'#ffd08a'
 if phase=='recovering':
  return ('恢复中 · 旧快照 '+age_txt)+(f' · {err}' if err else ''),'#ffd08a'
 return ('采集断开 · 旧快照 '+age_txt)+(f' · {err}' if err else ''),'#ffc0a0'

def poll(app):
 while not app.stop.is_set():
  try:
   CONNECTION.ensure()
   with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(URL,timeout=6) as response:p=json.load(response)
   CONNECTION.validate(p)
   if p.get('service')!='sgi-crossover-bridge-1':raise ValueError('不是本测试包的采集桥')
   if p.get('fresh') is not True:p['fresh']=False
  except Exception as error:p={'fresh':False,'error':str(error),'state':None,'phase':'error'}
  p['source_label']=CONNECTION.cfg['label']
  p['remote']=CONNECTION.remote
  try:app.inbox.put_nowait(p)
  except Exception:pass
  app.stop.wait(1)


def confirm_player(doc,force_id):
 if CONNECTION.remote:raise ValueError('远端只读查看；我方身份由游戏所在电脑自动识别')
 payload={'session_id':(doc.get('player_identity') or {}).get('session_id'),'force_id':force_id}
 request=urllib.request.Request(CONNECTION.base_url+'/api/player',data=json.dumps(payload).encode('utf8'),headers={'Content-Type':'application/json'},method='POST')
 try:
  with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(request,timeout=3) as response:return json.load(response)
 except urllib.error.HTTPError as error:
  raise ValueError(json.loads(error.read()).get('error','确认失败')) from error


def invalidate_player(doc):
 out=dict(doc);out['player_force_id']=None
 out['player_identity']=dict(doc.get('player_identity') or {},force_id=None,status='unknown',source='unknown')
 out['current_local_projection']=dict(doc.get('current_local_projection') or {},player_force_id=None)
 out.pop('history',None);out['core_projection_divergence']={}
 return out


def status_text(payload,doc=None):
 text,color=_status_text(payload,doc)
 p=payload or {}
 label=p.get('source_label',CONNECTION.cfg['label'])
 return ('远端 · ' if p.get('remote',CONNECTION.remote) else '本机 · ')+label+' · '+text,color
