"""Read the original SGI terrain tile stream, without modifying game assets."""
from pathlib import Path
from functools import lru_cache
import os
from PIL import Image

def world_pixel(x,y):
    return 48+96*x+48*(y%2),24+24*y

class Terrain:
    def __init__(self,path=None):
        candidates=[Path(path)] if path else []
        if os.environ.get('SGI_TERRAIN_FILE'):candidates.append(Path(os.environ['SGI_TERRAIN_FILE']))
        candidates += [Path(__file__).parent/'assets'/'SanInet.mbm',Path('D:/Coding/sanguo-internet/run-3.5/3I/SanInet.mbm'),Path.home()/'Library/Application Support/CrossOver/Bottles/SanguoInternet/drive_c/sgi/run-3.5/3I/SanInet.mbm']
        self.path=next((p for p in candidates if p.is_file()),None)
        if self.path is None:raise FileNotFoundError('未找到 SanInet.mbm')
        raw=self.path.read_bytes()
        with Image.open(self.path) as im:
            if im.size!=(9744,4872) or im.mode!='P':raise ValueError('地图规格不匹配，不能使用本坐标配准')
            self.palette=im.getpalette()
        offset=int.from_bytes(raw[10:14],'little');self.data=raw[offset:]
        if len(self.data)<203*203*1152:raise ValueError('地图像素不完整')
    @lru_cache(maxsize=512)
    def tile(self,x,y):
        offset=(y*203+x)*1152
        tile=Image.frombytes('P',(48,24),self.data[offset:offset+1152]).transpose(Image.Transpose.FLIP_TOP_BOTTOM)
        tile.putpalette(self.palette)
        return tile.convert('RGB')
    def crop(self,box):
        left,top,right,bottom=map(int,box)
        out=Image.new('RGB',(right-left,bottom-top),'#68724e')
        for y in range(max(0,top//24),min(203,(bottom+23)//24)):
            for x in range(max(0,left//48),min(203,(right+47)//48)):
                out.paste(self.tile(x,y),(x*48-left,y*24-top))
        return out
