"""Shared live map annotations; unknown morale stays unknown."""
def unit_label(state,u):
 ids=u.get('general_ids',[]);gid=ids[0] if ids else None
 gs=[g for g in state.get('entities',{}).get('generals',[]) if gid is not None and g.get('general_id_raw')==gid]
 general=gs[0].get('name','未知') if len(gs)==1 else '未知'
 attack=u.get('target_attack_unit')
 if attack is None or attack=='':attack='未知'
 label=f"{general}(攻:{attack}) - {u.get('unit_kind','部队')}"
 morale=u.get('morale')
 if type(morale) in (int,float):
  import math
  if math.isfinite(morale):label+=f" · 士气:{morale:g}"
 return label

def label_box(canvas,x,y,text,color,anchor='n',tags='unit_label'):
 tid=canvas.create_text(x,y,text=text,anchor=anchor,fill='#25271e',font=('Microsoft YaHei',9),tags=tags)
 b=canvas.bbox(tid)
 if b:
  rid=canvas.create_rectangle(b[0]-4,b[1]-2,b[2]+4,b[3]+2,fill='#fff9e7',outline=color,width=2,tags=tags);canvas.tag_lower(rid,tid)
 return tid
