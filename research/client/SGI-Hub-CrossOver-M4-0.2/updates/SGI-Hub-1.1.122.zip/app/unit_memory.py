"""Already-decoded field-unit memory fields for display. No new reads."""

# Guide: each turn eats soldiers/6 rice; a full ration lasts 6 turns, starve from the 7th.
RATION_TURNS = 6


def fmt_mem(value):
    if value is None:
        return '未知'
    if type(value) is int:
        return f'{value:,}'
    return str(value)


def rice_days(soldiers, rice):
    if type(soldiers) is not int or type(rice) is not int:
        return None
    if soldiers <= 0:
        return None
    if rice <= 0:
        return 0.0
    return RATION_TURNS * rice / soldiers


def format_days(days):
    if days is None:
        return None
    if days == 0:
        return '0'
    if abs(days - round(days)) < 1e-9:
        return str(int(round(days)))
    return f'{days:.1f}'


def rice_label(row):
    rice = fmt_mem(row.get('rice_candidate'))
    days = format_days(rice_days(row.get('soldiers_candidate'), row.get('rice_candidate')))
    if days is None:
        return f'{rice} · 天数未知'
    return f'{rice}（约{days}天）'


def attack_label(row):
    value = row.get('target_attack_unit')
    if value in (None, '', '缺参数'):
        return '研究中'
    return str(value)


def memory_line(row):
    return (
        f"兵数 {fmt_mem(row.get('soldiers_candidate'))}"
        f" · 粮食 {rice_label(row)}"
        f" · 战力 {fmt_mem(row.get('basic_combat_power'))}"
        f" · 士气 {fmt_mem(row.get('morale'))}"
        f" · 攻击系数 {attack_label(row)}"
    )
