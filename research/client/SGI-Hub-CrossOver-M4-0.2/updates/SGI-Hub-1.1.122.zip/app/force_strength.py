"""Observed five-stat totals for force ranking. Not combat power or win chance."""
KEYS = ('lead', 'war', 'intel', 'pol', 'cha')


def five_stat_total(officer):
    attrs = (officer or {}).get('attributes') or {}
    values = [attrs.get(key) for key in KEYS]
    if any(type(value) not in (int, float) for value in values):
        return None
    return sum(values)


def top_five_stat_average(officers, limit=10):
    totals = sorted((total for total in (five_stat_total(officer) for officer in officers or []) if total is not None), reverse=True)
    if not totals:
        return None
    picked = totals[:limit]
    return sum(picked) / len(picked)


def format_average(value):
    if value is None:
        return '—'
    rounded = round(value, 1)
    return str(int(rounded)) if rounded == int(rounded) else f'{rounded:.1f}'
