"""Read-only camera movement shared by the map widgets."""
_WHEEL_LISTENERS = []
_WHEEL_READY = False
_WHEEL_SEQS = (
    '<MouseWheel>',
    '<Shift-MouseWheel>',
    '<Option-MouseWheel>',
    '<Command-MouseWheel>',
    '<Control-MouseWheel>',
    '<Mod1-MouseWheel>',
    '<Mod2-MouseWheel>',
)
_MOVE_KEYS = {
    'Up': (0, -1), 'Down': (0, 1), 'Left': (-1, 0), 'Right': (1, 0),
    'w': (0, -1), 's': (0, 1), 'a': (-1, 0), 'd': (1, 0),
    'W': (0, -1), 'S': (0, 1), 'A': (-1, 0), 'D': (1, 0),
}


def move_center(center, dx, dy, step=1, world=(101, 202), offset=0):
    return tuple(max(offset, min(world[i] - 1 + offset, center[i] + d * step))
                 for i, d in enumerate((dx, dy)))


def wheel_direction(delta):
    try:
        value = float(delta)
    except (TypeError, ValueError):
        return 0
    if value == 0:
        return 0
    return 1 if value > 0 else -1


def _over_widget(widget, event):
    try:
        if not widget.winfo_exists() or not widget.winfo_ismapped():
            return None
        sx = int(event.x_root) - widget.winfo_rootx()
        sy = int(event.y_root) - widget.winfo_rooty()
    except Exception:
        return None
    if 0 <= sx < max(1, widget.winfo_width()) and 0 <= sy < max(1, widget.winfo_height()):
        return sx, sy
    return None


def _wheel_dispatch(event):
    for widget, handler in reversed(_WHEEL_LISTENERS):
        hit = _over_widget(widget, event)
        if hit is None:
            continue
        handler(event, hit[0], hit[1])
        return 'break'
    return None


def _wheel_button(delta):
    def inner(event):
        event.delta = delta
        return _wheel_dispatch(event)
    return inner


def _install_wheel(widget):
    global _WHEEL_READY
    if _WHEEL_READY:
        return
    top = widget.winfo_toplevel()
    for seq in _WHEEL_SEQS:
        top.bind_all(seq, _wheel_dispatch)
    top.bind_all('<Button-4>', _wheel_button(1))
    top.bind_all('<Button-5>', _wheel_button(-1))
    _WHEEL_READY = True


def bind_pointer_wheel(widget, handler):
    """Keep a shared wheel dispatch so one map's Leave cannot steal another map's zoom."""
    _WHEEL_LISTENERS.append((widget, handler))

    def drop(_=None):
        _WHEEL_LISTENERS[:] = [(item, fn) for item, fn in _WHEEL_LISTENERS if item is not widget]

    def ready(_=None):
        try:
            _install_wheel(widget)
            widget.focus_set()
        except Exception:
            pass

    widget.bind('<Map>', ready, add='+')
    widget.bind('<Destroy>', drop, add='+')
    widget.bind('<Enter>', lambda _e: widget.focus_set(), add='+')
    for seq in _WHEEL_SEQS:
        widget.bind(seq, _wheel_dispatch, add='+')
    widget.bind('<Button-4>', _wheel_button(1), add='+')
    widget.bind('<Button-5>', _wheel_button(-1), add='+')
    try:
        ready()
    except Exception:
        pass


def navigation_bar(parent, move, reset):
    from tkinter import ttk
    bar = ttk.Frame(parent)
    for label, dx, dy in [('↑', 0, -1), ('↓', 0, 1), ('←', -1, 0), ('→', 1, 0)]:
        ttk.Button(bar, text=label, width=3, command=lambda x=dx, y=dy: move(x, y)).pack(side='left')
    ttk.Button(bar, text='回到定位', command=reset).pack(side='left', padx=4)
    return bar


def bind_arrows(canvas, move):
    def on_key(event):
        step = _MOVE_KEYS.get(event.keysym) or _MOVE_KEYS.get(event.char)
        if not step:
            return
        move(*step)
        return 'break'

    for key in ('Up', 'Down', 'Left', 'Right', 'w', 'a', 's', 'd', 'W', 'A', 'S', 'D'):
        canvas.bind('<' + key + '>', on_key, add='+')
    canvas.bind('<Button-1>', lambda event: canvas.focus_set(), add='+')
