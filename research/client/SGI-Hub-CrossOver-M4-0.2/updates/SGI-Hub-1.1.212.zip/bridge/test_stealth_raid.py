import sys
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / 'app'), str(ROOT / 'bridge')]

from panorama_model import vision_cells, world_xy
from stealth_raid import (
    SOURCE, UNIT_VISION, choose_origin_city, default_cavalry_spec, default_wagon_spec,
    enemy_vision_sets, format_raid_brief, hostile_force_ids, origin_watched, plan_stealth_raid,
    raid_board, resolve_raid_endpoints, split_turns, unit_vision_radius,
)
from unit_move import tile_neighbors


def plains_hex():
    return bytes(101 * 202).hex()


def walk(start, n, key=lambda cell: (cell[1], cell[0])):
    cell = start
    path = [cell]
    for _ in range(n):
        cell = max(tile_neighbors(*cell), key=key)
        path.append(cell)
    return path


def confirmed(entities, player=1):
    rels = [0] * 22
    for lord in entities.get('lords') or []:
        fid = lord.get('force_id')
        if fid != player:
            rels[fid] = 1
    for lord in entities.get('lords') or []:
        if lord.get('force_id') == player:
            lord['diplomacy_relations'] = rels
    return {
        'player_force_id': player,
        'player_identity': {'status': 'confirmed', 'force_id': player},
        'terrain_grid': {'width': 101, 'height': 202, 'types': plains_hex()},
        'entities': entities,
    }


class StealthRaidTests(unittest.TestCase):
    def test_defaults_and_spy_radius(self):
        self.assertEqual(default_cavalry_spec()['points'], 18)
        self.assertEqual(default_wagon_spec()['points'], 14)
        self.assertEqual(unit_vision_radius({}, {'unit_kind': '骑兵'}), UNIT_VISION)
        self.assertEqual(unit_vision_radius({}, {'vision_radius': 4}), 4)
        self.assertIn('末回合才进目标主城视野', SOURCE)

    def test_split_turns_counts_full_mp_chunks(self):
        path = [(0, 0)]
        # fake linear costs of 3
        cells = [(i, 0) for i in range(7)]
        cost = {cell: 3 for cell in cells[1:]}
        chunks = split_turns(cells, 18, lambda cell: cost.get(cell, 3))
        self.assertEqual(len(chunks), 1)
        long = [(i, 0) for i in range(13)]
        chunks = split_turns(long, 18, lambda cell: 3)
        self.assertEqual(len(chunks), 2)
        self.assertEqual(chunks[0][-1], (6, 0))
        self.assertEqual(chunks[1][-1], (12, 0))

    def _raid_state(self, enemy_cell=None, spy=False, extra_units=None):
        path = walk((40, 40), 28)
        origin, dest = path[0], path[-1]
        units = extra_units or []
        if enemy_cell is None:
            enemy_cell = path[12]
        enemy = {
            'unit_id': 9, 'unit_kind': '步兵', 'owner_raw': 2, 'size_index': 0,
            'world_xy_raw': list(enemy_cell),
        }
        if spy:
            enemy['vision_radius'] = 4
        units = [enemy] + units
        state = confirmed({
            'lords': [
                {'force_id': 1, 'name': '鲁', 'capital_city_id': 1},
                {'force_id': 2, 'name': '汉', 'capital_city_id': 2},
            ],
            'cities_and_barriers': [
                {'city_id': 1, 'name': '曲阜', 'type': 'city', 'owner_raw': 1, 'world_xy_raw': list(origin)},
                {'city_id': 2, 'name': '洛阳', 'type': 'city', 'owner_raw': 2, 'world_xy_raw': list(dest)},
            ],
            'field_units': units,
            'generals': [],
        })
        return state, origin, dest, enemy_cell

    def test_path_detours_enemy_unit_vision_and_dashes_last_turn(self):
        state, origin, dest, enemy = self._raid_state()
        dest_row = state['entities']['cities_and_barriers'][1]
        with patch('unit_move.road_cells', return_value=set()):
            plan = plan_stealth_raid(state, origin, dest_row)
        self.assertTrue(plan['ok'], plan.get('error'))
        self.assertEqual(plan['dest_name'], '洛阳')
        self.assertGreaterEqual(plan['cavalry_turns'], 2)
        self.assertGreaterEqual(plan['wagon_turns'], plan['hidden_turns'])
        self.assertEqual(plan['arrive_calendar'], 1 + plan['cavalry_turns'])
        hostile = hostile_force_ids(state, 2)
        self.assertEqual(hostile, {2})
        vision = enemy_vision_sets(state, hostile, dest)
        hidden = set(plan['hidden_path'])
        self.assertTrue(hidden)
        self.assertFalse(hidden & vision['other'])
        self.assertNotIn(enemy, plan['full_path'])
        for cell in plan['hidden_path'][:-1]:
            self.assertNotIn(cell, vision['dest'])
        self.assertEqual(plan['dash_path'][0], plan['staging'])
        self.assertIn(plan['dash_path'][-1], set(tile_neighbors(*dest)) | {dest})
        self.assertIn('粮车', plan['brief'])
        self.assertIn('洛阳', plan['brief'])
        self.assertIn('埋伏', format_raid_brief(plan))
        ox, _, dest_row = resolve_raid_endpoints(state, '城关', dest_row, 2)
        self.assertEqual(ox, origin)
        self.assertEqual(world_xy(dest_row), dest)

    def test_spy_vision_is_wider_than_normal(self):
        state, origin, dest, enemy = self._raid_state(spy=False)
        dest_row = state['entities']['cities_and_barriers'][1]
        spy_state, _, _, _ = self._raid_state(spy=True, enemy_cell=enemy)
        spy_row = spy_state['entities']['cities_and_barriers'][1]
        with patch('unit_move.road_cells', return_value=set()):
            normal = plan_stealth_raid(state, origin, dest_row)
            spy = plan_stealth_raid(spy_state, origin, spy_row)
        self.assertTrue(normal['ok'], normal.get('error'))
        self.assertTrue(spy['ok'], spy.get('error'))
        n_vis = enemy_vision_sets(state, {2}, dest)['other']
        s_vis = enemy_vision_sets(spy_state, {2}, dest)['other']
        self.assertGreater(len(s_vis), len(n_vis))
        self.assertGreaterEqual(len(spy['full_path']), len(normal['full_path']))
        self.assertTrue(set(spy['hidden_path']).isdisjoint(s_vis))

    def test_no_path_when_origin_is_inside_enemy_unit_vision(self):
        origin = (40, 80)
        dest = (40, 120)
        enemy = (40, 80)
        # actually put enemy adjacent covering origin
        nbs = tile_neighbors(*origin)
        enemy = nbs[0]
        state = confirmed({
            'lords': [
                {'force_id': 1, 'name': '鲁', 'capital_city_id': 1},
                {'force_id': 2, 'name': '汉', 'capital_city_id': 2},
            ],
            'cities_and_barriers': [
                {'city_id': 1, 'name': '曲阜', 'type': 'city', 'owner_raw': 1, 'world_xy_raw': list(origin)},
                {'city_id': 2, 'name': '洛阳', 'type': 'city', 'owner_raw': 2, 'world_xy_raw': list(dest)},
            ],
            'field_units': [{
                'unit_id': 3, 'unit_kind': '步兵', 'owner_raw': 2, 'size_index': 0,
                'world_xy_raw': list(enemy),
            }],
            'generals': [],
        })
        dest_row = state['entities']['cities_and_barriers'][1]
        self.assertIn(origin, vision_cells(enemy, 2))
        with patch('unit_move.road_cells', return_value=set()):
            plan = plan_stealth_raid(state, origin, dest_row)
        self.assertFalse(plan['ok'])
        self.assertIn('视野', plan['error'])

    def test_skips_watched_nearest_city(self):
        path = walk((36, 36), 30)
        dest = path[-1]
        near = path[12]
        far = path[0]
        enemy = tile_neighbors(*near)[0]
        state = confirmed({
            'lords': [
                {'force_id': 1, 'name': '鲁', 'capital_city_id': 1},
                {'force_id': 2, 'name': '汉', 'capital_city_id': 2},
            ],
            'cities_and_barriers': [
                {'city_id': 1, 'name': '曲阜', 'type': 'city', 'owner_raw': 1, 'world_xy_raw': list(far)},
                {'city_id': 3, 'name': '琅邪', 'type': 'city', 'owner_raw': 1, 'world_xy_raw': list(near)},
                {'city_id': 2, 'name': '洛阳', 'type': 'city', 'owner_raw': 2, 'world_xy_raw': list(dest)},
            ],
            'field_units': [{
                'unit_id': 9, 'unit_kind': '步兵', 'owner_raw': 2, 'size_index': 0,
                'world_xy_raw': list(enemy),
            }],
            'generals': [],
        })
        dest_row = state['entities']['cities_and_barriers'][2]
        self.assertTrue(origin_watched(state, near, {2}))
        self.assertFalse(origin_watched(state, far, {2}))
        with patch('unit_move.road_cells', return_value=set()):
            origin, plan = choose_origin_city(state, dest_row)
            board = raid_board(state)
        self.assertEqual(origin, far, plan.get('origin_reason'))
        self.assertTrue(plan.get('ok'), plan.get('error'))
        self.assertIn('周边有敌', plan.get('origin_reason') or '')
        self.assertEqual(board[0]['force_name'], '汉')
        self.assertTrue(board[0]['ok'])
        self.assertEqual(board[0]['origin_name'], '曲阜')

    def test_hub_has_raid_tab_not_panorama_button(self):
        pan = (ROOT / 'app/panorama_map.py').read_text(encoding='utf-8')
        omni = (ROOT / 'app/omni_window.py').read_text(encoding='utf-8')
        page = (ROOT / 'app/stealth_raid_page.py').read_text(encoding='utf-8')
        self.assertIn("mode == 'raid'", pan)
        self.assertIn('def show_raid', pan)
        self.assertIn("mode='raid'", page)
        self.assertNotIn("text='偷袭主城', command=self.toggle_raid", pan)
        self.assertIn("text='偷袭主城'", omni)
        self.assertIn('StealthRaidPage', omni)
        self.assertNotIn('陷阱（只读）', omni)
        self.assertIn('raid_board', page)
        self.assertNotIn('#c32620', (ROOT / 'app/stealth_raid.py').read_text(encoding='utf-8'))


if __name__ == '__main__':
    unittest.main()
