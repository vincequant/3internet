import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / 'app'), str(ROOT / 'bridge')]
from training_sim import (
    CAMP_YIELD, GOAL_RAW, GOAL_STOCK, OPENING, apply_action, goal_hit, mix_recruit,
    opening_state, project_goal, train_gain,
)


class TrainingSimEngine(unittest.TestCase):
    def test_opening_twenty_two_and_ba_infantry(self):
        self.assertEqual(len(OPENING), 22)
        self.assertEqual([row[0] for row in OPENING], list(range(22)))
        ba = opening_state(name='巴')
        self.assertEqual(ba['stock']['infantry'], 35000)
        wei = opening_state(0)
        self.assertEqual(wei['stock'], {'infantry': 30000, 'cavalry': 10000, 'bow': 20000})
        self.assertEqual(wei['raw']['bow'], 130)
        self.assertEqual(wei['camp']['cavalry'], 6500)

    def test_train_gain_strips_stock_ratio_via_formula(self):
        self.assertEqual(train_gain('bow', 0), 20)
        self.assertEqual(train_gain('bow', 100000), 10)
        self.assertEqual(train_gain('cavalry', 0), 30)
        self.assertEqual(train_gain('infantry', 0), 40)

    def test_summer_mix_and_three_commands(self):
        st = opening_state(name='燕')
        st['stock']['bow'] = 0
        st['raw']['bow'] = 300
        st['camp']['bow'] = 100000
        for _ in range(3):
            st = apply_action(st, 'other')
        self.assertEqual(st['season'], 1)
        self.assertEqual(st['stock']['bow'], 100000)
        self.assertEqual(st['raw']['bow'], 180)
        self.assertEqual(st['other'], 3)
        self.assertEqual(st['build'] + st['train'], 0)

    def test_goal_counts_only_build_and_train(self):
        st = opening_state(name='秦')
        st['stock']['bow'] = GOAL_STOCK
        st['raw']['bow'] = 190
        st = apply_action(st, 'other')
        st = apply_action(st, 'train:bow')
        self.assertTrue(goal_hit(st, 'bow'))
        hit = st['reached']['bow']
        self.assertEqual(hit['train'], 1)
        self.assertEqual(hit['build'], 0)
        self.assertEqual(hit['other'], 1)
        self.assertEqual(hit['total'], 1)

    def test_mix_seed_cannot_land_at_200(self):
        raw, stock = mix_recruit(300, 0, 100000)
        self.assertEqual((raw, stock), (180, 100000))
        self.assertLess(raw, GOAL_RAW)

    def test_project_wei_bow_reports_build_plus_train(self):
        proj = project_goal(opening_state(0), 'bow')
        self.assertTrue(proj['ok'])
        self.assertGreater(proj['build'], 0)
        self.assertGreater(proj['train'], 0)
        self.assertEqual(proj['total'], proj['build'] + proj['train'])
        self.assertGreaterEqual(proj['stock'], GOAL_STOCK)
        self.assertGreaterEqual(proj['raw'], GOAL_RAW)
        already = opening_state(0)
        already['stock']['bow'] = 100000
        already['raw']['bow'] = 200
        zero = project_goal(already, 'bow')
        self.assertEqual(zero['total'], 0)

    def test_camp_yield_matches_archive_median(self):
        self.assertEqual(CAMP_YIELD['bow'], 9240)
        self.assertEqual(CAMP_YIELD['cavalry'], 3225)
        self.assertEqual(CAMP_YIELD['infantry'], 14165)

    def test_panel_is_first_strategy_tab(self):
        text = (ROOT / 'app' / 'rules_panel.py').read_text(encoding='utf-8')
        self.assertIn('TrainingSimPanel', text)
        self.assertLess(text.index("text='盖营练兵模拟'"), text.index("text='盖营与练兵实测'"))
        self.assertIn('camp-train-simulator', (ROOT / 'RELEASE.json').read_text(encoding='utf-8'))
