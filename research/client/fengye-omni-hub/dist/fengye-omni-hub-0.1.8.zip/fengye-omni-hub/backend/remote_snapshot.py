"""One-shot remote reader; optionally search through an existing relay.
optionally writes one hub control request for a running p34 probe.

Executed with `python3 -` over SSH. No login, room join, memory writes,
trigger writes, or persistent process. Only --search sends a normal room query.
Only --control writes a single validated request file for the probe to poll.
"""
import base64
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import time


def json_file(path, default=None):
    try:
        return json.loads(path.read_text())
    except (OSError, ValueError):
        return default


def json_lines(path, cap=131072):
    try:
        with path.open('rb') as f:
            size = path.stat().st_size
            head = f.read(min(size, cap))
            if size > cap:
                f.seek(max(cap, size - cap))
                tail = f.read(cap)
            else:
                tail = b''
        rows = []
        seen = set()
        for line in (head + b'\n' + tail).splitlines():
            try:
                row = json.loads(line)
                key = line
                if isinstance(row, dict) and key not in seen:
                    rows.append(row)
                    seen.add(key)
            except ValueError:
                pass
        return rows
    except OSError:
        return []


def processes():
    result = []
    raw = subprocess.check_output(['ps', '-axo', 'pid=,ppid=,command='], text=True)
    names = {'p21_orchestrate.py': 'orchestrator', 'p25_orchestrate.py': 'orchestrator',
             'p29_receive_orchestrate.py': 'orchestrator', 'p34_d8_orchestrate.py': 'orchestrator',
             'p42_prestart_d8_run.py': 'orchestrator',
             'p1_directed_probe.py': 'driver', 'p2_loader_host.py': 'relay',
             'p20_cmd2_verified_probe.py': 'ghost', 'p24_cmd2_featureless_probe.py': 'ghost',
             'p28_receive_probe.py': 'ghost', 'p34_d8_probe.py': 'ghost',
             'p42_prestart_d8_probe.py': 'ghost', 'p43_prestart_d8_probe.py': 'ghost',
             'p4_host_watch.py': 'watch', 'p33_host_watch.py': 'watch'}
    for line in raw.splitlines():
        parts = line.strip().split(None, 2)
        if len(parts) != 3:
            continue
        argv = [a.strip('"') for a in shlex.split(parts[2], posix=False)]
        scripts = [Path(a.replace('\\', '/')).name for a in argv]
        role = next((names[n] for n in scripts if n in names), None)
        if not role:
            continue
        row = {'pid': int(parts[0]), 'parent_pid': int(parts[1]), 'role': role}
        for flag, key in (('--line', 'line'), ('--target', 'target'), ('--session-name', 'session')):
            if flag in argv and argv.index(flag) + 1 < len(argv):
                row[key] = argv[argv.index(flag) + 1]
        result.append(row)
    return result


def latest_run(lab):
    """Pick the newest chain pointer inside evidence/ (p42/p34 first, legacy kept).

    Returns (run_path, pointer_state, pointer_source). A pointer only selects
    which run directory is read; freshness is judged from the run's own data.
    """
    root = (lab / 'evidence').resolve()
    found = []
    for source in ('p42-prestart-d8-20261016', 'p34-d8-invisible-20261015',
                   'p27-start-preflight-20261015'):
        active = json_file(lab / 'evidence' / source / 'active-run.json', {})
        evidence = active.get('evidence')
        if not evidence:
            continue
        candidate = Path(evidence).resolve()
        if root not in candidate.parents:
            continue
        wall = active.get('wall')
        found.append((wall if isinstance(wall, (int, float)) else 0, candidate,
                      active.get('state'), source))
    if found:
        found.sort(key=lambda item: item[0])
        _, candidate, state, source = found[-1]
        return candidate, state, source
    return (lab / 'evidence/p20-verified-restart-20261014').resolve(), None, 'legacy_fallback'


def collector_path(run, identity):
    # Identity is evidence, not permission to read an arbitrary file. Reject
    # absolute paths, traversal and symlinks escaping this specific run.
    name = identity.get('collector_log', 'p20_live.jsonl')
    if name not in ('p20_live.jsonl', 'p28_live.jsonl', 'p34_live.jsonl', 'p42_live.jsonl'):
        return None
    path = (run / name).resolve()
    return path if path.parent == run.resolve() else None


def counter(rows, key, fallback=0):
    values = [r[key] for r in rows if isinstance(r.get(key), int)
              and not isinstance(r[key], bool) and r[key] >= 0]
    return max(values) if values else fallback


def start_snapshot_faction(logs):
    """Return only named row facts from the latest complete cmd7 snapshot.

    Missing/unmatched data never means an unbound member. ID and freshness
    are checked separately by the local presenter against the host watch.
    """
    complete = [r for r in logs if r.get('ev') == 'received_packet'
                and isinstance(r.get('object'), dict) and r['object'].get('cmd') == 7
                and r['object'].get('class_name') == 'CSanInetInitGameData'
                and isinstance(r.get('snapshot'), dict)
                and isinstance(r['snapshot'].get('rows'), list)
                and len(r['snapshot']['rows']) == 8
                and isinstance(r.get('length'), int)
                and r['snapshot'].get('consumed') == r['length']]
    if not complete:
        return {}
    packet = complete[-1]
    rows = [r for r in packet['snapshot']['rows'] if isinstance(r, dict)
            and isinstance(r.get('name_e'), dict)
            and r['name_e'].get('gbk_display') == '风夜']
    if len(rows) != 1:
        return {}
    row = rows[0]
    binding = row.get('binding46')
    if not isinstance(binding, int) or isinstance(binding, bool) or not -1 <= binding <= 0xffffffff:
        return {}
    # The wire decoder preserves DWORDs unsigned; native -1 is the sentinel.
    if binding == 0xffffffff:
        binding = -1
    label = (row.get('text4c') or {}).get('gbk_display')
    return {'observed_at': packet.get('wall'), 'member_id': row.get('id'),
            'binding46': binding, 'faction_name': label if isinstance(label, str) else None,
            'source': 'cmd7_snapshot'}


P34_FRAME_CAP = 80
CONTROL_TEXT_MAX = 120


def write_control(lab, payload):
    """Write one hub control request into the current p34 run directory.

    Validates the payload, requires a running p34 probe, and atomically
    replaces hub-control.json. This function never executes game actions; the
    probe polls the file and applies once-only semantics by request id.
    """
    if not isinstance(payload, dict):
        return {'error': 'bad_payload'}
    rid = payload.get('id')
    if not isinstance(rid, str) or not 0 < len(rid) <= 64:
        return {'error': 'bad_id'}
    op = payload.get('op')
    request = {'id': rid, 'op': op}
    if op == 'chat':
        text = payload.get('text')
        if not isinstance(text, str) or not 0 < len(text) <= CONTROL_TEXT_MAX:
            return {'error': 'bad_text'}
        try:
            text.encode('gbk')
        except UnicodeEncodeError:
            return {'error': 'text_not_gbk'}
        request['text'] = text
    elif op != 'stop':
        return {'error': 'unknown_op'}
    run, state, source = latest_run(lab)
    if not ((run / 'p34_live.jsonl').exists() or (run / 'p42_live.jsonl').exists()):
        return {'error': 'no_p34_run'}
    try:
        raw = subprocess.check_output(['ps', '-axo', 'command='], text=True)
    except (OSError, subprocess.SubprocessError):
        return {'error': 'ps_unavailable'}
    if all(name not in raw for name in ('p34_d8_probe.py', 'p42_prestart_d8_probe.py',
                                        'p43_prestart_d8_probe.py')):
        return {'error': 'probe_not_running'}
    path = run / 'hub-control.json'
    temp = run / 'hub-control.json.tmp'
    temp.write_text(json.dumps(request, ensure_ascii=False), encoding='utf-8')
    temp.replace(path)
    return {'status': 'sent', 'id': rid, 'op': op, 'run': run.name}


def p34_binding(value):
    """Wire decoder keeps DWORDs unsigned; native -1 is the unbound sentinel."""
    return -1 if value == 0xffffffff else value


def p34_snapshot_block(packet):
    rows = []
    for row in (packet.get('snapshot') or {}).get('rows', []):
        if not isinstance(row, dict):
            continue
        rows.append({'i': row.get('index'), 'id': row.get('id'), 'w4': row.get('w4'),
                     'name': (row.get('name_e') or {}).get('gbk_display'),
                     'state42': row.get('state42'),
                     'binding46': p34_binding(row.get('binding46')),
                     'faction': (row.get('text4c') or {}).get('gbk_display')})
    return {'observed_at': packet.get('wall'),
            'cmd': (packet.get('object') or {}).get('cmd'), 'rows': rows}


def p34_chat_text(raw_hex):
    """Best-effort text from a type-3 local-delivery payload; never invented.

    Live sample (2026-10-16, run-115248): the payload is the GBK message plus
    trailing NUL bytes (b'hi\\x00'). Wire-shaped frames carry the text after
    the all-ones broadcast marker. Unknown shapes return None, never a guess.
    """
    try:
        data = bytes.fromhex(str(raw_hex or ''))
    except ValueError:
        return None
    candidates = []
    stripped = data.rstrip(b'\x00')
    if stripped:
        candidates.append(stripped)
    idx = data.find(b'\xff\xff\xff\xff')
    if idx >= 0 and idx + 4 < len(data):
        tail = data[idx + 4:].split(b'\x00')[0]
        if tail:
            candidates.append(tail)
    for tail in candidates:
        if not 0 < len(tail) <= 160:
            continue
        try:
            text = tail.decode('gbk')
        except UnicodeDecodeError:
            continue
        if text.strip() and all(ch.isprintable() or ch == '\u3000' for ch in text):
            return text
    return None


def p34_intel(run, identity, logs, pointer_state, pointer_source):
    """Bounded read-only digest of one p34 run for the local hub.

    Reads only files already inside the run directory plus the loaded log.
    Raw payloads are truncated to one display line; process pointers and
    machine paths are never collected.
    """
    summary = json_file(run / 'summary.json', {}) or {}
    registration = json_file(run / 'registration-receipt.json', {}) or {}
    gate = json_file(run / 'register-gate.json', {}) or {}
    fakeexit = json_file(run / 'fakeexit-effect.json', {}) or {}
    sent = json_file(run / 'd8-sent-receipt.json', {}) or json_file(run / 'p42-d8-sent.json', {}) or {}
    effect = json_file(run / 'd8-effect.json', {}) or {}
    withdrawn = json_file(run / 'host-withdrawn.json', {}) or {}
    control_result = json_file(run / 'hub-control-result.json', {}) or {}
    control_request = json_file(run / 'hub-control.json', {}) or {}
    frames = []
    chat_messages = []
    snapshots = {'initial': None, 'start': None}
    sync_nonempty = []
    notifications = {}
    sync_rounds = 0
    d8_enter = d8_return = cmd1_ack = None
    health = None
    listen_started = None
    for row in logs:
        ev = row.get('ev')
        if ev == 'received_packet':
            obj = row.get('object') or {}
            frames.append({'wall': row.get('wall'), 'type': row.get('type'),
                           'cmd': obj.get('cmd'), 'cls': obj.get('class_name'),
                           'len': row.get('length'),
                           'sha8': str(row.get('sha256') or '')[:12]})
            snap = row.get('snapshot')
            if (isinstance(snap, dict) and len(snap.get('rows') or []) == 8
                    and snap.get('consumed') == row.get('length')
                    and obj.get('class_name') == 'CSanInetInitGameData'
                    and obj.get('cmd') in (3, 7)):
                block = p34_snapshot_block(row)
                if obj.get('cmd') == 3:
                    snapshots['initial'] = block
                else:
                    snapshots['start'] = block
            if row.get('type') == 3:
                message = p34_chat_text(row.get('raw_hex'))
                if message:
                    chat_messages.append({'wall': row.get('wall'), 'text': message})
        elif ev == 'sync_round_complete':
            sync_rounds += 1
        elif ev == 'native_slot_observed':
            inner = row.get('inner') or {}
            control = inner.get('control') or {}
            slot_kind = control.get('control_cmd')
            if slot_kind == 3:
                sync_rounds += 1
            elif slot_kind == 5:
                slot_records = []
                for record in control.get('records') or []:
                    if not isinstance(record, dict):
                        continue
                    raw_hex = str(record.get('raw_hex') or '')
                    try:
                        sha8 = hashlib.sha256(bytes.fromhex(raw_hex)).hexdigest()[:12]
                    except ValueError:
                        sha8 = None
                    slot_records.append({'sender': record.get('sender'),
                                         'len': record.get('length'), 'sha8': sha8,
                                         'raw': raw_hex[:240]})
                if slot_records:
                    sync_nonempty.append({'wall': row.get('wall'), 'round': inner.get('seq'),
                                          'records': slot_records})
        elif ev == 'sync_batch_accepted' and row.get('count'):
            records = [{'sender': r.get('sender'), 'len': r.get('length'),
                        'sha8': str(r.get('sha256') or '')[:12],
                        'raw': str(r.get('raw_hex') or '')[:240]}
                       for r in row.get('records', []) if isinstance(r, dict)]
            sync_nonempty.append({'wall': row.get('wall'), 'round': row.get('round'),
                                  'records': records})
        elif ev == 'notification':
            key = row.get('message')
            notifications[key] = notifications.get(key, 0) + 1
        elif ev in ('d8_send_enter', 'd8_prestart_send_enter'):
            d8_enter = row
        elif ev in ('d8_send_return', 'd8_prestart_send_return'):
            d8_return = row
        elif ev == 'cmd1_ack_observed':
            cmd1_ack = row
        elif ev == 'send_return' and row.get('label') == 'cmd1' and cmd1_ack is None:
            cmd1_ack = row
        elif ev == 'health_sample':
            health = {k: row.get(k) for k in
                      ('wall', 'connected', 'packets', 'release_calls', 'receiver_errors',
                       'tx_seq', 'native_state', 'd8_seconds', 'last_activity_age',
                       'observe_remaining', 'log_bytes')}
        elif ev == 'passive_listen_started':
            listen_started = row.get('wall')
    d8_wall = (d8_return or {}).get('wall') or sent.get('wall')
    if not isinstance(d8_wall, (int, float)):
        d8_wall = None
    cmd1_wall = (cmd1_ack or {}).get('wall')
    if not isinstance(cmd1_wall, (int, float)):
        cmd1_wall = None
    observe = identity.get('observe_seconds')
    anchor = d8_wall if d8_wall is not None else cmd1_wall
    end_wall = (anchor + observe) if anchor is not None and isinstance(observe, (int, float)) else None
    received_after_d8 = None
    if d8_wall is not None:
        received_after_d8 = sum(1 for f in frames if isinstance(f.get('wall'), (int, float))
                                and f['wall'] >= d8_wall)
    trims = frames[-P34_FRAME_CAP:]
    last = trims[-1] if trims else {}
    return {
        'run_name': run.name,
        'pointer_state': pointer_state,
        'pointer_source': pointer_source,
        'registration_verified': bool(summary.get('registered_verified')) or bool(registration.get('own_id')),
        'registered': {'own_id': (registration.get('own_id') or sent.get('own_id')
                                  or gate.get('own_id')),
                       'machine_name': registration.get('machine_name') or next(
                           (r.get('machine_name') for r in logs if r.get('ev') == 'start_enter'), None),
                       'w4': (registration.get('row') or {}).get('w4'),
                       'row_state': (registration.get('row') or {}).get('state'),
                       'pending_2723': (registration.get('row') or {}).get('pending_2723')},
        'fakeexit': {'P_state': fakeexit.get('P_state'),
                     'observed_wall': fakeexit.get('observed_wall')},
        'd8': {'sent_once': sum(1 for r in logs
                                if r.get('ev') in ('d8_send_return', 'd8_prestart_send_return')) == 1,
               'sent_wall': d8_wall,
               'body_hex': (d8_enter or {}).get('body_hex') or (d8_enter or {}).get('raw_hex'),
               'raw_rc': (d8_return or sent).get('raw_rc'),
               'mapped_rc': (d8_return or {}).get('mapped_rc'),
               'target': (d8_return or {}).get('target'),
               'effect': ({'row_present': effect.get('row_present'),
                           'unknown': effect.get('unknown'),
                           'observed_wall': effect.get('observed_wall')} if effect else None),
               'withdrawn': ({'observed_wall': withdrawn.get('observed_wall'),
                              'consecutive_absent_samples': withdrawn.get('consecutive_absent_samples')}
                             if withdrawn else None)},
        'window': {'anchor_wall': anchor, 'observe_seconds': observe,
                   'end_wall': end_wall,
                   'anchored_by': 'd8' if d8_wall is not None else ('cmd1' if cmd1_wall is not None else None)},
        'longrun': {'long_run': bool(identity.get('long_run')),
                    'health_seconds': identity.get('health_seconds'),
                    'tail_seconds': identity.get('tail_seconds'),
                    'listen_started_wall': listen_started,
                    'health': health,
                    'end_reason': summary.get('end_reason'),
                    'tail_recorded': bool(summary.get('post_exit_tail_written'))},
        'counters': {'received': len(frames),
                     'released': counter(logs, 'release_calls'),
                     'errors': counter(logs, 'receiver_errors',
                                       sum(1 for r in logs if r.get('ev') == 'receiver_error')),
                     'rounds': sync_rounds,
                     'received_after_d8': received_after_d8,
                     'last_packet_wall': last.get('wall'),
                     'last_packet_cmd': last.get('cmd')},
        'snapshots': snapshots,
        'frames': trims,
        'sync': {'rounds': sync_rounds, 'nonempty': sync_nonempty[-40:]},
        'notifications': {'wm_event': notifications.get(34048, 0),
                          'wm_data': notifications.get(34049, 0),
                          'wm_chat': notifications.get(34050, 0)},
        'control': {
            'last_result': ({'id': control_result.get('id'), 'op': control_result.get('op'),
                             'rc': control_result.get('rc'), 'wall': control_result.get('wall'),
                             'chars': control_result.get('chars')}
                            if isinstance(control_result.get('id'), str) else None),
            'pending': ({'id': control_request.get('id'), 'op': control_request.get('op')}
                        if isinstance(control_request.get('id'), str)
                        and control_request.get('id') != control_result.get('id') else None),
            'events': [{'ev': r.get('ev'), 'wall': r.get('wall'),
                        'request_id': r.get('request_id'), 'text': r.get('text'),
                        'rc': r.get('rc'), 'reason': r.get('reason')}
                       for r in logs if str(r.get('ev', '')).startswith('control_')][-8:],
        },
        'chat': {'wm_chat_count': notifications.get(34050, 0),
                 'type3_frames': sum(1 for f in frames if f.get('type') == 3),
                 'messages': chat_messages[-10:]},
    }


def search_existing_relay(lab, chain):
    drivers = [p for p in chain if p['role'] == 'driver']
    relays = [p for p in chain if p['role'] == 'relay']
    ghosts = [p for p in chain if p['role'] == 'ghost']
    if len(drivers) != 1 or len(relays) != 1 or len(ghosts) != 1:
        return {'error': '需唯一的现有风夜中继链；未重新登录', 'query_status': 'unavailable'}
    if drivers[0].get('line') != '多线3' or relays[0]['parent_pid'] != drivers[0]['pid']:
        return {'error': '当前中继线路未核实为多线3；未执行搜索', 'query_status': 'unavailable'}
    rt = json_file(Path.home() / 'Library/Application Support/SGI-Wine/runtime.json', {})
    prefix = Path.home() / 'Library/Application Support/SGI-Wine/prefix-monitor'
    env = dict(os.environ, WINEPREFIX=str(prefix), WINEDEBUG='-all',
               DYLD_FALLBACK_LIBRARY_PATH=rt.get('dependency_lib', ''))
    command = [rt['wine'], str(lab / 'python32/sgi-protocol-probe.exe'), '-X', 'utf8',
               str(lab / 'koeinm_probe.py'), '--dll', r'C:\sgi\run-3.5\3I\Koeinm.dll',
               '--target', '255.255.255.255', '--port', '7777', '--app-id', '78731', '--with-nethook']
    try:
        proc = subprocess.run(command, env=env, capture_output=True, text=True, timeout=15)
        results = [json.loads(s) for s in proc.stdout.splitlines() if s.startswith('{')]
        result = next((r for r in reversed(results) if 'query_status' in r), {})
        if proc.returncode or result.get('start_rc') != 0 or result.get('search_rc') != 0:
            return {'error': '现有中继搜索未成功；未重登或加入房间', 'query_status': 'unavailable'}
        return {'observed_at': result.get('observed_at'), 'line': '多线3',
                'query_status': result['query_status'], 'rooms': result.get('rooms', []),
                'source': 'SearchSession through existing relay', 'opensession_join': False,
                'line_verified': True}
    except (OSError, ValueError, KeyError, subprocess.TimeoutExpired):
        return {'error': '现有中继搜索超时或不可用；未重新登录', 'query_status': 'unavailable'}


def snapshot(lab, search=False):
    run, pointer_state, pointer_source = latest_run(lab)
    chain = processes()
    identity = json_file(run / 'run_identity.json', {})
    watch = json_lines(run / 'host_watch.jsonl')
    watch.sort(key=lambda r: r.get('wall', 0))
    path = collector_path(run, identity)
    # P45: long runs grow the collector log past 100MB-scale; read a bounded
    # head+tail (early gate/D8 events plus the newest counters/health) instead
    # of whole-file reads on every refresh. Raw logs stay on the collector.
    logs = json_lines(path, cap=2 * 1024 * 1024) if path else []
    logs.sort(key=lambda r: r.get('wall', 0))
    activity = {}
    previous = {}
    member_names = {}
    for tick in watch:
        for member in tick.get('members', []):
            if isinstance(member, dict) and member.get('id') and member.get('name'):
                member_names[str(member['id'])] = member['name']
            key = str(member.get('id'))
            active = member.get('active')
            if key in previous and active != previous[key]:
                activity[key] = tick.get('wall')
            previous[key] = active
    safe_events = []
    for row in logs:
        if row.get('ev') in ('joined', 'registered', 'register_unverified', 'watchdog_started',
                              'wd_trigger_seen', 'wd_fired', 'wd_complete', 'send_enter',
                              'send_return', 'wd_err', 'wd_session_dead', 'session_dead_before_register',
                              'received_packet', 'packet_release', 'receiver_error', 'window_bindings',
                              'open_return', 'host_gate_receipt', 'abort', 'closed', 'snapshot_stored',
                              'ready_once', 'scenario_checked', 'prep_blocked', 'start_command_received',
                              'cmd1_ack_observed', 'sync_worker_starting', 'sync_api_enter',
                              'sync_api_return', 'sync_round_complete', 'sync_batch_accepted',
                              'sync_failed', 'd8_send_enter', 'd8_send_return', 'worker_exit',
                              'worker_finished', 'passive_listen_started', 'stop_requested',
                              'exit_enter', 'exit_return', 'end_enter', 'end_return'):
            event = {k: row[k] for k in ('ev', 'wall', 'wine_pid', 'label', 'fire', 'n', 'rc', 'dt', 'attempts', 'cmd') if k in row}
            if row.get('ev') == 'received_packet':
                cmd = (row.get('object') or {}).get('cmd')
                if isinstance(cmd, int) and not isinstance(cmd, bool):
                    event['cmd'] = cmd
            safe_events.append(event)
    instrumented = any(r.get('ev') == 'send_enter' for r in logs)
    p20 = {'watchdog_started_at': next((r.get('wall') for r in reversed(logs) if r.get('ev') == 'watchdog_started'), None),
           'cmd23_attempts': sum(r.get('ev') == 'send_enter' and str(r.get('label', '')).startswith('cmd23') for r in logs) if instrumented else None,
           'cmd23_returns': sum(r.get('ev') == 'send_return' and str(r.get('label', '')).startswith('cmd23') for r in logs) if instrumented else None,
           'wd_fired': sum(r.get('ev') == 'wd_fired' for r in logs),
           'registration': 'verified' if any(r.get('ev') == 'registered' for r in logs) else 'unknown',
           'last_log_at': logs[-1].get('wall') if logs else None}
    identity_mode = str(identity.get('mode') or '')
    if identity_mode.startswith('p34'):
        receive_mode = 'p34_spectator'
    elif identity_mode.startswith('p42'):
        receive_mode = 'p42_spectator'
    elif identity_mode in ('capture_only', 'ready_on_valid_cmd7'):
        receive_mode = identity_mode
    else:
        receive_mode = 'cmd23_watchdog'
    packets = [r for r in logs if r.get('ev') == 'received_packet']
    last_packet = packets[-1] if packets else {}
    last_object = last_packet.get('object') or {}
    p20.update(mode=receive_mode,
               packet_count=counter(logs, 'packet_index', len(packets)),
               release_calls=counter(logs, 'release_calls'),
               receiver_errors=counter(logs, 'receiver_errors', sum(r.get('ev') == 'receiver_error' for r in logs)),
               last_packet_at=last_packet.get('wall'), last_cmd=last_object.get('cmd'),
               cmd9_attempts=sum(r.get('ev') == 'send_enter' and r.get('label') == 'cmd9' for r in logs) if instrumented else None,
               cmd9_returns=sum(r.get('ev') == 'send_return' and r.get('label') == 'cmd9' for r in logs) if instrumented else None,
               start_command_received_at=next((r.get('wall') for r in reversed(logs) if r.get('ev') == 'start_command_received'), None),
               automatic_ready=identity.get('automatic_ready') is True,
               start_snapshot=start_snapshot_faction(logs),
               log_allowed=path is not None)
    # A selfcheck counter may be newer than the retained packet events.
    p20['packet_count'] = max(p20['packet_count'], counter(logs, 'packets'))
    p34_payload = None
    if (identity_mode.startswith('p34') or identity_mode.startswith('p42')
            or (run / 'p34_live.jsonl').exists()):
        p34_payload = p34_intel(run, identity, logs, pointer_state, pointer_source)
        p34_payload['live_probe'] = any(p.get('role') == 'ghost' for p in chain)
        if p34_payload.get('registration_verified'):
            p20['registration'] = 'verified'
    host = next((p for p in chain if p['role'] == 'driver'), {})
    known_host = identity.get('host') or {}
    queried_at = time.time()
    current_target = bool(host.get('target') and host.get('session'))
    payload = {'queried_at': queried_at, 'source_kind': 'remote_readonly',
               'host_watch': watch[-1] if watch else None, 'activity': activity,
               'member_names': member_names,
               'chain': chain, 'ghost_log': p20, 'events': safe_events[-20:],
               'p34': p34_payload,
               'host': {'virtual_ip': host.get('target') or known_host.get('host_ip'),
                        'session': host.get('session') or known_host.get('session_name'),
                        'source': 'current_driver' if current_target else 'run_identity',
                        'observed_at': queried_at if current_target else identity.get('wall')},
               'line': host.get('line') or identity.get('line'), 'run_name': run.name,
               'source_sha256': identity.get('source_sha256', {})}
    if search:
        payload['room_query'] = search_existing_relay(lab, chain)
    return payload


if __name__ == '__main__':
    try:
        lab = Path.home() / 'sgi-protocol-lab-20260915'
        control = next((a for a in sys.argv[1:] if a.startswith('--control=')), None)
        if control is not None:
            payload = json.loads(base64.urlsafe_b64decode(control.split('=', 1)[1]).decode('utf-8'))
            print(json.dumps(write_control(lab, payload), ensure_ascii=False))
        else:
            print(json.dumps(snapshot(lab, '--search' in sys.argv), ensure_ascii=False))
    except Exception as exc:
        # Exception messages can contain command data. Return only its type.
        print(json.dumps({'error': '远端状态读取失败', 'error_type': type(exc).__name__}))
        sys.exit(2)
