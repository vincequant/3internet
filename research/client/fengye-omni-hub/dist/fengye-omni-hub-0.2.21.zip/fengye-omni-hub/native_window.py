"""The complete native OmniWindow with an additional Fengye console."""
import json
import queue
import subprocess
import sys
import time
import threading
import tkinter as tk
from datetime import datetime
from tkinter import ttk, messagebox

from omni_window import OmniWindow, DAMASK, PANEL, WELL, INK, GOLD, GOLD_HI, MUTED, WARN, BG
from fengye_source import FengyeSource, control_ready, validate_control
from room_client import RoomClient
from backend.room_protocol import nickname
from backend import fengyun_local
from backend.lab_remote import lab_remote


def wall_text(value):
    if not isinstance(value, (int, float)):
        return '—'
    try:
        return datetime.fromtimestamp(value).strftime('%m-%d %H:%M:%S')
    except (OSError, ValueError, OverflowError):
        return '—'


def dur_text(value):
    """Human duration for long-run listening windows; never negative."""
    try:
        seconds = int(max(0, float(value)))
    except (TypeError, ValueError):
        return '—'
    hours, rem = divmod(seconds, 3600)
    minutes = rem // 60
    if hours:
        return '{}時{:02d}分'.format(hours, minutes)
    if minutes:
        return '{}分'.format(minutes)
    return '{}秒'.format(rem)


def force_payload(result):
    """席位助手 JSON（{'slot_forces': ...}）：直接給的 dict 或 stdout 尾行的 JSON。"""
    if isinstance(result, dict) and 'slot_forces' in result:
        return result
    raw = (result.get('stdout') or '').strip()
    for line in reversed(raw.splitlines()):
        try:
            payload = json.loads(line)
        except ValueError:
            continue
        if isinstance(payload, dict) and 'slot_forces' in payload:
            return payload
    return None


def notify_operator(title, message, sound='Glass'):
    """摘席流程的本地提示：聲音＋系統通知。

    讓操作者在遊戲視窗在前時也能察覺「先勿按開始／可以按開始」。
    只在本機發出（macOS osascript/afplay）；不觸碰遊戲、會話或網路。
    """
    try:
        if sys.platform == 'darwin':
            safe_title = str(title).replace('"', ' ')
            safe_message = str(message).replace('"', ' ')
            subprocess.Popen(
                ['osascript', '-e',
                 'display notification "{}" with title "{}"'.format(safe_message, safe_title)],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            subprocess.Popen(
                ['afplay', '/System/Library/Sounds/{}.aiff'.format(sound)],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


class FengyeWindow(OmniWindow):
    def __init__(self, root, source=None):
        self.source = source or FengyeSource()
        self.messages = queue.Queue()
        self.jobs = queue.Queue(maxsize=1)
        self.view = self.source.view
        self.control_busy = False
        self.cooldown = 0
        self.pending_id = None
        self.pending_run = None
        self.pending_uncertain = False
        self.render_signature = None
        self.render_error = None
        self.rooms = RoomClient(host=self.source.sources.host, replay=bool(self.source.sources.source_file))
        self.room_busy = False
        self.room_pending = None
        self.room_uncertain = False
        self.room_rows = {}
        self.room_signature = None
        self.retry = None
        super().__init__(root)
        root.title('風夜 · 全知情報 Hub 0.2.21')
        root.minsize(1120, 700)
        self.version_label.configure(text='風夜 0.2.21')
        self.identity_label.master.pack_forget()
        self.status.configure(text='玩家全知來源已關閉 · 僅風夜資料', fg='#ffd08a')
        self.coverage.configure(text='世界情報尚未由風夜封包完整還原；缺失資料保持未知。')
        # 2026-10-17：玩家視角頁面（永久停用）不再顯示會誤導的等待文案。
        try:
            self.resources.configure(
                text='本頁是原版「玩家視角」世界情報（已永久關閉，不會有資料）。\n'
                     '風夜相關操作與狀態請看「風夜操控台」。',
                font=(self.face, 12), justify='left')
        except Exception:
            pass
        top = self.version_label.master
        for w in top.winfo_children():
            if isinstance(w, tk.Label) and w.cget('text') == '全知情报':
                w.configure(text='風夜 · 全知情報')
        self.original_tabs = list(self.workspace.tabs())
        # 2026-10-18（0.2.18）：遊戲記錄顯示由全知情報來源承擔；本 Hub 收攏為單一
        # 「風夜操控台」——原「本局局勢／房間與來源記錄／風夜指令解讀」分頁移除。
        # 原版「玩家視角」頁面永久關閉（不會有資料），入口收起避免混淆。
        self._build_console()
        for tab in self.original_tabs:
            try:
                self.workspace.hide(tab)
            except Exception:
                pass
        self.workspace.select(self.console_page)
        self.render_view(self.view)
        threading.Thread(target=self._fetch_fengye, daemon=True, name='fengye-evidence-reader').start()
        self.root.after(250, self._tick_fengye)

    def fetch(self):
        """Never start the inherited player API/evidence polling path."""
        return

    def tick(self):
        return

    def confirm_player(self, clear=False):
        return

    def pick_history_archive(self):
        return

    def clear_history_review(self):
        return

    def _apply_review(self, bundle):
        raise ValueError('玩家視角的全知檔案來源已關閉')

    def _page(self, title, index=None):
        page = tk.Frame(self.workspace, bg=DAMASK)
        if index is None:
            self.workspace.add(page, text=title)
        else:
            self.workspace.insert(index, page, text=title)
        return page

    def _text(self, parent, height=5):
        frame = tk.Frame(parent, bg=WELL)
        frame.pack(fill='both', expand=True, padx=8, pady=6)
        w = tk.Text(frame, height=height, bg=WELL, fg=INK, wrap='word', relief='flat',
                    font=(self.face, 11), state='disabled', padx=10, pady=8)
        scroll = ttk.Scrollbar(frame, command=w.yview)
        scroll.pack(side='right', fill='y')
        w.configure(yscrollcommand=scroll.set)
        w.pack(side='left', fill='both', expand=True)
        return w

    @staticmethod
    def _set_text(widget, text):
        if widget.get('1.0', 'end-1c') == text:
            return
        pos = widget.yview()[0]
        widget.configure(state='normal')
        widget.delete('1.0', 'end')
        widget.insert('1.0', text)
        widget.configure(state='disabled')
        widget.yview_moveto(pos)

    def _box(self, parent, title):
        return tk.LabelFrame(parent, text=title, bg=DAMASK, fg=GOLD, font=(self.face, 12, 'bold'))

    def _build_console(self):
        self.console_page = self._page('風夜操控台', 1)
        self.console_state = tk.Label(self.console_page, text='未就緒', bg=PANEL, fg=GOLD_HI,
                                      font=(self.face, 15, 'bold'), anchor='w', padx=16, pady=12)
        self.console_state.pack(fill='x', padx=12, pady=8)
        self.control_book = ttk.Notebook(self.console_page)
        self.control_book.pack(fill='both', expand=True, padx=12, pady=(0, 10))
        self.room_control_page = tk.Frame(self.control_book, bg=DAMASK)
        self.chat_control_page = tk.Frame(self.control_book, bg=DAMASK)
        self.control_book.add(self.room_control_page, text='房間監控')
        self.control_book.add(self.chat_control_page, text='發言與回執')
        self._build_room_controls()
        tk.Label(self.chat_control_page, text='以風夜的名義發言', bg=DAMASK, fg=GOLD,
                 font=(self.face, 14, 'bold'), anchor='w').pack(fill='x', padx=18)
        self.chat_input = tk.Text(self.chat_control_page, height=4, wrap='word', bg=WELL, fg=INK,
                                  font=(self.face, 13), padx=12, pady=10)
        self.chat_input.pack(fill='x', padx=16, pady=8)
        buttons = tk.Frame(self.chat_control_page, bg=DAMASK)
        buttons.pack(fill='x', padx=16)
        self.chat_button = tk.Button(buttons, text='以風夜發言', bg=BG, fg=INK, command=self.send_chat)
        self.chat_button.pack(side='left')
        self.char_label = tk.Label(buttons, text='0 / 120 字 · GBK', bg=DAMASK, fg=MUTED)
        self.char_label.pack(side='left', padx=12)
        self.stop_button = tk.Button(buttons, text='風夜下線（正常退出）', bg='#ead4c6', fg=WARN, command=self.send_stop)
        self.stop_button.pack(side='right')
        self.chat_input.bind('<<Modified>>', self.input_changed)
        self.control_result = tk.Label(self.chat_control_page, text='每條請求僅執行一次；失敗或結果未知時不自動重發。',
                                      bg=DAMASK, fg=MUTED, anchor='w', justify='left', wraplength=1050)
        self.control_result.pack(fill='x', padx=18, pady=10)
        panes = tk.PanedWindow(self.chat_control_page, orient='horizontal', bg=DAMASK, sashwidth=9)
        panes.pack(fill='both', expand=True, padx=12, pady=(0, 12))
        chats = self._box(panes, '聊天記錄')
        receipts = self._box(panes, '控制回執')
        panes.add(chats, minsize=360, stretch='always')
        panes.add(receipts, minsize=360, stretch='always')
        self.console_chat = self._text(chats, 10)
        self.control_log = self._text(receipts, 10)
        self._build_local_controls()
        # 0.2.18：資料讀取等系統訊息集中在這一行（原「本局局勢」頁的提示已移除）。
        self.notice_label = tk.Label(self.console_page, text='', bg=DAMASK, fg=MUTED, anchor='w',
                                     justify='left', wraplength=1100)
        self.notice_label.pack(fill='x', padx=14, pady=(0, 8))

    def _build_room_controls(self):
        box = self._box(self.room_control_page, '大廳房間監控與連接')
        box.pack(fill='both', expand=True, padx=10, pady=10)
        bar = tk.Frame(box, bg=DAMASK)
        bar.pack(fill='x', padx=8, pady=6)
        self.room_line = tk.StringVar(value='多线3')
        primary = tk.Frame(box, bg=DAMASK)
        primary.pack(fill='x', padx=8, pady=(8, 0))
        self.room_once = tk.Button(primary, text='▶ 一鍵上場：登入大廳→更新房間→進入（自動報到→藏身）',
                                   bg='#d9ead3', fg='#1e3d2a', command=self.one_click_enter)
        self.room_once.pack(side='left')
        tk.Label(primary, text='完成後自動收束、響提示音；下面一排＝手動單步。',
                 bg=DAMASK, fg=MUTED).pack(side='left', padx=8)
        self.room_line_combo = ttk.Combobox(bar, textvariable=self.room_line, width=8,
                                          values=['多线2', '多线3'], state='readonly')
        self.room_line_combo.pack(side='left')
        self.room_start = tk.Button(bar, text='登入風夜大廳', bg=BG,
                                    command=lambda: self.room_action({'op': 'start', 'line': self.room_line.get()}))
        self.room_start.pack(side='left', padx=5)
        self.room_search = tk.Button(bar, text='更新房間', bg=BG,
                                     command=lambda: self.room_action({'op': 'search'}))
        self.room_search.pack(side='left')
        tk.Label(bar, text='進房暱稱', bg=DAMASK, fg=INK).pack(side='left', padx=(16, 5))
        self.room_nickname = tk.StringVar(value='待秋至')
        self.room_nick_combo = ttk.Combobox(bar, textvariable=self.room_nickname, width=14,
                                          values=['待秋至', '風夜', '小白'], state='normal')
        self.room_nick_combo.pack(side='left')
        self.room_join = tk.Button(bar, text='進入所選房間（自動：報到→藏身）', bg=BG, command=self.join_selected_room)
        self.room_join.pack(side='left', padx=5)
        self.room_leave = tk.Button(bar, text='退出房間', bg=BG,
                                    command=lambda: self.room_action({'op': 'leave'}))
        self.room_leave.pack(side='left')
        self.room_stop = tk.Button(bar, text='停止大廳', bg=BG,
                                   command=lambda: self.room_action({'op': 'stop'}))
        self.room_stop.pack(side='right', padx=5)
        flow = tk.Frame(box, bg=DAMASK)
        flow.pack(fill='x', padx=8, pady=(0, 4))
        tk.Label(flow, text='上場前準備', bg=DAMASK, fg=GOLD).pack(side='left', padx=(0, 8))
        self.room_register = tk.Button(flow, text='風夜報到', bg=BG,
                                       command=self.register_ghost)
        self.room_register.pack(side='left')
        self.room_d8 = tk.Button(flow, text='風夜藏身', bg='#ead4c6', fg=WARN,
                                 command=self.withdraw_ghost)
        self.room_d8.pack(side='left', padx=8)
        self.room_retry = tk.Button(flow, text='↻ 重新來過', bg='#ead4c6', fg=WARN,
                                    command=self.one_click_retry)
        self.room_retry.pack(side='left')
        self.room_flow_label = tk.Label(flow, bg=DAMASK, fg=MUTED)
        self.room_flow_label.pack(side='left', padx=8)
        lab = tk.Frame(box, bg=DAMASK)
        lab.pack(fill='x', padx=8, pady=(0, 4))
        tk.Label(lab, text='實驗室新流程：', bg=DAMASK, fg=GOLD).pack(side='left', padx=(0, 6))
        tk.Button(lab, text='一鍵武裝並進房（20補丁＋藏身＋代理待命）', bg='#ead4c6', fg=WARN,
                  command=self.lab_arm).pack(side='left')
        tk.Button(lab, text='實驗室收線', bg=BG, command=self.lab_stop).pack(side='left', padx=6)
        tk.Button(lab, text='強制退出風夜（強退）', bg='#ead4c6', fg=WARN, command=self.lab_force_quit).pack(side='left')
        tk.Button(lab, text='查看狀態', bg=BG, command=self.lab_status).pack(side='left')
        self.lab_label = tk.Label(box, bg=WELL, fg=INK, anchor='w', justify='left', wraplength=1100)
        self.lab_label.pack(fill='x', padx=8, pady=(0, 6))
        self.room_tree = self.tree(box, [('name', '房間', 160), ('host', '房主', 140),
                                       ('ip', '房間虛擬 IP', 160), ('count', '人數', 70)])
        self.room_tree.configure(height=4)
        self.room_tree.bind('<<TreeviewSelect>>', lambda _e: self.update_room_controls())
        self.room_status = tk.Label(box, bg=DAMASK, fg=MUTED, anchor='w', justify='left', wraplength=1100)
        self.room_status.pack(fill='x', padx=10, pady=4)
        self.room_channel = tk.Label(box, bg=WELL, fg=INK, anchor='w', justify='left', wraplength=1100)
        self.room_channel.pack(fill='x', padx=8, pady=(0, 6))
        self.room_receipt = tk.Label(box, text='按「▶ 一鍵上場」＝自動完成：登入大廳 → 更新房間 → 進入 → 報到 → 藏身（藏好後開局不會等風夜）。聽到「可以開始」再按開始；結束按「風夜下線」；出錯按「↻ 重新來過」。進房暱稱預設＝待秋至。',
                                     bg=DAMASK, fg=MUTED, anchor='w', wraplength=1100)
        self.room_receipt.pack(fill='x', padx=10, pady=(0, 6))

    def join_selected_room(self):
        ids = self.room_tree.selection()
        row = self.room_rows.get(ids[0]) if ids else None
        if row is None and len(self.room_rows) == 1:
            row = next(iter(self.room_rows.values()))  # 只有一個房間：未選取也可直接進入
        if row is None:
            self.room_receipt.configure(text='請先在房間列表點選一個房間列，再按「進入所選房間」。')
            return
        try:
            name = nickname(self.room_nickname.get())
        except ValueError as error:
            self.room_receipt.configure(text=str(error))
            return
        self.room_action({'op': 'join', 'room_id': row['id'], 'nickname': name, 'quick': True})

    def register_ghost(self):
        state = self.rooms.state
        if not (state.get('fresh') and state.get('connected')):
            return
        if not messagebox.askokcancel('風夜報到',
                                      '讓風夜在房間名單報到（只送一次）。\n'
                                      '名單會短暫出現風夜的名字；失敗不重試。確認執行？', parent=self.root):
            return
        self.room_action({'op': 'register'})

    def withdraw_ghost(self):
        state = self.rooms.state
        if not (state.get('fresh') and state.get('connected')):
            return
        if not messagebox.askokcancel('風夜藏身',
                                      '把風夜從名單中藏起來：這樣遊戲開局時不會等風夜，\n'
                                      '風夜可以一直暗中旁聽（名單會出現一行「風夜从游戏中退出了」）。\n'
                                      '請在遊戲按「開始」之前完成；只送一次、失敗不重試。確認執行？', parent=self.root):
            return
        self.room_action({'op': 'd8'})

    # ---- 風雲・本機控制（0.2.15）與實驗室一鍵（新流程） ----

    def _local_async(self, widget, label, func):
        def work():
            try:
                result = func()
            except Exception as error:
                result = {'status': 'error', 'error': '{}: {}'.format(type(error).__name__, error)}
            text = label + '\n' + json.dumps(result, ensure_ascii=False, indent=1)

            def show():
                widget.configure(text=text[:2200])
            self.root.after(0, show)

        widget.configure(text=label + '…執行中（請稍候）')
        threading.Thread(target=work, daemon=True, name='fengyun-local').start()

    def local_login(self):
        self.local_state_label.configure(text='⏳ 登入中……（幾秒後自動顯示結果）', fg=INK)

        def work():
            try:
                result = fengyun_local.login(line=self.local_line.get())
            except Exception as error:
                result = {'status': 'error', 'error': '{}: {}'.format(type(error).__name__, error)}

            def show():
                if result.get('status') == 'already_online':
                    self.local_state_label.configure(text=result.get('message') or '風雲已在線', fg='#2f6a4f')
                    detail = result.get('detail') or ''
                    rooms = result.get('rooms') or []
                    if rooms:
                        detail = (detail + '\n' if detail else '') + '房間列表：' + '、'.join(rooms)
                    self.local_status_label.configure(text=detail[:2200])
                else:
                    self.local_status_label.configure(
                        text=json.dumps(result, ensure_ascii=False, indent=1)[:2200])
                    self.root.after(6000, self.local_state_refresh)
                    self.root.after(15000, self.local_state_refresh)
            self.root.after(0, show)
        threading.Thread(target=work, daemon=True, name='fengyun-login').start()

    def local_exit(self):
        self._local_async(self.local_status_label, '退出遊戲（溫和）', fengyun_local.exit_soft)

    def local_kill(self):
        if not messagebox.askokcancel('強制關閉遊戲',
                                      'wineserver -k（prefix-sikarugir10）：會強制關閉本機遊戲，未保存進度會丟。確認？',
                                      parent=self.root):
            return
        self._local_async(self.local_status_label, '強制關閉遊戲', fengyun_local.force_kill)

    def local_status(self):
        self._local_async(self.local_status_label, '本機狀態', fengyun_local.status)

    def local_state_refresh(self):
        if getattr(self, '_local_state_busy', False):
            return
        self._local_state_busy = True

        def work():
            try:
                result = fengyun_local.live_status()
            except Exception as error:
                result = {'state': 'error', 'headline': '狀態讀取失敗', 'detail': str(error)}

            def show():
                self._local_state_busy = False
                self._render_local_state(result)
            self.root.after(0, show)
        threading.Thread(target=work, daemon=True, name='fengyun-state').start()

    def _render_local_state(self, result):
        colors = {'holding': '#2f6a4f', 'already_logged': WARN, 'aborted': WARN,
                  'logging_in': INK, 'not_started': MUTED, 'exited': MUTED, 'stopping': MUTED}
        state = result.get('state')
        self.local_state_label.configure(text=result.get('headline') or str(state or ''),
                                         fg=colors.get(state, INK))
        bits = []
        if result.get('detail'):
            bits.append(str(result['detail']))
        bits.append('進程：helper {} / SANPK {}'.format(result.get('helper_pid') or '—',
                                                       result.get('sanpk_pid') or '—'))
        if result.get('log'):
            bits.append('日誌：' + str(result['log']).rsplit('/', 1)[-1])
        self.local_status_label.configure(text='\n'.join(bits)[:2200])

    def local_slots_read(self):
        self._local_slot_async('讀取目前席位（wine 掃描，數秒）',
                               lambda: fengyun_local.setforce('read'))

    def local_slot_set(self, slot):
        self._local_slot_async('切換到席位 {}'.format(slot),
                               lambda: fengyun_local.setforce('switch', slot))

    def local_slot_restore(self):
        self._local_slot_async('還原上一個席位',
                               lambda: fengyun_local.setforce('restore'))

    def _local_slot_async(self, label, func):
        """本機席位操作：結果用與風夜相同的「名稱＋勢力」格式化顯示。"""
        def work():
            try:
                result = func()
            except Exception as error:
                result = {'status': 'error', 'error': '{}: {}'.format(type(error).__name__, error)}
            text = self._format_force(label, result)

            def show():
                self.local_slot_label.configure(text=text[:2200])
                self._update_slot_buttons(result)
            self.root.after(0, show)

        self.local_slot_label.configure(text=label + '…執行中（wine 掃描數秒）')
        threading.Thread(target=work, daemon=True, name='fengyun-force').start()

    def _fengye_slot_async(self, label, script):
        def work():
            try:
                result = lab_remote(self.source.sources.host, script, timeout=180)
            except Exception as error:
                result = {'rc': -1, 'stderr': str(error)}
            text = self._format_force(label, result)

            def show():
                self.fengye_slot_label.configure(text=text[:2200])
                self._update_slot_buttons(result)
            self.root.after(0, show)

        self.fengye_slot_label.configure(text=label + '…執行中（wine 掃描數秒）')
        threading.Thread(target=work, daemon=True, name='fengye-force').start()

    def _seat_table(self):
        """seat index -> (player name, faction name) from the current session snapshot."""
        view = getattr(self, 'view', None) or {}
        p = (view.get('p34') or {}) if isinstance(view, dict) else {}
        snapshots = p.get('snapshots') or {}
        block = snapshots.get('start') or snapshots.get('initial') or {}
        table = {}
        for row in block.get('rows') or []:
            try:
                seat = int(row.get('i'))
            except (TypeError, ValueError):
                continue
            name = row.get('name') or ('電腦' if row.get('state42') == 2 else '空席' if not row.get('id') else '未命名')
            table[seat] = (name, row.get('faction') or '—')
        return table

    def _update_slot_buttons(self, result):
        """0.2.19：兩排席位按鈕只放行「可切換的玩家席」；讀不到資料＝全部放行。"""
        payload = force_payload(result)
        slots = None
        if payload is not None:
            slots = set()
            for s in range(8):
                fid = (payload.get('slot_forces') or {}).get(str(s), '?')
                if fid in (-1, '-1', None, '?'):
                    continue
                slots.add(s)
        for table in (getattr(self, 'local_slot_buttons', None),
                      getattr(self, 'fengye_slot_buttons', None)):
            if not table:
                continue
            for s, btn in table.items():
                try:
                    btn.configure(state='normal' if (slots is None or s in slots) else 'disabled')
                except tk.TclError:
                    pass

    def _format_force(self, label, result):
        payload = force_payload(result)
        if payload is not None:
            forces = payload.get('slot_forces') or {}
            seats = self._seat_table()
            parts = []
            # 0.2.19（用戶指示）：電腦／空席（操控欄無值）直接隱去，只留可切換的玩家席。
            for s in range(8):
                fid = forces.get(str(s), '?')
                if fid in (-1, '-1', None, '?'):
                    continue
                name, faction = seats.get(s, (None, None))
                if name and faction:
                    parts.append('{}→{}・{}（id {}）'.format(s, name, faction, fid))
                elif faction:
                    parts.append('{}→{}（id {}）'.format(s, faction, fid))
                else:
                    parts.append('{}→（id {}）'.format(s, fid))
            extra = ''
            if payload.get('action') == 'written':
                extra = '（已切換 請求={} 現={}）'.format(payload.get('requested'), payload.get('now'))
            elif payload.get('action') == 'restored':
                extra = '（已還原到 {}）'.format(payload.get('restored_to'))
            header = '{}：席位＝{}{}'.format(label, payload.get('slot_now'), extra)
            if not parts:
                return header + '（沒有可切換的玩家席位——開局後自動出現；電腦／空席不列出）'
            note = '' if seats else '（尚未收到本局開局名單：只顯示編號；開局後自動帶出名稱）'
            return header + note + '\n勢力表:\n' + '\n'.join('  ' + x for x in parts)
        err = (result.get('stderr') or '').strip()
        lines = (result.get('stdout') or '').strip().splitlines()
        tail = '\n'.join(lines[-6:])
        return '{}（rc={}）\n{}{}'.format(label, result.get('rc'), tail,
                                         ('\n[stderr] ' + err[-300:]) if err else '')

    def fengye_slot_read(self):
        self._fengye_slot_async('讀取風夜席位',
                                'cd ~/sgi-protocol-lab-20260915/shadow && bash shadow_force.sh read')

    def fengye_slot_set(self, slot):
        self._fengye_slot_async('切換風夜到席位 {}'.format(slot),
                                'cd ~/sgi-protocol-lab-20260915/shadow && bash shadow_force.sh switch {}'.format(slot))

    def fengye_slot_restore(self):
        self._fengye_slot_async('還原風夜席位',
                                'cd ~/sgi-protocol-lab-20260915/shadow && bash shadow_force.sh restore')

    def _lab_async(self, label, script, timeout=360):
        def work():
            try:
                result = lab_remote(self.source.sources.host, script, timeout=timeout)
            except Exception as error:
                result = {'rc': -1, 'stderr': str(error)}
            lines = (result.get('stdout') or '').strip().splitlines()
            tail = '\n'.join(lines[-14:])
            err = (result.get('stderr') or '').strip()
            text = '{}（rc={}）\n{}{}'.format(label, result.get('rc'), tail,
                                              ('\n[stderr] ' + err[-400:]) if err else '')

            def show():
                self.lab_label.configure(text=text[:2600])
            self.root.after(0, show)

        self.lab_label.configure(text=label + '…執行中（可能需數分鐘）')
        threading.Thread(target=work, daemon=True, name='fengye-lab').start()

    def lab_arm(self):
        if not messagebox.askokcancel('一鍵武裝並進房（完整 SOP）',
                                      '流程：清場→登入→進房→20 補丁＋上行抑制→藏身摘席→'
                                      'C 代理待命→監看＋記錄器。\n'
                                      '會重啟風夜會話；房間需先由丁满建好並掛牌。確認執行？',
                                      parent=self.root):
            return
        self._lab_async('實驗室：武裝並進房',
                        'cd ~/sgi-protocol-lab-20260915/shadow && bash arm_now.sh')

    def lab_stop(self):
        self._lab_async('實驗室：收線',
                        'cd ~/sgi-protocol-lab-20260915/shadow && bash stop_shadow.sh',
                        timeout=90)

    def lab_force_quit(self):
        if not messagebox.askokcancel('強制退出風夜（強退）',
                                      '會停掉風夜的輔助鏈（keeper／監看／記錄器）＋停止會話＋wineserver -k。\n'
                                      '用於客戶端卡死／半死時；正常收線請用「實驗室收線」。確認執行？',
                                      parent=self.root):
            return
        self._lab_async('實驗室：強制退出（強退）',
                        'cd ~/sgi-protocol-lab-20260915/shadow && bash shadow_force_quit.sh',
                        timeout=120)

    def lab_status(self):
        script = (
            "cd ~/sgi-protocol-lab-20260915/shadow\n"
            "echo '[進程]'\n"
            "(pgrep -fl prefix-fengye-shadow | head -3 || echo 無進程)\n"
            "echo '[D8 藏身回執]'\n"
            "(xxd -l 16 shadow_d8_receipt.bin 2>/dev/null || echo 無回執)\n"
            "echo '[崩潰台帳]'\n"
            "ls -la \"$HOME/Library/Application Support/SGI-Wine/prefix-fengye-shadow/drive_c/sgi/run-3.5/3I/sgi-crash-context.bin\" 2>/dev/null | awk '{print $5, $6, $7, $8}'\n"
            "echo '[app.log 尾]'\n"
            "tail -2 logs/app.log 2>/dev/null\n"
        )
        self._lab_async('實驗室：狀態', script, timeout=60)

    def _build_local_controls(self):
        page = tk.Frame(self.control_book, bg=DAMASK)
        self.control_book.add(page, text='風雲・本機控制')
        box = self._box(page, '風雲帳號（本機）——直連登入與退出')
        box.pack(fill='x', padx=10, pady=10)
        bar = tk.Frame(box, bg=DAMASK)
        bar.pack(fill='x', padx=8, pady=6)
        self.local_line = tk.StringVar(value='多线3（备用）')
        ttk.Combobox(bar, textvariable=self.local_line, width=14,
                     values=['多线3（备用）', '多线2（主线）'], state='readonly').pack(side='left')
        tk.Button(bar, text='登入大廳→進遊戲', bg=BG, command=self.local_login).pack(side='left', padx=6)
        tk.Button(bar, text='退出遊戲（溫和）', bg=BG, command=self.local_exit).pack(side='left')
        tk.Button(bar, text='強制關閉遊戲', bg='#ead4c6', fg=WARN, command=self.local_kill).pack(side='left', padx=6)
        tk.Button(bar, text='重新整理狀態', bg=BG, command=self.local_state_refresh).pack(side='right')
        self.local_state_label = tk.Label(box, bg=WELL, fg=MUTED, anchor='w', justify='left',
                                          wraplength=1080, font=(self.face, 12, 'bold'))
        self.local_state_label.pack(fill='x', padx=8, pady=(6, 0))
        self.local_status_label = tk.Label(box, bg=WELL, fg=INK, anchor='w', justify='left', wraplength=1080)
        self.local_status_label.pack(fill='x', padx=8, pady=(0, 6))
        box2 = self._box(page, '勢力切換（開局後・實驗）——把本機客戶端的操控席位切到目標勢力')
        box2.pack(fill='x', padx=10, pady=(0, 10))
        bar2 = tk.Frame(box2, bg=DAMASK)
        bar2.pack(fill='x', padx=8, pady=6)
        tk.Button(bar2, text='讀取目前狀態', bg=BG, command=self.local_slots_read).pack(side='left')
        tk.Label(bar2, text='切換到：', bg=DAMASK, fg=INK).pack(side='left', padx=(12, 4))
        self.local_slot_buttons = {}
        for slot in range(8):
            btn = tk.Button(bar2, text=str(slot), bg=BG, width=3,
                            command=lambda value=slot: self.local_slot_set(value))
            btn.pack(side='left', padx=1)
            self.local_slot_buttons[slot] = btn
        tk.Button(bar2, text='還原上一個', bg=BG, command=self.local_slot_restore).pack(side='left', padx=10)
        self.local_slot_label = tk.Label(box2, bg=WELL, fg=INK, anchor='w', justify='left', wraplength=1080)
        self.local_slot_label.pack(fill='x', padx=8, pady=(0, 6))
        box3 = self._box(page, '風夜・遠端勢力切換（開局後・實驗）——切換風夜上身的目標勢力')
        box3.pack(fill='x', padx=10, pady=(0, 10))
        bar3 = tk.Frame(box3, bg=DAMASK)
        bar3.pack(fill='x', padx=8, pady=6)
        tk.Button(bar3, text='讀取風夜席位', bg=BG, command=self.fengye_slot_read).pack(side='left')
        tk.Label(bar3, text='切換到：', bg=DAMASK, fg=INK).pack(side='left', padx=(12, 4))
        self.fengye_slot_buttons = {}
        for slot in range(8):
            btn = tk.Button(bar3, text=str(slot), bg=BG, width=3,
                            command=lambda value=slot: self.fengye_slot_set(value))
            btn.pack(side='left', padx=1)
            self.fengye_slot_buttons[slot] = btn
        tk.Button(bar3, text='還原上一個', bg=BG, command=self.fengye_slot_restore).pack(side='left', padx=10)
        self.fengye_slot_label = tk.Label(box3, bg=WELL, fg=INK, anchor='w', justify='left', wraplength=1080)
        self.fengye_slot_label.pack(fill='x', padx=8, pady=(0, 6))
        tk.Label(page, text='註：本機控制只操作你這台的風雲客戶端（prefix-sikarugir10）；不讀玩家記憶體情報，'
                            '不影響風夜的隱身層。開局後未就緒（大廳/遊戲未開）時讀取會失敗，屬正常。',
                 bg=DAMASK, fg=MUTED, anchor='w', justify='left', wraplength=1080).pack(fill='x', padx=14, pady=(0, 10))
        self.local_state_refresh()
        self.fengye_slot_read()

    def room_action(self, payload):
        if self.room_busy or self.room_pending or self.room_uncertain or self.source.sources.source_file:
            self.room_receipt.configure(text='上一個操作尚未完成，或上次結果未知（一次性原則），本次未送出。')
            return
        try:
            self.jobs.put_nowait(('room', payload))
        except queue.Full:
            self.room_receipt.configure(text='正在讀取狀態，請稍候。')
            return
        self.room_busy = True
        self.room_receipt.configure(text='正在執行一次操作，等待實際回執…')
        self.update_room_controls()

    def update_room_controls(self):
        if not hasattr(self, 'room_start'):
            return
        state = self.rooms.state
        writable = not self.source.sources.source_file and not (self.room_busy or self.room_pending or self.room_uncertain)
        fresh = state.get('fresh') and (state.get('external') or
            isinstance(state.get('observed_at'), (int, float)) and 0 <= time.time()-state['observed_at'] <= 20)
        lobby = fresh and state.get('phase') == 'lobby' and not state.get('connected')
        q = state.get('room_query') or {}
        observed = q.get('observed_at')
        listed = isinstance(observed, (int, float)) and 0 <= time.time()-observed <= 60
        registered = bool(state.get('ghost_registered'))
        withdrawn = bool(state.get('ghost_withdrawn'))
        native_state = state.get('native_sync_state')
        modes = ((self.room_once, not (fresh and state.get('connected'))),
                 (self.room_start, not state.get('alive')),
                 (self.room_search, lobby or fresh and state.get('external')), (self.room_join, lobby and listed and (bool(self.room_tree.selection()) or len(self.room_rows) == 1)),
                 (self.room_leave, fresh and state.get('connected')), (self.room_stop, fresh and not state.get('external') and state.get('phase') != 'stopped'),
                 (self.room_register, fresh and state.get('connected') and not registered),
                 (self.room_d8, fresh and state.get('connected') and registered and not withdrawn
                  and native_state == 1))
        retrying = self.retry is not None
        for button, allowed in modes:
            button.configure(state='normal' if writable and allowed and not retrying else 'disabled')
        if hasattr(self, 'room_retry'):
            self.room_retry.configure(
                state='disabled' if self.source.sources.source_file else 'normal',
                text=('✕ 取消重做' if retrying else '↻ 重新來過'))
        self.room_stop.configure(text='風夜下線（結束旁聽）' if withdrawn else '風夜下線',
                                 bg='#ead4c6' if withdrawn else BG)
        if fresh and state.get('connected') and registered and not withdrawn:
            self.room_flow_label.configure(text='⚠️ 正在藏身（幾秒）——先別按「開始」', fg=WARN)
        elif fresh and state.get('connected') and withdrawn:
            d8r = state.get('d8') or {}
            if d8r.get('fast') or state.get('exit_seen_wall'):
                self.room_flow_label.configure(text='✅ 已藏好——現在可以按「開始」', fg='#2f6a4f')
            else:
                self.room_flow_label.configure(text='⚠️ 藏身訊號已送出（主機處理約 2 分鐘）——等名單上風夜消失再按「開始」', fg=WARN)
        else:
            self.room_flow_label.configure(text='報到：{}　藏身：{}'.format(
                '完成' if registered else '未完成',
                '完成' if withdrawn else '未完成'), fg=MUTED)
        self.room_line_combo.configure(state='readonly' if writable and not state.get('alive') else 'disabled')
        self.room_nick_combo.configure(state='normal' if writable and not state.get('connected') else 'disabled')

    def render_rooms(self):
        state = self.rooms.state
        q = state.get('room_query') or {}
        signature = json.dumps(q, ensure_ascii=False, sort_keys=True)
        if signature != self.room_signature:
            selected = self.room_tree.selection()
            selected_id = self.room_rows.get(selected[0], {}).get('id') if selected else None
            self.room_tree.delete(*self.room_tree.get_children())
            self.room_rows = {}
            for row in q.get('rooms') or []:
                iid = self.room_tree.insert('', 'end', values=(row.get('name', '—'), row.get('host', '—'),
                    row.get('virtual_ip', '—'), '{}/{}'.format(row.get('current', '—'), row.get('maximum', '—'))))
                self.room_rows[iid] = row
                if row.get('id') == selected_id:
                    self.room_tree.selection_set(iid)
            self.room_signature = signature
        labels = {'idle': '尚未登入', 'starting': '正在登入', 'lobby': '大廳監控中',
                  'joining': '正在進房', 'room': '已進入房間', 'stopped': '已停止',
                  'stale': '觀測過期', 'disconnected': '連接已斷開', 'external_lobby': '既有大廳中繼監控'}
        text = '{} · {} · 房間列表時間 {}{}'.format(labels.get(state.get('phase'), '未知'),
            state.get('line') or self.room_line.get(), wall_text(q.get('observed_at')),
            ' · 未收到房間回覆，不代表零房間' if q.get('status') == 'unconfirmed_empty' else '')
        if state.get('error'):
            text += ' · ' + str(state['error'])
        if q.get('error'):
            text += ' · ' + str(q['error'])
        self.room_status.configure(text=text)
        ch = state.get('channel') or {}
        register = state.get('register') or {}
        d8 = state.get('d8') or {}
        listen = ''
        if state.get('ghost_withdrawn') and isinstance(d8.get('wall'), (int, float)):
            listen = ' · 旁聽中 {}（收線上限 24 小時）'.format(dur_text(time.time()-d8['wall']))
        self.room_channel.configure(text='{}：風夜 ID {} → 房主 ID {}（{}）　遊戲端口 {}　中繼 A {}／B {}　進房：{}\n暱稱：{} · 已收 {} 包／已放行 {} · 報到：{} · 藏身：{}{}'.format(
            '連線中' if state.get('fresh') and state.get('connected') else '連線記錄（未確認在線）',
            ch.get('own_id', '—'), ch.get('host_id') or '—', ch.get('target_virtual_ip') or '—',
            ch.get('local_game_port', '—'), ch.get('a_port') or '—', ch.get('b_port') or '—',
            ('成功' if ch.get('open_rc') == 0 else ch.get('open_rc', '—')),
            state.get('nickname') or '—', state.get('received', 0), state.get('released', 0),
            ('完成' if state.get('ghost_registered') else '未完成'),
            ('完成' if state.get('ghost_withdrawn') else '未完成'),
            listen))
        result = state.get('last_result') or {}
        if self.room_pending and result.get('id') == self.room_pending:
            self.room_receipt.configure(text='{} · {} · rc={} · {}'.format(result.get('op'),
                result.get('status'), result.get('rc', '—'), result.get('detail') or result.get('error') or wall_text(result.get('wall'))))
            self.room_pending = None
            self.room_uncertain = result.get('status') == 'unknown'
            self._maybe_chain(result)
            self._notify_room_result(result)
            self._maybe_retry(result)
        self.update_room_controls()

    def _notify_room_result(self, result):
        """0.2.5：摘席流程關鍵節點的本機提示（遊戲視窗在前也看得到）。"""
        op, status = result.get('op'), result.get('status')
        room_state = self.rooms.state or {}
        d8r = room_state.get('d8') or {}
        ready = bool(d8r.get('fast') or room_state.get('exit_seen_wall'))
        if op == 'join' and status == 'completed':
            if room_state.get('ghost_withdrawn'):
                if ready:
                    notify_operator('風夜已藏好啦', '現在可以在遊戲按「開始」', sound='Glass')
                else:
                    notify_operator('藏身訊號已送出', '等風夜從遊戲名單消失（約 2 分鐘）再按「開始」', sound='Ping')
            else:
                notify_operator('風夜正在藏身', '幾秒就好——先別按「開始」', sound='Ping')
        elif op == 'join' and status == 'error':
            reason = str(result.get('error') or result.get('detail') or '請看 Hub 訊息')
            notify_operator('風夜藏身沒成功', reason[:90], sound='Basso')
        elif op == 'd8' and status == 'completed':
            if ready:
                notify_operator('風夜已藏好啦', '現在可以在遊戲按「開始」', sound='Glass')
            else:
                notify_operator('藏身訊號已送出', '等風夜從遊戲名單消失（約 2 分鐘）再按「開始」', sound='Ping')
        elif op == 'd8' and status == 'error':
            reason = str(result.get('error') or result.get('detail') or '請看 Hub 訊息')
            if '提前開始' not in reason and '開局等待' not in reason:
                notify_operator('風夜藏身沒成功', reason[:90], sound='Basso')

    def _maybe_chain(self, result):
        if result.get('status') != 'completed':
            return
        state = self.rooms.state
        op = result.get('op')
        if op == 'join' and state.get('connected') and not state.get('ghost_registered') and not state.get('ghost_withdrawn'):
            self.room_receipt.configure(text='自動準備：已進房，接著報到…')
            self.root.after(800, lambda: self._chain_fire('register'))
        elif op == 'register' and state.get('ghost_registered') and not state.get('ghost_withdrawn'):
            self.room_receipt.configure(text='自動準備：已報到，接著藏身…')
            self.root.after(800, lambda: self._chain_fire('d8'))

    def _chain_fire(self, op):
        self.room_action({'op': op})

    def _retry_label(self):
        return (self.retry or {}).get('label', '重新來過')

    def one_click_enter(self):
        """0.2.21 一鍵上場：登入(如需)→更新房間→進入(自動報到→藏身)；完成後流程自動收束。"""
        if self.source.sources.source_file:
            return
        if self.retry is not None or self.room_busy or self.room_pending or self.room_uncertain:
            self.room_receipt.configure(text='上一個操作還在進行（或結果未知）——請稍候，或按「↻ 重新來過」。')
            return
        state = self.rooms.state or {}
        if state.get('fresh') and state.get('connected'):
            self.room_receipt.configure(text='風夜已經在房間裡了（報到／藏身狀態見下方）；要重來請按「↻ 重新來過」。')
            return
        steps = []
        if not (state.get('fresh') and state.get('alive')):
            steps += ['start', 'wait_lobby']
        q = state.get('room_query') or {}
        observed = q.get('observed_at')
        fresh_rooms = (isinstance(observed, (int, float)) and 0 <= time.time() - observed <= 30
                       and (q.get('rooms') or []))
        if not fresh_rooms:
            steps.append('search')
        steps.append('wait_rooms')
        self.retry = {'steps': steps, 'deadline': time.monotonic() + 180, 'start_retries': 0,
                      'label': '一鍵上場'}
        self.retry_next()

    def one_click_retry(self):
        """失敗後一鍵收尾重來：退房→收線→重登→查房→進入（接手自動註冊→摘席）。"""
        if self.source.sources.source_file:
            return
        if self.retry is not None:
            self.retry = None
            self.room_receipt.configure(text='已取消「重新來過」；按鈕恢復正常。')
            return
        state = self.rooms.state
        steps = []
        if state.get('connected'):
            steps.append('leave')
        if state.get('alive') or state.get('fresh'):
            steps.append('stop')
        steps += ['wait_teardown', 'start', 'wait_lobby', 'search', 'wait_rooms']
        self.retry = {'steps': steps, 'deadline': time.monotonic() + 150, 'start_retries': 0,
                      'label': '重新來過'}
        self.room_receipt.configure(text='重新來過：開始收尾（若遊戲裡有等待畫面，請按掉取消）…')
        self.retry_next()

    def retry_next(self):
        """推進「一鍵重來」流程；每步只發一次操作，結果經 _maybe_retry 續行。"""
        tag = (self.retry or {}).get('label', '重新來過')
        if self.retry is None:
            return
        if time.monotonic() > self.retry.get('deadline', 0):
            self.retry = None
            self.room_receipt.configure(text=tag + '：超時中止；請確認狀態後再試。')
            return
        if self.room_uncertain:
            self.retry = None
            self.room_receipt.configure(text=tag + '：上次操作結果未知（不重複送），已中止。')
            return
        if self.room_busy or self.room_pending:
            return
        steps = self.retry['steps']
        if not steps:
            self.retry = None
            self.room_receipt.configure(text=tag + '：已進房並自動藏身——聽到「可以開始」提示音後再按「開始」。')
            return
        step = steps[0]
        state = self.rooms.state
        if step == 'leave':
            self.retry['steps'] = steps[1:]
            self.room_action({'op': 'leave'})
            self.room_receipt.configure(text=tag + '：退出房間…（若有等待畫面請按掉）')
        elif step == 'stop':
            self.retry['steps'] = steps[1:]
            self.room_action({'op': 'stop'})
            self.room_receipt.configure(text=tag + '：讓風夜下線…')
        elif step == 'wait_teardown':
            if not state.get('alive') and not state.get('fresh'):
                self.retry['steps'] = steps[1:]
                self.room_receipt.configure(text=tag + '：已下線，重新登入…')
                self.retry_next()
        elif step == 'start':
            self.retry['steps'] = steps[1:]
            self.room_action({'op': 'start', 'line': self.room_line.get()})
            self.room_receipt.configure(text=tag + '：登入風夜大廳…')
        elif step == 'wait_lobby':
            if state.get('fresh') and state.get('alive') and state.get('phase') == 'lobby':
                self.retry['steps'] = steps[1:]
                self.retry_next()
        elif step == 'search':
            self.retry['steps'] = steps[1:]
            self.room_action({'op': 'search'})
            self.room_receipt.configure(text=tag + '：查房中…')
        elif step == 'wait_rooms':
            if not (state.get('fresh') and state.get('phase') == 'lobby'):
                return
            q = state.get('room_query') or {}
            observed = q.get('observed_at')
            if not isinstance(observed, (int, float)) or time.time() - observed > 60:
                return
            rooms = q.get('rooms') or []
            self.retry['steps'] = []
            if len(rooms) == 1:
                row = rooms[0]
                try:
                    name = nickname(self.room_nickname.get())
                except ValueError as error:
                    self.retry = None
                    self.room_receipt.configure(text=str(error))
                    return
                self.room_action({'op': 'join', 'room_id': row['id'], 'nickname': name, 'quick': True})
                self.room_receipt.configure(text=tag + '：進入「{}」——等一下會通知「可以開始」…'.format(row.get('name') or row.get('id')))
            elif not rooms:
                self.retry = None
                self.room_receipt.configure(text=tag + '：查不到房間——請先在遊戲重開房間，再按「↻ 重新來過」。')
            else:
                self.retry = None
                self.room_receipt.configure(text=tag + '：有多個房間，請自行選房後按「進入所選房間」。')

    def _maybe_retry(self, result):
        if self.retry is None:
            return
        op, status = result.get('op'), result.get('status')
        if op == 'start':
            if status == 'started':
                self.retry_next()
            elif self.retry.get('start_retries', 0) < 2:
                self.retry['start_retries'] = self.retry.get('start_retries', 0) + 1
                self.retry['steps'].insert(0, 'start')
                self.room_receipt.configure(text='重新來過：登入暫未成功，4 秒後再試一次…')
                self.root.after(4000, self.retry_next)
            else:
                self.retry = None
                self.room_receipt.configure(text='重新來過：登入失敗——' + str(result.get('error') or status))
            return
        if op in ('leave', 'stop', 'search') and status in ('completed', 'error'):
            # 收尾步驟失敗不致命（可能已斷線／已停止）：繼續下一步。
            self.retry_next()
        elif op == 'join':
            if status == 'completed':
                self.retry_next()
            else:
                self.retry = None
                self.room_receipt.configure(text='重新來過：進房後的自動準備沒完成——' + str(
                    result.get('error') or result.get('detail') or status)[:90])

    # Keep the complete original polling/rendering path. Fengye has a separate
    # worker and queue, so an offline probe never replaces a valid world state.
    def _fetch_fengye(self):
        job = ('refresh', False)
        while not self.stop.is_set():
            op, payload = job
            try:
                if op == 'room':
                    result = self.rooms.call(payload)
                    self.messages.put(('room_result', result))
                if op == 'control':
                    try:
                        result = self.source.send(payload)
                    except Exception:
                        result = {'status': 'error', 'error': '控制結果未知；未重試'}
                    self.messages.put(('control', result))
            except Exception:
                self.messages.put(('error', '操作失敗；保留最後記錄'))
            # 2026-10-17：資料讀取與大廳心跳分開執行——資料通道失敗或超時時，
            # 房間監控（維持探針心跳）仍必須繼續，避免探針因心跳到期誤收尾。
            try:
                self.messages.put(('view', self.source.refresh(search=(op == 'refresh' and payload))))
            except Exception:
                self.messages.put(('error', '讀取失敗；保留最後記錄'))
            try:
                self.rooms.call({'op': 'status'})
                self.messages.put(('rooms', None))
            except Exception:
                pass
            self.messages.put(('idle', None))
            while not self.stop.is_set():
                try:
                    job = self.jobs.get(timeout=.25)
                    break
                except queue.Empty:
                    if self.stop.wait(.25):
                        return
                    # Poll only while this native window exists. 房間操作待回執時
                    # 加快輪詢（5s→1s），縮短一鍵流程的暴露窗口。
                    interval = 0.5 if (self.room_busy or self.room_pending) else 5
                    if time.monotonic() - getattr(self, '_last_poll', 0) >= interval:
                        job = ('refresh', False)
                        break
            self._last_poll = time.monotonic()

    def request_refresh(self, search=False):
        if self.stop.is_set():
            return
        try:
            self.jobs.put_nowait(('refresh', search))
        except queue.Full:
            pass

    def _tick_fengye(self):
        try:
            while True:
                kind, value = self.messages.get_nowait()
                if kind == 'view':
                    self.view = value
                    self.render_view(value)
                elif kind == 'control':
                    self.control_busy = False
                    if value.get('status') == 'sent':
                        self.pending_id = value.get('id')
                        self.control_result.configure(text='請求已寫入 · {} · 等待探針回執，尚未確認執行'.format(self.pending_id))
                        if value.get('op') == 'chat':
                            self.chat_input.delete('1.0', 'end')
                    else:
                        self.pending_uncertain = True
                        self.control_result.configure(text='{} · 未自動重試；關閉或重新核實前不再送出。'.format(value.get('error') or value.get('status')))
                elif kind == 'room_result':
                    self.room_busy = False
                    if value.get('status') == 'sent':
                        self.room_pending = value.get('id')
                        self.room_receipt.configure(text='請求已送出，等待探針執行回執：' + str(self.room_pending))
                    else:
                        self.room_uncertain = value.get('status') == 'unknown'
                        self.room_receipt.configure(text=value.get('error') or ('大廳會話已啟動' if value.get('status') == 'started' else str(value.get('status'))))
                        self._maybe_retry(value)
                    self.render_rooms()
                elif kind == 'rooms':
                    self.render_rooms()
                elif kind == 'error':
                    self.notice_label.configure(text=str(value))
                elif kind == 'idle':
                    self.reload_btn.configure(state='normal')
        except queue.Empty:
            pass
        except Exception as error:
            self.render_error = str(error)
            print('fengye-render', error, flush=True)
        self.update_control_state()
        self.update_room_controls()
        if self.retry is not None:
            try:
                self.retry_next()
            except Exception:
                self.retry = None
        self._local_state_n = getattr(self, '_local_state_n', 0) + 1
        if self._local_state_n % 40 == 0:
            try:
                self.local_state_refresh()
            except Exception:
                pass
        if not self.stop.is_set():
            self.root.after(250, self._tick_fengye)

    def render_view(self, view):
        p = view.get('p34') or {}
        session = view.get('session') or {}
        signature = json.dumps({k: view.get(k) for k in ('p34', 'host', 'members', 'events', 'directory', 'room_query', 'chain', 'source', 'ghost', 'collector')}, ensure_ascii=False, sort_keys=True)
        if signature != self.render_signature:
            chats = (p.get('chat') or {}).get('messages') or []
            chat_text = '\n\n'.join('{}　{}\n{}'.format(wall_text(m.get('wall')),
                m.get('sender_name') or '—', str(m.get('text') or '—')) for m in chats) or (
                '本局尚無聊天記錄。' if session else '目前沒有可核實的聊天記錄。')
            self._set_text(self.console_chat, chat_text)
            events = (p.get('control') or {}).get('events') or []
            self._set_text(self.control_log, '\n\n'.join('{}　{}\n{}{}{}'.format(
                wall_text(e.get('wall')), e.get('ev') or '', e.get('text') or '',
                ' · rc=' + str(e['rc']) if e.get('rc') is not None else '',
                ' · ' + str(e['reason']) if e.get('reason') else '') for e in reversed(events)) or '尚無控制回執。')
            self.render_signature = signature
        control = p.get('control') or {}
        last = control.get('last_result') or {}
        if self.pending_id and last.get('id') == self.pending_id:
            self.control_result.configure(text='已收到執行回執 · {} · rc={} · {}'.format(last.get('op'), last.get('rc'), wall_text(last.get('wall'))))
            self.pending_id = None
        if self.pending_run and p.get('run_name') != self.pending_run:
            self.pending_id = None
            self.pending_uncertain = False
            self.control_result.configure(text='已切換 run；先前請求不會重發。')
            self.pending_run = None
        self.update_control_state()

    def input_changed(self, _=None):
        if not self.chat_input.edit_modified():
            return
        self.chat_input.edit_modified(False)
        text = self.chat_input.get('1.0', 'end-1c')
        try:
            text.encode('gbk')
            valid = len(text) <= 120
            suffix = 'GBK' if valid else '超過字數上限'
        except UnicodeEncodeError:
            valid = False
            suffix = '含 GBK 不支援字元'
        self.char_label.configure(text='{} / 120 字 · {}'.format(len(text), suffix), fg=MUTED if valid else WARN)
        self.update_control_state()

    def update_control_state(self):
        if not hasattr(self, 'console_state'):
            return
        ready = control_ready(self.view)
        p = self.view.get('p34') or {}
        pending = self.pending_id or (p.get('control') or {}).get('pending')
        enabled = ready and not self.control_busy and not pending and not self.pending_uncertain and time.monotonic() >= self.cooldown
        lobby = self.rooms.state
        if self.source.sources.source_file:
            headline = '本地回放 · 大廳與控制已停用'
        elif lobby.get('fresh'):
            if lobby.get('connected') and not lobby.get('ghost_withdrawn'):
                if lobby.get('ghost_registered'):
                    headline = '⚠ 風夜正在藏身（幾秒）——先別按「開始」'
                else:
                    headline = '⚠ 風夜已進房，正在報到→藏身——先別按「開始」'
            elif lobby.get('connected') and lobby.get('ghost_withdrawn'):
                d8r = lobby.get('d8') or {}
                if d8r.get('fast') or lobby.get('exit_seen_wall'):
                    headline = '✅ 風夜已藏好·旁聽中——可以按「開始」'
                else:
                    headline = '⚠ 藏身訊號已送出——等風夜從遊戲名單消失再按「開始」（約 2 分鐘）'
            else:
                headline = '大廳房間監控 · ' + ('既有中繼' if lobby.get('external') else '風夜獨立會話')
        else:
            headline = '風夜操控台 · 選線路登入大廳；查房後選暱稱進入'
        self.console_state.configure(text=headline)
        try:
            validate_control({'op': 'chat', 'text': self.chat_input.get('1.0', 'end-1c')})
            text_valid = True
        except ValueError:
            text_valid = False
        self.chat_button.configure(state='normal' if enabled and text_valid else 'disabled')
        self.stop_button.configure(state='normal' if enabled else 'disabled')

    def send_control(self, payload):
        if not control_ready(self.view) or self.control_busy or self.pending_id or self.pending_uncertain or (self.view.get('p34') or {}).get('control', {}).get('pending') or time.monotonic() < self.cooldown:
            return
        try:
            payload = validate_control(payload)
        except ValueError as error:
            messagebox.showerror('無法送出', str(error), parent=self.root)
            return
        try:
            self.jobs.put_nowait(('control', payload))
        except queue.Full:
            self.control_result.configure(text='正在讀取狀態；本次未送出，請稍候。')
            return
        self.control_busy = True
        self.pending_run = (self.view.get('p34') or {}).get('run_name')
        self.cooldown = time.monotonic() + 2
        self.control_result.configure(text='送出單次請求中；不會自動重試。')
        self.update_control_state()

    def send_chat(self):
        self.send_control({'op': 'chat', 'text': self.chat_input.get('1.0', 'end-1c')})

    def send_stop(self):
        if not control_ready(self.view) or self.control_busy:
            return
        if messagebox.askokcancel('風夜下線（正常退出）',
                                  '讓風夜下線並結束旁聽？\n'
                                  '下線後要再旁聽需重新登入。', parent=self.root):
            self.send_control({'op': 'stop'})

