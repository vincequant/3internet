"""Fengye-only source adapter. No HTTP listener and no memory collector."""
import importlib.util
import json
import struct
import time
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('fengye_backend', ROOT / 'backend/server.py')
backend = importlib.util.module_from_spec(spec)
spec.loader.exec_module(backend)

CMD_NAMES = {0: '玩家通知', 3: '初始快照', 6: '劇本請求', 7: '開局快照',
             10: '開局指令', 11: '取消', 18: '遊戲數據', 26: '逐輪通知'}


TROOP_CN = {0: '步兵', 1: '骑兵', 2: '弓兵'}
LABELED_CLASSES = {'CSanInetUnitNetCmdMove': '部隊移動', 'CSanInetPhaseEndCmd': '階段結束'}


def _city_names():
    try:
        data = json.loads((ROOT / 'backend/city_id_table.json').read_text(encoding='utf-8'))
        return {int(k): v['name'] for k, v in (data.get('cities') or {}).items()
                if isinstance(v, dict) and isinstance(v.get('name'), str)}
    except (OSError, ValueError, AttributeError, KeyError):
        return {}


CITY_NAMES = _city_names()


def _class_name(raw):
    try:
        size = struct.unpack_from('<H', raw, 4)[0]
        if not 0 < size < 64:
            return None
        return raw[6:6 + size].decode('ascii')
    except (struct.error, UnicodeDecodeError):
        return None


def _move_fields(raw):
    """kind17 衍生欄位（2026-10-16 佈局文檔：位移對位已驗、座標為候選語義）。"""
    try:
        size = struct.unpack_from('<H', raw, 4)[0]
        body = raw[6 + size:]
        if len(body) != 35:
            return None
        return struct.unpack_from('<II', body, 15)
    except struct.error:
        return None


def _value_display(row):
    xy = row.get('target_xy_raw')
    value = row.get('value_raw')
    if isinstance(xy, (list, tuple)) and len(xy) >= 2:
        city = CITY_NAMES.get(value) if isinstance(value, int) else None
        return ('%s (%d, %d)' % (city, xy[0], xy[1])) if city else ('(%d, %d)' % (xy[0], xy[1]))
    if 'troop_kind_raw' in row:
        troop = TROOP_CN.get(row.get('troop_kind_raw'), str(row.get('troop_kind_raw')))
        return '%s 武将%s 兵%s/米%s' % (troop, row.get('general_ids_raw'),
                                        row.get('soldiers_raw'), row.get('rice_raw'))
    if 'target_raw' in row:
        return '對象#%s' % row.get('target_raw')
    if value is not None:
        return str(value)
    return None


def decoded_commands(view):
    """Use the original Hub decoder on complete, hash-checked Fengye records.

    0.2.14 顯示層補強（只加呈現欄位；原文、SHA、解碼欄位全部保留）：
    發送者↔名字/勢力、類別名標註（部隊移動/階段結束）、建造城池名＋座標、出征兵種/兵力。
    """
    from native_command_evidence import decode
    p = view.get('p34') or {}
    names = dict(p.get('member_names') or view.get('member_names') or {})
    snapshot = ((p.get('snapshots') or {}).get('start')
                or (p.get('snapshots') or {}).get('initial') or {})
    kingdoms = {}
    for seat in snapshot.get('rows') or []:
        seat_id = str(seat.get('id') or '')
        if seat_id and seat.get('name'):
            names.setdefault(seat_id, seat.get('name'))
        if seat_id and seat.get('faction'):
            kingdoms[seat_id] = seat.get('faction')
    rows = []
    for batch in (p.get('sync') or {}).get('nonempty') or []:
        for record in batch.get('records') or []:
            sender = record.get('sender')
            row = {'wall': batch.get('wall'), 'round': batch.get('round'),
                   'sender': sender, 'run_name': p.get('run_name'),
                   'source': 'fengye_received_sync', 'server_result_verified': False}
            raw = None
            try:
                raw = bytes.fromhex(record.get('raw') or '')
                sha = record.get('sha8') or ''
                if len(raw) != record.get('len'):
                    raise ValueError('封包不完整，保留未知')
                if not 8 <= len(sha) <= 64 or not hashlib.sha256(raw).hexdigest().startswith(sha):
                    raise ValueError('封包 SHA 未核對，保留未知')
                row.update(decode(raw))
            except (ValueError, TypeError, UnicodeError) as error:
                row['error'] = str(error)
            name = names.get(str(sender))
            kingdom = kingdoms.get(str(sender))
            row['sender_name'] = name
            row['kingdom'] = kingdom
            row['who_display'] = ('%s（%s）' % (name, kingdom)) if (name and kingdom) else (name or sender)
            if raw is not None and row.get('error') is not None:
                class_name = _class_name(raw)
                if class_name:
                    row['class'] = class_name
                    label = LABELED_CLASSES.get(class_name)
                    if label:
                        row['class_cn'] = label
                        if class_name == 'CSanInetUnitNetCmdMove':
                            xy = _move_fields(raw)
                            if xy:
                                row['move_xy'] = list(xy)
                                row['value_display'] = '(%d, %d)' % xy
                                row['status_text'] = '移動欄位對位已驗；座標為候選語義；結算未確認'
                            else:
                                row['status_text'] = '原文已標註；結算未確認'
                        else:
                            row['status_text'] = '原文已標註；結算未確認'
                    else:
                        row['status_text'] = '未編目類別；原文已保留'
            if row.get('error') is None and 'action' in row:
                row['value_display'] = _value_display(row)
            rows.append(row)
    return rows


def class_name(raw):
    try:
        data = bytes.fromhex(str(raw or '')[:240])
    except ValueError:
        return None
    start = data.find(b'CSanInet')
    if start < 0:
        return None
    end = start
    while end < len(data) and 32 <= data[end] < 127:
        end += 1
    return data[start:end].decode('ascii') or None


def feed_items(view):
    """Show each real item once; zero/unknown is never filled with demo data."""
    p = view.get('p34') or {}
    items = []
    for f in p.get('frames') or []:
        cmd = f.get('cmd')
        name = CMD_NAMES.get(cmd, 'cmd' + str(cmd)) if isinstance(cmd, int) else f.get('cls') or '未知'
        items.append({'wall': f.get('wall'), 'kind': 'frame', 'label': name,
                      'detail': 'type {} · {} B · {}'.format(f.get('type', '—'), f.get('len', '—'), f.get('sha8', ''))})
    for b in (p.get('sync') or {}).get('nonempty') or []:
        for r in b.get('records') or []:
            items.append({'wall': b.get('wall'), 'kind': 'data', 'label': class_name(r.get('raw')) or '遊戲數據',
                          'detail': '第 {} 輪 · sender={} · {} B · {}\n{}'.format(
                              b.get('round', '—'), r.get('sender', '—'), r.get('len', '—'),
                              r.get('sha8', ''), str(r.get('raw') or '')[:240])})
    for e in (p.get('control') or {}).get('events') or []:
        items.append({'wall': e.get('wall'), 'kind': 'control', 'label': e.get('ev') or '控制事件',
                      'detail': '{}{}{}'.format(e.get('text') or '',
                                               ' · rc=' + str(e['rc']) if e.get('rc') is not None else '',
                                               ' · ' + str(e['reason']) if e.get('reason') else '')})
    for m in (p.get('chat') or {}).get('messages') or []:
        items.append({'wall': m.get('wall'), 'kind': 'chat', 'label': m.get('text') or '—', 'detail': '風夜收到的對話'})
    return sorted(items, key=lambda x: x.get('wall') or 0, reverse=True)


def control_ready(view, now=None):
    now = time.time() if now is None else now
    transport = view.get('transport') or {}
    checked = transport.get('checked_at')
    return bool((view.get('p34') or {}).get('live_probe') and transport.get('status') == 'online'
                and isinstance(checked, (int, float)) and 0 <= now - checked <= 20)


def mode_text(view, now=None):
    t = view.get('transport') or {}
    session = view.get('session') or {}
    if t.get('status') == 'file':
        return '回放 · 本地記錄'
    if t.get('status') == 'offline':
        return '離線 · 無法讀取採集端'
    if session:
        # 2026-10-17：只顯示當前加入的那局會話（不再回放其他 run）。
        labels = {'lobby': '大廳中', 'joining': '進房中', 'room': '已在房間',
                  'starting': '啟動中', 'disconnected': '連線斷開',
                  'stopped': '已停止', 'stale': '停止回應'}
        phase = str(session.get('phase') or 'unknown')
        label = labels.get(phase, phase)
        if session.get('fresh'):
            return '本局會話 · ' + label
        return '本局會話 · ' + ('已停止' if not session.get('alive') or phase == 'stopped' else '停止回應')
    if control_ready(view, now):
        return '在線 · 風夜探針'
    return '未就緒 · 尚無本局資料'


def validate_control(payload):
    if not isinstance(payload, dict) or payload.get('op') not in ('chat', 'stop'):
        raise ValueError('未知操作')
    if payload['op'] == 'stop':
        return {'op': 'stop'}
    text = payload.get('text')
    if not isinstance(text, str) or not text.strip() or not 0 < len(text) <= 120:
        raise ValueError('發言需為 1–120 字')
    try:
        text.encode('gbk')
    except UnicodeEncodeError:
        raise ValueError('文字含 GBK 無法表示的字元') from None
    return {'op': 'chat', 'text': text}


class FengyeSource:
    def __init__(self, data_dir=None, replay=None, sources=None):
        self.sources = sources or backend.Sources(data_dir=data_dir or ROOT / 'data', source_file=replay)
        self.view = self.sources.view()

    def refresh(self, search=False):
        self.view = self.sources.refresh(search=search)
        return self.view

    def send(self, payload):
        payload = validate_control(payload)
        if self.sources.source_file or not control_ready(self.view):
            return {'status': 'error', 'error': 'probe_not_running：回放或未就緒時不能操控'}
        # Existing backend keeps its two-second limiter and remote once-only
        # writer. No retries, including an ambiguous SSH failure.
        return self.sources.control(payload)
