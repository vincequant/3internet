"""The complete native OmniWindow with an additional Fengye console."""
import json
import queue
import subprocess
import sys
import time
import threading
import tkinter as tk
from datetime import datetime
from tkinter import ttk, messagebox

from omni_window import OmniWindow, DAMASK, PANEL, WELL, INK, GOLD, GOLD_HI, MUTED, WARN, BG
from fengye_source import FengyeSource, control_ready, validate_control
from room_client import RoomClient
from backend.room_protocol import nickname
from backend import fengyun_local
from backend.lab_remote import lab_remote
from player_text import (plain_error, room_summary, room_result, room_fresh,
                         operation_result, local_state, control_event,
                         force_choices, force_summary, lab_result)

# A separate player-facing palette; the inherited world renderer is untouched.
LEGACY_COLORS = {DAMASK: '#f3f6fa', PANEL: '#16343d', WELL: '#ffffff',
                 INK: '#203440', GOLD: '#286a72', GOLD_HI: '#f3fafb',
                 MUTED: '#657985', WARN: '#a13b42', BG: '#e6eef2'}
DAMASK, PANEL, WELL = '#f3f6fa', '#16343d', '#ffffff'
INK, GOLD, GOLD_HI = '#203440', '#286a72', '#f3fafb'
MUTED, WARN, BG = '#657985', '#a13b42', '#e6eef2' 


def wall_text(value):
    if not isinstance(value, (int, float)):
        return '—'
    try:
        return datetime.fromtimestamp(value).strftime('%m-%d %H:%M:%S')
    except (OSError, ValueError, OverflowError):
        return '—'


def dur_text(value):
    """Human duration for long-run listening windows; never negative."""
    try:
        seconds = int(max(0, float(value)))
    except (TypeError, ValueError):
        return '—'
    hours, rem = divmod(seconds, 3600)
    minutes = rem // 60
    if hours:
        return '{}時{:02d}分'.format(hours, minutes)
    if minutes:
        return '{}分'.format(minutes)
    return '{}秒'.format(rem)


def force_payload(result):
    """席位助手 JSON（{'slot_forces': ...}）：直接給的 dict 或 stdout 尾行的 JSON。"""
    if isinstance(result, dict) and 'slot_forces' in result:
        return result
    raw = (result.get('stdout') or '').strip()
    for line in reversed(raw.splitlines()):
        try:
            payload = json.loads(line)
        except ValueError:
            continue
        if isinstance(payload, dict) and 'slot_forces' in payload:
            return payload
    return None


def notify_operator(title, message, sound='Glass'):
    """摘席流程的本地提示：聲音＋系統通知。

    讓操作者在遊戲視窗在前時也能察覺「先勿按開始／可以按開始」。
    只在本機發出（macOS osascript/afplay）；不觸碰遊戲、會話或網路。
    """
    try:
        if sys.platform == 'darwin':
            safe_title = str(title).replace('"', ' ')
            safe_message = str(message).replace('"', ' ')
            subprocess.Popen(
                ['osascript', '-e',
                 'display notification "{}" with title "{}"'.format(safe_message, safe_title)],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            subprocess.Popen(
                ['afplay', '/System/Library/Sounds/{}.aiff'.format(sound)],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


class FengyeWindow(OmniWindow):
    def __init__(self, root, source=None):
        self.source = source or FengyeSource()
        self.messages = queue.Queue()
        self.jobs = queue.Queue(maxsize=1)
        self.view = self.source.view
        self.control_busy = False
        self.cooldown = 0
        self.pending_id = None
        self.pending_run = None
        self.pending_uncertain = False
        self.render_signature = None
        self.render_error = None
        self.rooms = RoomClient(host=self.source.sources.host, replay=bool(self.source.sources.source_file))
        self.room_busy = False
        self.room_pending = None
        self.room_uncertain = False
        self.room_rows = {}
        self.room_signature = None
        self.retry = None
        super().__init__(root)
        root.title('風夜情報台')
        root.minsize(1120, 700)
        self.version_label.configure(text='版本 0.2.23')
        self.identity_label.master.pack_forget()
        self.status.configure(text='掌握風夜狀態，再開始遊戲', fg='#d7ebea')
        self.coverage.configure(text='只顯示已確認的情況；尚未讀到的資料會清楚標示。')
        # 2026-10-17：玩家視角頁面（永久停用）不再顯示會誤導的等待文案。
        try:
            self.resources.configure(
                text='本頁是原版「玩家視角」世界情報（已永久關閉，不會有資料）。\n'
                     '風夜相關操作與狀態請看「風夜操控台」。',
                font=(self.face, 12), justify='left')
        except Exception:
            pass
        top = self.version_label.master
        for w in top.winfo_children():
            if isinstance(w, tk.Label) and w.cget('text') == '全知情报':
                w.configure(text='風夜情報台')
        self.original_tabs = list(self.workspace.tabs())
        # 2026-10-18（0.2.18）：遊戲記錄顯示由全知情報來源承擔；本 Hub 收攏為單一
        # 「風夜操控台」——原「本局局勢／房間與來源記錄／風夜指令解讀」分頁移除。
        # 原版「玩家視角」頁面永久關閉（不會有資料），入口收起避免混淆。
        self._build_console()
        for tab in self.original_tabs:
            try:
                self.workspace.hide(tab)
            except Exception:
                pass
        self.workspace.select(self.console_page)
        self._style_player_shell()
        self.render_view(self.view)
        threading.Thread(target=self._fetch_fengye, daemon=True, name='fengye-evidence-reader').start()
        self.root.after(250, self._tick_fengye)

    def fetch(self):
        """Never start the inherited player API/evidence polling path."""
        return

    def tick(self):
        return

    def confirm_player(self, clear=False):
        return

    def pick_history_archive(self):
        return

    def clear_history_review(self):
        return

    def _apply_review(self, bundle):
        raise ValueError('玩家視角的全知檔案來源已關閉')

    def _page(self, title, index=None):
        page = tk.Frame(self.workspace, bg=DAMASK)
        if index is None:
            self.workspace.add(page, text=title)
        else:
            self.workspace.insert(index, page, text=title)
        return page

    def _text(self, parent, height=5):
        frame = tk.Frame(parent, bg=WELL)
        frame.pack(fill='both', expand=True, padx=8, pady=6)
        w = tk.Text(frame, height=height, bg=WELL, fg=INK, wrap='word', relief='flat',
                    font=(self.face, 11), state='disabled', padx=10, pady=8)
        scroll = ttk.Scrollbar(frame, command=w.yview)
        scroll.pack(side='right', fill='y')
        w.configure(yscrollcommand=scroll.set)
        w.pack(side='left', fill='both', expand=True)
        return w

    @staticmethod
    def _set_text(widget, text):
        if widget.get('1.0', 'end-1c') == text:
            return
        pos = widget.yview()[0]
        widget.configure(state='normal')
        widget.delete('1.0', 'end')
        widget.insert('1.0', text)
        widget.configure(state='disabled')
        widget.yview_moveto(pos)

    def _box(self, parent, title):
        return tk.LabelFrame(parent, text=title, bg=DAMASK, fg=GOLD,
                             font=(self.face, 12, 'bold'), relief='flat', bd=0,
                             padx=8, pady=8)

    def _style_player_shell(self):
        self.root.configure(bg=DAMASK)
        def restyle(widget):
            options = {}
            for key in ('background', 'foreground'):
                try:
                    value = str(widget.cget(key))
                    if value in LEGACY_COLORS:
                        options[key] = LEGACY_COLORS[value]
                except tk.TclError:
                    pass
            if isinstance(widget, tk.Button):
                options.update(relief='flat', bd=0, padx=12, pady=7,
                               font=(self.face, 11), cursor='hand2')
            if options:
                widget.configure(**options)
            for child in widget.winfo_children():
                restyle(child)
        restyle(self.root)
        style = ttk.Style(self.root)
        style.configure('TNotebook', background=DAMASK, borderwidth=0)
        style.configure('FengyeOuter.TNotebook', background=DAMASK, borderwidth=0)
        style.layout('FengyeOuter.TNotebook.Tab', [])
        self.workspace.configure(style='FengyeOuter.TNotebook')
        style.configure('TNotebook.Tab', padding=(18, 10), font=(self.face, 11),
                        background=BG, foreground=MUTED)
        style.map('TNotebook.Tab', background=[('selected', WELL)],
                  foreground=[('selected', GOLD)])
        style.configure('Treeview', background=WELL, fieldbackground=WELL,
                        foreground=INK, rowheight=36, borderwidth=0,
                        font=(self.face, 11))
        style.configure('Treeview.Heading', background=BG, foreground=GOLD,
                        font=(self.face, 11, 'bold'), relief='flat')
        style.map('Treeview', background=[('selected', '#d9eceb')],
                  foreground=[('selected', INK)])
        self.reload_btn.configure(text='更新資料', command=self.request_refresh)
        self.console_state.configure(wraplength=1040, justify='left')
        if self.source.sources.source_file:
            def disable(widget):
                if isinstance(widget, tk.Button):
                    widget.configure(state='disabled')
                for child in widget.winfo_children():
                    disable(child)
            disable(self.console_page)

    def _build_console(self):
        self.console_page = self._page('風夜情報台', 1)
        self.console_state = tk.Label(self.console_page, text='未就緒', bg=PANEL, fg=GOLD_HI,
                                      font=(self.face, 15, 'bold'), anchor='w', padx=16, pady=12)
        self.console_state.pack(fill='x', padx=12, pady=8)
        self.control_book = ttk.Notebook(self.console_page)
        self.control_book.pack(fill='both', expand=True, padx=12, pady=(0, 10))
        self.room_control_page = tk.Frame(self.control_book, bg=DAMASK)
        self.chat_control_page = tk.Frame(self.control_book, bg=DAMASK)
        self.control_book.add(self.room_control_page, text='進房與準備')
        self.control_book.add(self.chat_control_page, text='聊天與操作結果')
        self._build_room_controls()
        tk.Label(self.chat_control_page, text='以風夜的名義發言', bg=DAMASK, fg=GOLD,
                 font=(self.face, 14, 'bold'), anchor='w').pack(fill='x', padx=18)
        self.chat_input = tk.Text(self.chat_control_page, height=4, wrap='word', bg=WELL, fg=INK,
                                  font=(self.face, 13), padx=12, pady=10)
        self.chat_input.pack(fill='x', padx=16, pady=8)
        buttons = tk.Frame(self.chat_control_page, bg=DAMASK)
        buttons.pack(fill='x', padx=16)
        self.chat_button = tk.Button(buttons, text='以風夜發言', bg=BG, fg=INK, command=self.send_chat)
        self.chat_button.pack(side='left')
        self.char_label = tk.Label(buttons, text='0 / 120 字', bg=DAMASK, fg=MUTED)
        self.char_label.pack(side='left', padx=12)
        self.stop_button = tk.Button(buttons, text='風夜下線（正常退出）', bg='#ead4c6', fg=WARN, command=self.send_stop)
        self.stop_button.pack(side='right')
        self.chat_input.bind('<<Modified>>', self.input_changed)
        self.control_result = tk.Label(self.chat_control_page, text='每按一次只送出一次；還沒看到結果時，請先更新狀態。',
                                      bg=DAMASK, fg=MUTED, anchor='w', justify='left', wraplength=1050)
        self.control_result.pack(fill='x', padx=18, pady=10)
        panes = tk.PanedWindow(self.chat_control_page, orient='horizontal', bg=DAMASK, sashwidth=9)
        panes.pack(fill='both', expand=True, padx=12, pady=(0, 12))
        chats = self._box(panes, '聊天記錄')
        receipts = self._box(panes, '最近操作結果')
        panes.add(chats, minsize=360, stretch='always')
        panes.add(receipts, minsize=360, stretch='always')
        self.console_chat = self._text(chats, 10)
        self.control_log = self._text(receipts, 10)
        self._build_local_controls()
        # 0.2.18：資料讀取等系統訊息集中在這一行（原「本局局勢」頁的提示已移除）。
        self.notice_label = tk.Label(self.console_page, text='', bg=DAMASK, fg=MUTED, anchor='w',
                                     justify='left', wraplength=1100)
        self.notice_label.pack(fill='x', padx=14, pady=(0, 8))

    def _build_room_controls(self):
        box = self._box(self.room_control_page, '風夜進房與準備')
        box.pack(fill='both', expand=True, padx=14, pady=14)
        tk.Label(box, text='進房、確認準備狀態，然後開始遊戲。',
                 bg=DAMASK, fg=MUTED, anchor='w').pack(fill='x', padx=14, pady=(10, 8))
        probe_box = tk.Frame(box, bg=DAMASK)
        self.room_line = tk.StringVar(value='多线3')
        self.room_nickname = tk.StringVar(value='待秋至')
        primary = tk.Frame(probe_box, bg=DAMASK)
        primary.pack(fill='x', padx=8, pady=(8, 0))
        self.room_once = tk.Button(primary, text='自動登入、找房並進入', bg=BG, command=self.one_click_enter)
        self.room_once.pack(side='left')
        bar = tk.Frame(probe_box, bg=DAMASK)
        bar.pack(fill='x', padx=8, pady=8)
        self.room_line_combo = ttk.Combobox(bar, textvariable=self.room_line, width=8,
                                          values=['多线2', '多线3'], state='readonly')
        self.room_line_combo.pack(side='left')
        self.room_start = tk.Button(bar, text='登入風夜', bg=BG,
                                    command=lambda: self.room_action({'op': 'start', 'line': self.room_line.get()}))
        self.room_start.pack(side='left', padx=5)
        self.room_search = tk.Button(bar, text='更新房間', bg=BG,
                                     command=lambda: self.room_action({'op': 'search'}))
        self.room_search.pack(side='left')
        tk.Label(bar, text='進房暱稱', bg=DAMASK, fg=INK).pack(side='left', padx=(12, 5))
        self.room_nick_combo = ttk.Combobox(bar, textvariable=self.room_nickname, width=12,
                                          values=['待秋至', '風夜', '小白'], state='normal')
        self.room_nick_combo.pack(side='left')
        self.room_join = tk.Button(bar, text='進入所選房間', bg=BG, command=self.join_selected_room)
        self.room_join.pack(side='left', padx=5)
        self.room_leave = tk.Button(bar, text='離開房間', bg=BG,
                                    command=lambda: self.room_action({'op': 'leave'}))
        self.room_leave.pack(side='left')
        self.room_stop = tk.Button(bar, text='風夜下線', bg=BG,
                                   command=lambda: self.room_action({'op': 'stop'}))
        self.room_stop.pack(side='left', padx=5)
        flow = tk.Frame(probe_box, bg=DAMASK)
        flow.pack(fill='x', padx=8, pady=(0, 8))
        self.room_register = tk.Button(flow, text='完成報到', bg=BG, command=self.register_ghost)
        self.room_register.pack(side='left')
        self.room_d8 = tk.Button(flow, text='讓風夜藏好', bg=BG, command=self.withdraw_ghost)
        self.room_d8.pack(side='left', padx=8)
        self.room_retry = tk.Button(flow, text='↻ 重新來過', bg=BG, command=self.one_click_retry)
        self.room_retry.pack(side='left')
        self.room_flow_label = tk.Label(flow, bg=DAMASK, fg=MUTED)
        self.room_flow_label.pack(side='left', padx=8)
        lab = tk.Frame(box, bg=DAMASK)
        lab.pack(fill='x', padx=12, pady=(2, 12))
        tk.Button(lab, text='讓風夜進房', bg='#cbe7e4', fg='#164d51', command=self.lab_arm,
                  font=(self.face, 12, 'bold')).pack(side='left')
        tk.Button(lab, text='風夜下線', bg=BG, command=self.lab_stop).pack(side='left', padx=8)
        tk.Button(lab, text='查看風夜狀態', bg=BG, command=self.lab_status).pack(side='left')
        tk.Button(lab, text='卡住了？強制結束', bg='#f7e5e5', fg=WARN,
                  command=self.lab_force_quit).pack(side='left', padx=8)
        self.probe_toggle = tk.Button(lab, text='手動進房設定', bg=BG, command=self._toggle_probe_layer)
        self.probe_toggle.pack(side='right')
        self.probe_box, self._lab_row, self.probe_shown = probe_box, lab, False
        self.lab_label = tk.Label(box, text='還沒執行進房準備。準備期間請先別按遊戲的「開始」。',
                                 bg='#e4f1ef', fg='#245b61', anchor='w', justify='left',
                                 wraplength=1080, padx=14, pady=12)
        self.lab_label.pack(fill='x', padx=12, pady=(0, 12))
        self.room_tree = self.tree(box, [('name', '房間名稱', 220), ('host', '房主', 180), ('count', '目前人數', 100)])
        self.room_tree.configure(height=6)
        self.room_tree.bind('<<TreeviewSelect>>', lambda _e: self.update_room_controls())
        self.room_empty = tk.Label(self.room_tree, text='還沒有房間資料\n先請房主建好房間，再讓風夜進房。',
                                   bg=WELL, fg=MUTED, font=(self.face, 13), justify='center')
        self.room_empty.place(relx=.5, rely=.5, anchor='center')
        self.room_status = tk.Label(box, bg=DAMASK, fg=MUTED, anchor='w', justify='left', wraplength=1080)
        self.room_status.pack(fill='x', padx=14, pady=10)
        self.room_channel = tk.Label(box, bg=WELL, fg=INK, anchor='w', justify='left', wraplength=1080,
                                     font=(self.face, 12), padx=14, pady=12)
        self.room_channel.pack(fill='x', padx=12, pady=(0, 10))
        self.room_receipt = tk.Label(box, text='',
                                     bg=DAMASK, fg=MUTED, anchor='w', justify='left', wraplength=1080)
        self.room_receipt.pack(fill='x', padx=14, pady=(0, 12))

    def _toggle_probe_layer(self):
        """0.2.22：探針層默認收起（日常只用帶客戶端的流程）；要查房等再展開。"""
        self.probe_shown = not getattr(self, 'probe_shown', False)
        if self.probe_shown:
            self.probe_box.pack(fill='x', before=self._lab_row)
        else:
            self.probe_box.pack_forget()
        self.probe_toggle.configure(text=('收起手動設定' if self.probe_shown else '手動進房設定'))

    def join_selected_room(self):
        ids = self.room_tree.selection()
        row = self.room_rows.get(ids[0]) if ids else None
        if row is None and len(self.room_rows) == 1:
            row = next(iter(self.room_rows.values()))  # 只有一個房間：未選取也可直接進入
        if row is None:
            self.room_receipt.configure(text='請先在房間列表點選一個房間列，再按「進入所選房間」。')
            return
        try:
            name = nickname(self.room_nickname.get())
        except ValueError as error:
            self.room_receipt.configure(text=plain_error(error))
            return
        self.room_action({'op': 'join', 'room_id': row['id'], 'nickname': name, 'quick': True})

    def register_ghost(self):
        state = self.rooms.state
        if not (state.get('fresh') and state.get('connected')):
            return
        if not messagebox.askokcancel('風夜報到',
                                      '讓風夜在房間名單報到（只送一次）。\n'
                                      '名單會短暫出現風夜的名字；失敗不重試。確認執行？', parent=self.root):
            return
        self.room_action({'op': 'register'})

    def withdraw_ghost(self):
        state = self.rooms.state
        if not (state.get('fresh') and state.get('connected')):
            return
        if not messagebox.askokcancel('風夜藏身',
                                      '把風夜從名單中藏起來：這樣遊戲開局時不會等風夜，\n'
                                      '風夜可以一直暗中旁聽（名單會出現一行「風夜从游戏中退出了」）。\n'
                                      '請在遊戲按「開始」之前完成；只送一次、失敗不重試。確認執行？', parent=self.root):
            return
        self.room_action({'op': 'd8'})

    # ---- 風雲・本機控制（0.2.15）與實驗室一鍵（新流程） ----

    def _local_async(self, widget, label, func):
        def work():
            try:
                result = func()
            except Exception as error:
                result = {'status': 'error', 'error': '{}: {}'.format(type(error).__name__, error)}
            text = operation_result(label, result)

            def show():
                widget.configure(text=text[:2200])
            self.root.after(0, show)

        widget.configure(text=label + '…執行中（請稍候）')
        threading.Thread(target=work, daemon=True, name='fengyun-local').start()

    def local_login(self):
        self.local_state_label.configure(text='⏳ 登入中……（幾秒後自動顯示結果）', fg=INK)

        def work():
            try:
                result = fengyun_local.login(line=self.local_line.get())
            except Exception as error:
                result = {'status': 'error', 'error': '{}: {}'.format(type(error).__name__, error)}

            def show():
                if result.get('status') == 'already_online':
                    self.local_state_label.configure(text='風雲已在線，不用重複登入。', fg='#2f6a4f')
                    detail = '請切回現有遊戲視窗。'
                    rooms = result.get('rooms') or []
                    if rooms:
                        detail = (detail + '\n' if detail else '') + '房間列表：' + '、'.join(rooms)
                    self.local_status_label.configure(text=detail[:2200])
                else:
                    self.local_status_label.configure(
                        text=operation_result('進入遊戲', result))
                    self.root.after(6000, self.local_state_refresh)
                    self.root.after(15000, self.local_state_refresh)
            self.root.after(0, show)
        threading.Thread(target=work, daemon=True, name='fengyun-login').start()

    def local_exit(self):
        self._local_async(self.local_status_label, '結束風雲遊戲', fengyun_local.exit_soft)

    def local_kill(self):
        if not messagebox.askokcancel('強制關閉遊戲',
                                      '會關閉這台電腦上的風雲遊戲與大廳。未儲存的進度會遺失。確定繼續？',
                                      parent=self.root):
            return
        self._local_async(self.local_status_label, '強制關閉遊戲', fengyun_local.force_kill)

    def local_status(self):
        self._local_async(self.local_status_label, '本機狀態', fengyun_local.status)

    def local_state_refresh(self):
        if getattr(self, '_local_state_busy', False):
            return
        self._local_state_busy = True

        def work():
            try:
                result = fengyun_local.live_status()
            except Exception as error:
                result = {'state': 'error', 'headline': '狀態讀取失敗', 'detail': str(error)}

            def show():
                self._local_state_busy = False
                self._render_local_state(result)
            self.root.after(0, show)
        threading.Thread(target=work, daemon=True, name='fengyun-state').start()

    def _render_local_state(self, result):
        title, detail = local_state(result)
        state = result.get('state')
        self.local_state_label.configure(text=title, fg=GOLD if state == 'holding' else INK)
        self.local_status_label.configure(text=detail)

    def local_slots_read(self):
        self._local_slot_async('正在查看風雲對應的玩家',
                               lambda: fengyun_local.setforce('read'))

    def local_slot_set(self, slot):
        self._local_slot_async('切換風雲對應的玩家',
                               lambda: fengyun_local.setforce('switch', slot))

    def local_slot_restore(self):
        self._local_slot_async('切回風雲上一位玩家',
                               lambda: fengyun_local.setforce('restore'))

    def _local_slot_async(self, label, func):
        """本機席位操作：結果用與風夜相同的「名稱＋勢力」格式化顯示。"""
        def work():
            try:
                result = func()
            except Exception as error:
                result = {'status': 'error', 'error': '{}: {}'.format(type(error).__name__, error)}
            text = self._format_force(label, result)

            def show():
                self.local_slot_label.configure(text=text[:2200])
                self._update_slot_buttons(result)
            self.root.after(0, show)

        self.local_slot_label.configure(text=label + '，請稍候。')
        threading.Thread(target=work, daemon=True, name='fengyun-force').start()

    def _fengye_slot_async(self, label, script):
        def work():
            try:
                result = lab_remote(self.source.sources.host, script, timeout=180)
            except Exception as error:
                result = {'rc': -1, 'stderr': str(error)}
            text = self._format_force(label, result)

            def show():
                self.fengye_slot_label.configure(text=text[:2200])
                self._update_slot_buttons(result)
            self.root.after(0, show)

        self.fengye_slot_label.configure(text=label + '，請稍候。')
        threading.Thread(target=work, daemon=True, name='fengye-force').start()

    def _seat_table(self):
        """seat index -> (player name, faction name) from the current session snapshot."""
        view = getattr(self, 'view', None) or {}
        p = (view.get('p34') or {}) if isinstance(view, dict) else {}
        snapshots = p.get('snapshots') or {}
        block = snapshots.get('start') or snapshots.get('initial') or {}
        table = {}
        for row in block.get('rows') or []:
            try:
                seat = int(row.get('i'))
            except (TypeError, ValueError):
                continue
            name = row.get('name') or ('電腦' if row.get('state42') == 2 else '空席' if not row.get('id') else '未命名')
            table[seat] = (name, row.get('faction') or '—')
        return table

    def _update_slot_buttons(self, result):
        payload = force_payload(result)
        choices = force_choices(payload, self._seat_table()) if payload is not None else {}
        for table in (getattr(self, 'local_slot_buttons', None), getattr(self, 'fengye_slot_buttons', None)):
            for seat, button in (table or {}).items():
                button.configure(text=choices.get(seat, '等待玩家名單'),
                                 state='normal' if seat in choices else 'disabled')
                if seat in choices:
                    button.grid()
                else:
                    button.grid_remove()

    def _format_force(self, label, result):
        payload = force_payload(result)
        if payload is not None:
            return force_summary(payload, self._seat_table())
        return plain_error(result.get('stderr') or result.get('error'),
                           '還沒讀到本局玩家。請先進入對局，再按「更新可選玩家」。')

    def fengye_slot_read(self):
        self._fengye_slot_async('正在查看風夜對應的玩家',
                                'cd ~/sgi-protocol-lab-20260915/shadow && bash shadow_force.sh read')

    def fengye_slot_set(self, slot):
        self._fengye_slot_async('切換風夜對應的玩家',
                                'cd ~/sgi-protocol-lab-20260915/shadow && bash shadow_force.sh switch {}'.format(slot))

    def fengye_slot_restore(self):
        self._fengye_slot_async('切回風夜上一位玩家',
                                'cd ~/sgi-protocol-lab-20260915/shadow && bash shadow_force.sh restore')

    def _lab_async(self, label, script, timeout=360):
        def work():
            try:
                result = lab_remote(self.source.sources.host, script, timeout=timeout)
            except Exception as error:
                result = {'rc': -1, 'stderr': str(error)}
            text = lab_result(label, result)

            def show():
                display = text
                if label == '查看風夜狀態' and result.get('rc') == 0:
                    display = '\n'.join(room_summary(self.rooms.state))
                self.lab_label.configure(text=display[:2600])
            self.root.after(0, show)

        self.lab_label.configure(text=label + '…執行中（可能需數分鐘）')
        threading.Thread(target=work, daemon=True, name='fengye-lab').start()

    def lab_arm(self):
        if not messagebox.askokcancel('讓風夜進房？',
                                      '請先讓房主建好房間。\n'
                                      '這會結束風夜先前的連線，再重新進房並做好開局準備。\n'
                                      '準備期間先別按「開始」，等情報台通知可以開始。確定繼續？',
                                      parent=self.root):
            return
        self._lab_async('風夜進房準備',
                        'cd ~/sgi-protocol-lab-20260915/shadow && bash arm_now.sh')

    def lab_stop(self):
        self._lab_async('讓風夜下線',
                        'cd ~/sgi-protocol-lab-20260915/shadow && bash stop_shadow.sh',
                        timeout=90)

    def lab_force_quit(self):
        if not messagebox.askokcancel('風夜卡住了？',
                                      '這會強制關閉風夜的遊戲與相關連線。\n'
                                      '正常離開請用「風夜下線」；只有卡住、無法正常離開時才使用這個按鈕。確定繼續？',
                                      parent=self.root):
            return
        self._lab_async('強制結束風夜',
                        'cd ~/sgi-protocol-lab-20260915/shadow && bash shadow_force_quit.sh',
                        timeout=120)

    def lab_status(self):
        script = (
            "cd ~/sgi-protocol-lab-20260915/shadow\n"
            "echo '[進程]'\n"
            "(pgrep -fl prefix-fengye-shadow | head -3 || echo 無進程)\n"
            "echo '[D8 藏身回執]'\n"
            "(xxd -l 16 shadow_d8_receipt.bin 2>/dev/null || echo 無回執)\n"
            "echo '[崩潰台帳]'\n"
            "ls -la \"$HOME/Library/Application Support/SGI-Wine/prefix-fengye-shadow/drive_c/sgi/run-3.5/3I/sgi-crash-context.bin\" 2>/dev/null | awk '{print $5, $6, $7, $8}'\n"
            "echo '[app.log 尾]'\n"
            "tail -2 logs/app.log 2>/dev/null\n"
        )
        self._lab_async('查看風夜狀態', script, timeout=60)

    def _build_local_controls(self):
        page = tk.Frame(self.control_book, bg=DAMASK)
        self.control_book.add(page, text='玩家與遊戲')
        box = self._box(page, '風雲遊戲 · 這台電腦')
        box.pack(fill='x', padx=10, pady=10)
        bar = tk.Frame(box, bg=DAMASK)
        bar.pack(fill='x', padx=8, pady=6)
        self.local_line = tk.StringVar(value='多线3（备用）')
        ttk.Combobox(bar, textvariable=self.local_line, width=14,
                     values=['多线3（备用）', '多线2（主线）'], state='readonly').pack(side='left')
        tk.Button(bar, text='進入遊戲', bg=BG, command=self.local_login).pack(side='left', padx=6)
        tk.Button(bar, text='結束遊戲', bg=BG, command=self.local_exit).pack(side='left')
        tk.Button(bar, text='強制結束', bg='#ead4c6', fg=WARN, command=self.local_kill).pack(side='left', padx=6)
        tk.Button(bar, text='更新狀態', bg=BG, command=self.local_state_refresh).pack(side='right')
        self.local_state_label = tk.Label(box, bg=WELL, fg=MUTED, anchor='w', justify='left',
                                          wraplength=1080, font=(self.face, 12, 'bold'))
        self.local_state_label.pack(fill='x', padx=8, pady=(6, 0))
        self.local_status_label = tk.Label(box, bg=WELL, fg=INK, anchor='w', justify='left', wraplength=1080)
        self.local_status_label.pack(fill='x', padx=8, pady=(0, 6))
        box2 = self._box(page, '風雲 · 切換對應的玩家')
        box2.pack(fill='x', padx=10, pady=(0, 10))
        bar2 = tk.Frame(box2, bg=DAMASK)
        bar2.pack(fill='x', padx=8, pady=6)
        tk.Button(bar2, text='更新可選玩家', bg=BG, command=self.local_slots_read).pack(side='left')
        tk.Label(bar2, text='切換到：', bg=DAMASK, fg=INK).pack(side='left', padx=(12, 4))
        self.local_slot_buttons = {}
        local_choices = tk.Frame(box2, bg=DAMASK)
        local_choices.pack(fill='x', padx=8, pady=6)
        for slot in range(8):
            local_choices.columnconfigure(slot % 4, weight=1)
            btn = tk.Button(local_choices, text='等待玩家名單', bg=BG, state='disabled',
                            command=lambda value=slot: self.local_slot_set(value))
            btn.grid(row=slot // 4, column=slot % 4, sticky='ew', padx=3, pady=3)
            btn.grid_remove()
            self.local_slot_buttons[slot] = btn
        tk.Button(bar2, text='切回上一位', bg=BG, command=self.local_slot_restore).pack(side='left', padx=10)
        self.local_slot_label = tk.Label(box2, text='開局後，按「更新可選玩家」即可看到玩家與勢力名稱。', bg=WELL, fg=INK, anchor='w', justify='left', wraplength=1080)
        self.local_slot_label.pack(fill='x', padx=8, pady=(0, 6))
        box3 = self._box(page, '風夜 · 切換對應的玩家')
        box3.pack(fill='x', padx=10, pady=(0, 10))
        bar3 = tk.Frame(box3, bg=DAMASK)
        bar3.pack(fill='x', padx=8, pady=6)
        tk.Button(bar3, text='更新可選玩家', bg=BG, command=self.fengye_slot_read).pack(side='left')
        tk.Label(bar3, text='切換到：', bg=DAMASK, fg=INK).pack(side='left', padx=(12, 4))
        self.fengye_slot_buttons = {}
        fengye_choices = tk.Frame(box3, bg=DAMASK)
        fengye_choices.pack(fill='x', padx=8, pady=6)
        for slot in range(8):
            fengye_choices.columnconfigure(slot % 4, weight=1)
            btn = tk.Button(fengye_choices, text='等待玩家名單', bg=BG, state='disabled',
                            command=lambda value=slot: self.fengye_slot_set(value))
            btn.grid(row=slot // 4, column=slot % 4, sticky='ew', padx=3, pady=3)
            btn.grid_remove()
            self.fengye_slot_buttons[slot] = btn
        tk.Button(bar3, text='切回上一位', bg=BG, command=self.fengye_slot_restore).pack(side='left', padx=10)
        self.fengye_slot_label = tk.Label(box3, text='開局後，按「更新可選玩家」即可看到玩家與勢力名稱。', bg=WELL, fg=INK, anchor='w', justify='left', wraplength=1080)
        self.fengye_slot_label.pack(fill='x', padx=8, pady=(0, 6))
        tk.Label(page, text='先進入對局，再選擇要對應的玩家。切換結果請同時查看遊戲畫面；尚未取得名字時，不提供數字按鈕猜選。',
                 bg=DAMASK, fg=MUTED, anchor='w', justify='left', wraplength=1080).pack(fill='x', padx=14, pady=(0, 10))
        if not self.source.sources.source_file:
            self.local_state_refresh()
            self.fengye_slot_read()

    def room_action(self, payload):
        if self.room_busy or self.room_pending or self.room_uncertain or self.source.sources.source_file:
            self.room_receipt.configure(text='上一個操作還沒確認結果。請先更新狀態，不用重複點擊。')
            return
        try:
            self.jobs.put_nowait(('room', payload))
        except queue.Full:
            self.room_receipt.configure(text='正在讀取狀態，請稍候。')
            return
        self.room_busy = True
        self.room_receipt.configure(text='正在處理，請稍候；不用重複點擊。')
        self.update_room_controls()

    def update_room_controls(self):
        if not hasattr(self, 'room_start'):
            return
        state = self.rooms.state
        writable = not self.source.sources.source_file and not (self.room_busy or self.room_pending or self.room_uncertain)
        fresh = state.get('fresh') and (state.get('external') or
            isinstance(state.get('observed_at'), (int, float)) and 0 <= time.time()-state['observed_at'] <= 20)
        lobby = fresh and state.get('phase') == 'lobby' and not state.get('connected')
        q = state.get('room_query') or {}
        observed = q.get('observed_at')
        listed = isinstance(observed, (int, float)) and 0 <= time.time()-observed <= 60
        registered = bool(state.get('ghost_registered'))
        withdrawn = bool(state.get('ghost_withdrawn'))
        native_state = state.get('native_sync_state')
        modes = ((self.room_once, not (fresh and state.get('connected'))),
                 (self.room_start, not state.get('alive')),
                 (self.room_search, lobby or fresh and state.get('external')), (self.room_join, lobby and listed and (bool(self.room_tree.selection()) or len(self.room_rows) == 1)),
                 (self.room_leave, fresh and state.get('connected')), (self.room_stop, fresh and not state.get('external') and state.get('phase') != 'stopped'),
                 (self.room_register, fresh and state.get('connected') and not registered),
                 (self.room_d8, fresh and state.get('connected') and registered and not withdrawn
                  and native_state == 1))
        retrying = self.retry is not None
        for button, allowed in modes:
            button.configure(state='normal' if writable and allowed and not retrying else 'disabled')
        if hasattr(self, 'room_retry'):
            self.room_retry.configure(
                state='disabled' if self.source.sources.source_file else 'normal',
                text=('✕ 取消重做' if retrying else '↻ 重新來過'))
        self.room_stop.configure(text='風夜下線',
                                 bg='#ead4c6' if withdrawn else BG)
        if fresh and state.get('connected') and registered and not withdrawn:
            self.room_flow_label.configure(text='⚠️ 正在藏身（幾秒）——先別按「開始」', fg=WARN)
        elif fresh and state.get('connected') and withdrawn:
            d8r = state.get('d8') or {}
            if d8r.get('fast') or state.get('exit_seen_wall'):
                self.room_flow_label.configure(text='✅ 已藏好——現在可以按「開始」', fg='#2f6a4f')
            else:
                self.room_flow_label.configure(text='⚠️ 藏身訊號已送出（主機處理約 2 分鐘）——等名單上風夜消失再按「開始」', fg=WARN)
        else:
            self.room_flow_label.configure(text='等待本次進房準備。', fg=MUTED)
        self.room_line_combo.configure(state='readonly' if writable and not state.get('alive') else 'disabled')
        self.room_nick_combo.configure(state='normal' if writable and not state.get('connected') else 'disabled')

    def render_rooms(self):
        state = self.rooms.state
        q = state.get('room_query') or {}
        signature = json.dumps(q, ensure_ascii=False, sort_keys=True)
        if signature != self.room_signature:
            selected = self.room_tree.selection()
            selected_id = self.room_rows.get(selected[0], {}).get('id') if selected else None
            self.room_tree.delete(*self.room_tree.get_children())
            self.room_rows = {}
            for row in q.get('rooms') or []:
                iid = self.room_tree.insert('', 'end', values=(row.get('name') or '未命名房間',
                    row.get('host') or '尚未確認',
                    '{} / {}'.format(row.get('current', '未確認'), row.get('maximum', '未確認'))))
                self.room_rows[iid] = row
                if row.get('id') == selected_id:
                    self.room_tree.selection_set(iid)
            self.room_signature = signature
        if self.room_rows:
            self.room_empty.place_forget()
        else:
            self.room_empty.place(relx=.5, rely=.5, anchor='center')
            self.room_empty.configure(text=('還沒收到房間回覆，不能確定有沒有房間。'
                if q.get('status') == 'unconfirmed_empty' else
                '還沒有房間資料\n需要手動選房時，請展開「手動進房設定」。'))
        labels = {'idle': '還沒登入', 'starting': '正在登入', 'lobby': '正在查看房間',
                  'joining': '正在進房', 'room': '已進入房間', 'stopped': '風夜已停止連線',
                  'stale': '狀態暫未更新', 'disconnected': '連線已中斷',
                  'external_lobby': '正在查看現有大廳的房間'}
        line = str(state.get('line') or self.room_line.get()).replace('多线', '多線')
        text = '{} · {}'.format(labels.get(state.get('phase'), '正在確認'), line)
        if q.get('observed_at'):
            text += ' · 房間資料更新於 ' + wall_text(q['observed_at'])
        if state.get('error') or q.get('error'):
            text += '\n' + plain_error(state.get('error') or q.get('error'))
        self.room_status.configure(text=text)
        headline, hint = room_summary(state)
        self.room_channel.configure(text=headline + '\n' + hint)
        result = state.get('last_result') or {}
        if self.room_pending and result.get('id') == self.room_pending:
            self.room_receipt.configure(text=room_result(result))
            self.room_pending = None
            self.room_uncertain = result.get('status') == 'unknown'
            self._maybe_chain(result)
            self._notify_room_result(result)
            self._maybe_retry(result)
        self.update_room_controls()

    def _notify_room_result(self, result):
        """0.2.5：摘席流程關鍵節點的本機提示（遊戲視窗在前也看得到）。"""
        op, status = result.get('op'), result.get('status')
        room_state = self.rooms.state or {}
        d8r = room_state.get('d8') or {}
        ready = bool(d8r.get('fast') or room_state.get('exit_seen_wall'))
        if op == 'join' and status == 'completed':
            if room_state.get('ghost_withdrawn'):
                if ready:
                    notify_operator('風夜已藏好啦', '現在可以在遊戲按「開始」', sound='Glass')
                else:
                    notify_operator('藏身訊號已送出', '等風夜從遊戲名單消失（約 2 分鐘）再按「開始」', sound='Ping')
            else:
                notify_operator('風夜正在藏身', '幾秒就好——先別按「開始」', sound='Ping')
        elif op == 'join' and status == 'error':
            reason = plain_error(result.get('error') or result.get('detail'))
            notify_operator('風夜藏身沒成功', reason[:90], sound='Basso')
        elif op == 'd8' and status == 'completed':
            if ready:
                notify_operator('風夜已藏好啦', '現在可以在遊戲按「開始」', sound='Glass')
            else:
                notify_operator('藏身訊號已送出', '等風夜從遊戲名單消失（約 2 分鐘）再按「開始」', sound='Ping')
        elif op == 'd8' and status == 'error':
            reason = plain_error(result.get('error') or result.get('detail'))
            if '提前開始' not in reason and '開局等待' not in reason:
                notify_operator('風夜藏身沒成功', reason[:90], sound='Basso')

    def _maybe_chain(self, result):
        if result.get('status') != 'completed':
            return
        state = self.rooms.state
        op = result.get('op')
        if op == 'join' and state.get('connected') and not state.get('ghost_registered') and not state.get('ghost_withdrawn'):
            self.room_receipt.configure(text='自動準備：已進房，接著報到…')
            self.root.after(800, lambda: self._chain_fire('register'))
        elif op == 'register' and state.get('ghost_registered') and not state.get('ghost_withdrawn'):
            self.room_receipt.configure(text='自動準備：已報到，接著藏身…')
            self.root.after(800, lambda: self._chain_fire('d8'))

    def _chain_fire(self, op):
        self.room_action({'op': op})

    def _retry_label(self):
        return (self.retry or {}).get('label', '重新來過')

    def one_click_enter(self):
        """0.2.21 一鍵上場：登入(如需)→更新房間→進入(自動報到→藏身)；完成後流程自動收束。"""
        if self.source.sources.source_file:
            return
        if self.retry is not None or self.room_busy or self.room_pending or self.room_uncertain:
            self.room_receipt.configure(text='上一個操作還在進行（或結果未知）——請稍候，或按「↻ 重新來過」。')
            return
        state = self.rooms.state or {}
        if state.get('fresh') and state.get('connected'):
            self.room_receipt.configure(text='風夜已經在房間裡了（報到／藏身狀態見下方）；要重來請按「↻ 重新來過」。')
            return
        steps = []
        if not (state.get('fresh') and state.get('alive')):
            steps += ['start', 'wait_lobby']
        q = state.get('room_query') or {}
        observed = q.get('observed_at')
        fresh_rooms = (isinstance(observed, (int, float)) and 0 <= time.time() - observed <= 30
                       and (q.get('rooms') or []))
        if not fresh_rooms:
            steps.append('search')
        steps.append('wait_rooms')
        self.retry = {'steps': steps, 'deadline': time.monotonic() + 180, 'start_retries': 0,
                      'label': '一鍵上場'}
        self.retry_next()

    def one_click_retry(self):
        """失敗後一鍵收尾重來：退房→收線→重登→查房→進入（接手自動註冊→摘席）。"""
        if self.source.sources.source_file:
            return
        if self.retry is not None:
            self.retry = None
            self.room_receipt.configure(text='已取消「重新來過」；按鈕恢復正常。')
            return
        state = self.rooms.state
        steps = []
        if state.get('connected'):
            steps.append('leave')
        if state.get('alive') or state.get('fresh'):
            steps.append('stop')
        steps += ['wait_teardown', 'start', 'wait_lobby', 'search', 'wait_rooms']
        self.retry = {'steps': steps, 'deadline': time.monotonic() + 150, 'start_retries': 0,
                      'label': '重新來過'}
        self.room_receipt.configure(text='重新來過：開始收尾（若遊戲裡有等待畫面，請按掉取消）…')
        self.retry_next()

    def retry_next(self):
        """推進「一鍵重來」流程；每步只發一次操作，結果經 _maybe_retry 續行。"""
        tag = (self.retry or {}).get('label', '重新來過')
        if self.retry is None:
            return
        if time.monotonic() > self.retry.get('deadline', 0):
            self.retry = None
            self.room_receipt.configure(text=tag + '：超時中止；請確認狀態後再試。')
            return
        if self.room_uncertain:
            self.retry = None
            self.room_receipt.configure(text=tag + '：上次操作結果未知（不重複送），已中止。')
            return
        if self.room_busy or self.room_pending:
            return
        steps = self.retry['steps']
        if not steps:
            self.retry = None
            self.room_receipt.configure(text=tag + '：已進房並自動藏身——聽到「可以開始」提示音後再按「開始」。')
            return
        step = steps[0]
        state = self.rooms.state
        if step == 'leave':
            self.retry['steps'] = steps[1:]
            self.room_action({'op': 'leave'})
            self.room_receipt.configure(text=tag + '：退出房間…（若有等待畫面請按掉）')
        elif step == 'stop':
            self.retry['steps'] = steps[1:]
            self.room_action({'op': 'stop'})
            self.room_receipt.configure(text=tag + '：讓風夜下線…')
        elif step == 'wait_teardown':
            if not state.get('alive') and not state.get('fresh'):
                self.retry['steps'] = steps[1:]
                self.room_receipt.configure(text=tag + '：已下線，重新登入…')
                self.retry_next()
        elif step == 'start':
            self.retry['steps'] = steps[1:]
            self.room_action({'op': 'start', 'line': self.room_line.get()})
            self.room_receipt.configure(text=tag + '：登入風夜大廳…')
        elif step == 'wait_lobby':
            if state.get('fresh') and state.get('alive') and state.get('phase') == 'lobby':
                self.retry['steps'] = steps[1:]
                self.retry_next()
        elif step == 'search':
            self.retry['steps'] = steps[1:]
            self.room_action({'op': 'search'})
            self.room_receipt.configure(text=tag + '：查房中…')
        elif step == 'wait_rooms':
            if not (state.get('fresh') and state.get('phase') == 'lobby'):
                return
            q = state.get('room_query') or {}
            observed = q.get('observed_at')
            if not isinstance(observed, (int, float)) or time.time() - observed > 60:
                return
            rooms = q.get('rooms') or []
            self.retry['steps'] = []
            if len(rooms) == 1:
                row = rooms[0]
                try:
                    name = nickname(self.room_nickname.get())
                except ValueError as error:
                    self.retry = None
                    self.room_receipt.configure(text=plain_error(error))
                    return
                self.room_action({'op': 'join', 'room_id': row['id'], 'nickname': name, 'quick': True})
                self.room_receipt.configure(text=tag + '：進入「{}」——等一下會通知「可以開始」…'.format(row.get('name') or '所選房間'))
            elif not rooms:
                self.retry = None
                self.room_receipt.configure(text=tag + '：查不到房間——請先在遊戲重開房間，再按「↻ 重新來過」。')
            else:
                self.retry = None
                self.room_receipt.configure(text=tag + '：有多個房間，請自行選房後按「進入所選房間」。')

    def _maybe_retry(self, result):
        if self.retry is None:
            return
        op, status = result.get('op'), result.get('status')
        if op == 'start':
            if status == 'started':
                self.retry_next()
            elif self.retry.get('start_retries', 0) < 2:
                self.retry['start_retries'] = self.retry.get('start_retries', 0) + 1
                self.retry['steps'].insert(0, 'start')
                self.room_receipt.configure(text='重新來過：登入暫未成功，4 秒後再試一次…')
                self.root.after(4000, self.retry_next)
            else:
                self.retry = None
                self.room_receipt.configure(text='重新來過：' + plain_error(result.get('error') or status))
            return
        if op in ('leave', 'stop', 'search') and status in ('completed', 'error'):
            # 收尾步驟失敗不致命（可能已斷線／已停止）：繼續下一步。
            self.retry_next()
        elif op == 'join':
            if status == 'completed':
                self.retry_next()
            else:
                self.retry = None
                self.room_receipt.configure(text='重新來過：' + plain_error(result.get('error') or result.get('detail') or status))

    # Keep the complete original polling/rendering path. Fengye has a separate
    # worker and queue, so an offline probe never replaces a valid world state.
    def _fetch_fengye(self):
        job = ('refresh', False)
        while not self.stop.is_set():
            op, payload = job
            try:
                if op == 'room':
                    result = self.rooms.call(payload)
                    self.messages.put(('room_result', result))
                if op == 'control':
                    try:
                        result = self.source.send(payload)
                    except Exception:
                        result = {'status': 'error', 'error': '控制結果未知；未重試'}
                    self.messages.put(('control', result))
            except Exception:
                self.messages.put(('error', '操作失敗；保留最後記錄'))
            # 2026-10-17：資料讀取與大廳心跳分開執行——資料通道失敗或超時時，
            # 房間監控（維持探針心跳）仍必須繼續，避免探針因心跳到期誤收尾。
            try:
                self.messages.put(('view', self.source.refresh(search=(op == 'refresh' and payload))))
            except Exception:
                self.messages.put(('error', '讀取失敗；保留最後記錄'))
            try:
                self.rooms.call({'op': 'status'})
                self.messages.put(('rooms', None))
            except Exception:
                pass
            self.messages.put(('idle', None))
            while not self.stop.is_set():
                try:
                    job = self.jobs.get(timeout=.25)
                    break
                except queue.Empty:
                    if self.stop.wait(.25):
                        return
                    # Poll only while this native window exists. 房間操作待回執時
                    # 加快輪詢（5s→1s），縮短一鍵流程的暴露窗口。
                    interval = 0.5 if (self.room_busy or self.room_pending) else 5
                    if time.monotonic() - getattr(self, '_last_poll', 0) >= interval:
                        job = ('refresh', False)
                        break
            self._last_poll = time.monotonic()

    def request_refresh(self, search=False):
        if self.stop.is_set():
            return
        try:
            self.jobs.put_nowait(('refresh', search))
        except queue.Full:
            pass

    def _tick_fengye(self):
        try:
            while True:
                kind, value = self.messages.get_nowait()
                if kind == 'view':
                    self.view = value
                    self.render_view(value)
                elif kind == 'control':
                    self.control_busy = False
                    if value.get('status') == 'sent':
                        self.pending_id = value.get('id')
                        self.control_result.configure(text='操作已送出，正在等風夜回覆；還沒確認完成。')
                        if value.get('op') == 'chat':
                            self.chat_input.delete('1.0', 'end')
                    else:
                        self.pending_uncertain = True
                        self.control_result.configure(text=plain_error(value.get('error') or value.get('status')))
                elif kind == 'room_result':
                    self.room_busy = False
                    if value.get('status') == 'sent':
                        self.room_pending = value.get('id')
                        self.room_receipt.configure(text='操作已送出，正在等風夜回覆；不用重複點擊。')
                    else:
                        self.room_uncertain = value.get('status') == 'unknown'
                        self.room_receipt.configure(text=room_result(value))
                        self._maybe_retry(value)
                    self.render_rooms()
                elif kind == 'rooms':
                    self.render_rooms()
                elif kind == 'error':
                    self.notice_label.configure(text=plain_error(value, '資料暫時更新不到，舊紀錄不代表風夜仍在線。請稍後更新狀態。'))
                elif kind == 'idle':
                    self.reload_btn.configure(state='normal')
        except queue.Empty:
            pass
        except Exception as error:
            self.render_error = str(error)
            print('fengye-render', error, flush=True)
        self.update_control_state()
        self.update_room_controls()
        if self.retry is not None:
            try:
                self.retry_next()
            except Exception:
                self.retry = None
        self._local_state_n = getattr(self, '_local_state_n', 0) + 1
        if self._local_state_n % 40 == 0 and not self.source.sources.source_file:
            try:
                self.local_state_refresh()
            except Exception:
                pass
        if not self.stop.is_set():
            self.root.after(250, self._tick_fengye)

    def render_view(self, view):
        p = view.get('p34') or {}
        session = view.get('session') or {}
        transport = (view.get('transport') or {}).get('status')
        self.status.configure(text={'online': '正在更新本局資料', 'file': '正在查看保存的記錄',
                                   'offline': '目前連不到風夜'}.get(transport, '正在確認風夜狀態'))
        signature = json.dumps({k: view.get(k) for k in ('p34', 'host', 'members', 'events', 'directory', 'room_query', 'chain', 'source', 'ghost', 'collector')}, ensure_ascii=False, sort_keys=True)
        if signature != self.render_signature:
            chats = (p.get('chat') or {}).get('messages') or []
            chat_text = '\n\n'.join('{}　{}\n{}'.format(wall_text(m.get('wall')),
                m.get('sender_name') or '—', str(m.get('text') or '—')) for m in chats) or (
                '本局尚無聊天記錄。' if session else '目前沒有可核實的聊天記錄。')
            self._set_text(self.console_chat, chat_text)
            events = (p.get('control') or {}).get('events') or []
            self._set_text(self.control_log, '\n\n'.join(
                '{}\n{}'.format(wall_text(e.get('wall')), control_event(e))
                for e in reversed(events)) or '目前還沒有操作結果。')
            self.render_signature = signature
        control = p.get('control') or {}
        last = control.get('last_result') or {}
        if self.pending_id and last.get('id') == self.pending_id:
            self.control_result.configure(text=control_event(dict(last, ev='control_done')))
            self.pending_id = None
        if self.pending_run and p.get('run_name') != self.pending_run:
            self.pending_id = None
            self.pending_uncertain = False
            self.control_result.configure(text='目前顯示的是另一場對局；先前操作不會再次送出。')
            self.pending_run = None
        self.update_control_state()

    def input_changed(self, _=None):
        if not self.chat_input.edit_modified():
            return
        self.chat_input.edit_modified(False)
        text = self.chat_input.get('1.0', 'end-1c')
        try:
            text.encode('gbk')
            valid = len(text) <= 120
            suffix = '可以送出' if valid else '超過 120 字，請縮短訊息'
        except UnicodeEncodeError:
            valid = False
            suffix = '有遊戲無法顯示的字，請改用常見文字'
        self.char_label.configure(text='{} / 120 字 · {}'.format(len(text), suffix), fg=MUTED if valid else WARN)
        self.update_control_state()

    def update_control_state(self):
        if not hasattr(self, 'console_state'):
            return
        ready = control_ready(self.view)
        p = self.view.get('p34') or {}
        pending = self.pending_id or (p.get('control') or {}).get('pending')
        enabled = ready and not self.control_busy and not pending and not self.pending_uncertain and time.monotonic() >= self.cooldown
        lobby = self.rooms.state
        if self.source.sources.source_file:
            headline = '正在查看保存的記錄，這裡不能操作遊戲。'
        elif room_fresh(lobby):
            if lobby.get('connected') and not lobby.get('ghost_withdrawn'):
                if lobby.get('ghost_registered'):
                    headline = '⚠ 風夜正在藏身（幾秒）——先別按「開始」'
                else:
                    headline = '⚠ 風夜已進房，正在報到→藏身——先別按「開始」'
            elif lobby.get('connected') and lobby.get('ghost_withdrawn'):
                d8r = lobby.get('d8') or {}
                if d8r.get('fast') or lobby.get('exit_seen_wall'):
                    headline = '✅ 風夜已藏好·旁聽中——可以按「開始」'
                else:
                    headline = '⚠ 藏身訊號已送出——等風夜從遊戲名單消失再按「開始」（約 2 分鐘）'
            else:
                headline = '風夜還在大廳，尚未進入房間。'
        else:
            headline = '風夜尚未進房 · 先請房主建房，再讓風夜進房。'
        self.console_state.configure(text=headline)
        try:
            validate_control({'op': 'chat', 'text': self.chat_input.get('1.0', 'end-1c')})
            text_valid = True
        except ValueError:
            text_valid = False
        self.chat_button.configure(state='normal' if enabled and text_valid else 'disabled')
        self.stop_button.configure(state='normal' if enabled else 'disabled')

    def send_control(self, payload):
        if not control_ready(self.view) or self.control_busy or self.pending_id or self.pending_uncertain or (self.view.get('p34') or {}).get('control', {}).get('pending') or time.monotonic() < self.cooldown:
            return
        try:
            payload = validate_control(payload)
        except ValueError as error:
            messagebox.showerror('無法送出', plain_error(error), parent=self.root)
            return
        try:
            self.jobs.put_nowait(('control', payload))
        except queue.Full:
            self.control_result.configure(text='正在讀取狀態；本次未送出，請稍候。')
            return
        self.control_busy = True
        self.pending_run = (self.view.get('p34') or {}).get('run_name')
        self.cooldown = time.monotonic() + 2
        self.control_result.configure(text='送出單次請求中；不會自動重試。')
        self.update_control_state()

    def send_chat(self):
        self.send_control({'op': 'chat', 'text': self.chat_input.get('1.0', 'end-1c')})

    def send_stop(self):
        if not control_ready(self.view) or self.control_busy:
            return
        if messagebox.askokcancel('風夜下線（正常退出）',
                                  '讓風夜下線並結束旁聽？\n'
                                  '下線後要再旁聽需重新登入。', parent=self.root):
            self.send_control({'op': 'stop'})

