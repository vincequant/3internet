"""Owned Wine session: lobby SearchSession, explicit Open/ExitSession.

No game-process access, command injection, battle participation or automatic
ready replies. Uses an owned notification HWND and releases every packet.
"""
import argparse
import ctypes as c
from ctypes import wintypes as w
import hashlib
import json
import os
from pathlib import Path
import struct
import sys
import time


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--target')
    ap.add_argument('--session-name')
    ap.add_argument('--username')
    ap.add_argument('--hold', type=int, default=86400)
    ap.add_argument('--session-dir', required=True)
    ap.add_argument('--lab', required=True)
    args = ap.parse_args()
    folder = Path(args.session_dir)
    sys.path.insert(0, args.lab)
    sys.path.insert(0, str(folder))
    from p28_window import Receiver, WM_EVENT, WM_DATA, WM_CHAT
    from room_protocol import request, reserve_join
    if c.sizeof(c.c_void_p) != 4:
        raise ValueError('32-bit native runtime required')
    def read(name):
        try:
            return json.loads((folder / name).read_text(encoding='utf-8'))
        except (OSError, ValueError):
            return {}
    def write(name, data):
        path = folder / name
        tmp = path.with_suffix('.tmp')
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
        tmp.replace(path)
    audit = (folder / 'packets.jsonl').open('a', encoding='utf-8', buffering=1)
    state = {'phase': 'starting', 'connected': False, 'application_ready': False,
             'room_query': {}, 'channel': {}, 'last_result': None}
    def log(event):
        event.update(wall=time.time())
        audit.write(json.dumps(event, ensure_ascii=False) + '\n')
    root = Path(r'C:\sgi\run-3.5')
    dllpath = root / '3I/Koeinm.dll'
    hookpath = root / 'NetHookCore.dll'
    # Bind the installed binaries in the run, rather than guessing version
    # offsets. Only public DLL exports are used by this viewer.
    state['binary_sha256'] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (dllpath, hookpath)}
    if state['binary_sha256']['NetHookCore.dll'] != '5b3790982f7c54f891e5b3c8559e7a61c7589d8a4a9d68bc9f8f8992b5b678b4':
        raise ValueError('unexpected transport binary')
    dll = c.WinDLL(str(dllpath))
    hook = c.WinDLL(str(hookpath))
    def export(name, params, result=c.c_int):
        f = getattr(dll, '_NetMsg_' + name)
        f.argtypes, f.restype = params, result
        return f
    start = export('Start@36', [c.c_uint32]*8+[c.POINTER(c.c_uint32)])
    search = export('SearchSession@12', [c.c_char_p, w.HWND, w.UINT])
    getip = export('GetIPAddress@4', [c.POINTER(c.c_void_p)])
    opens = export('OpenSession@20', [c.c_char_p]*3+[c.c_uint32]*2)
    hostid = export('GetHostID@0', [], c.c_uint32)
    setdata = export('SetDataWindow@8', [w.HWND, w.UINT])
    setchat = export('SetChatWindow@8', [w.HWND, w.UINT])
    decode = export('DecodeWParam@4', [c.c_uint32])
    delete = export('DeletePacket@4', [c.c_void_p])
    accept = export('AcceptEXIT@4', [c.c_uint32])
    connected = export('IsConnected@0', [])
    exits = export('ExitSession@0', [])
    end = export('End@0', [])
    receiver = Receiver(log, decode, delete, accept)
    u, k = receiver.u, receiver.k
    k.GlobalFree.argtypes, k.GlobalFree.restype = [c.c_void_p], c.c_void_p
    room_msg = 0x2403
    own = None
    started = joined = False
    seen = set()
    next_search, next_save = 0, 0
    def do_search():
        nonlocal next_search
        # Search returns thread messages, so drain them BEFORE generic pump.
        rc = int(search(b'255.255.255.255', None, room_msg))
        msg = w.MSG()
        rooms = {}
        while u.PeekMessageW(c.byref(msg), None, room_msg, room_msg, 1):
            if msg.wParam == 5 and msg.lParam:
                ptr = c.c_void_p(msg.lParam)
                try:
                    raw = c.string_at(ptr, 80)
                    row = {'id': str(struct.unpack_from('<I', raw)[0]),
                           'name': raw[4:35].split(b'\0')[0].decode('gbk', 'replace'),
                           'host': raw[35:66].split(b'\0')[0].decode('gbk', 'replace'),
                           'maximum': struct.unpack_from('<I', raw, 68)[0],
                           'current': struct.unpack_from('<I', raw, 72)[0]}
                    row['virtual_ip'] = '.'.join(str(v) for v in struct.pack('!I', int(row['id'])))
                    rooms[row['id']] = row
                finally:
                    k.GlobalFree(ptr)
        now = time.time()
        if rc == 0:
            state['room_query'] = {'observed_at': now, 'rooms': list(rooms.values()),
                'status': 'replies_received' if rooms else 'unconfirmed_empty', 'rc': rc,
                'source': 'SearchSession through owned relay'}
        else:
            state['room_query'] = dict(state['room_query'], error='SearchSession rc=' + str(rc))
        next_search = time.monotonic() + 15
        return rc
    try:
        flag = c.c_uint32()
        rc = int(start(8, 64, 7777, int(receiver.hwnd), WM_EVENT, 78731, 0, 0, c.byref(flag)))
        started = rc == 0
        if not started:
            raise RuntimeError('NetMsg_Start rc=' + str(rc))
        setdata(receiver.hwnd, WM_DATA)
        setchat(receiver.hwnd, WM_CHAT)
        ptr = c.c_void_p()
        count = int(getip(c.byref(ptr)))
        if not 0 < count <= 32 or not ptr.value:
            raise RuntimeError('no registered relay address')
        own = c.c_uint32.from_address(ptr.value).value
        state.update(phase='lobby', channel={'own_id': own, 'local_game_port': 7777,
                     'app_id': 78731, 'transport': 'NetHookCore/Koeinm', 'hwnd': int(receiver.hwnd)})
        deadline = time.monotonic() + min(args.hold, 86400)
        while time.monotonic() < deadline:
            if time.time() - (folder / 'heartbeat').stat().st_mtime > 90:
                log({'ev': 'viewer_heartbeat_expired'})
                break
            command = read('request.json')
            if command.get('id') and command['id'] not in seen:
                # Persist reservation BEFORE native calls; never replay after
                # failure, crash, lost SSH reply or process restart.
                seen.add(command['id'])
                write('reserved.json', {'ids': sorted(seen)})
                result = {'id': command['id'], 'op': command.get('op'), 'wall': time.time()}
                stop = False
                try:
                    payload = request(command)
                    if command.get('session_id') != read('identity.json').get('session_id'):
                        raise ValueError('會話識別不符')
                    if not isinstance(command.get('wall'), (float, int)) or not 0 <= time.time()-command['wall'] <= 30:
                        raise ValueError('操作已過期')
                    if payload['op'] == 'join':
                        payload = reserve_join(payload, state)
                        state['phase'] = 'joining'
                        state['observed_at'] = time.time()
                        write('state.json', state)
                        log({'ev': 'open_session_enter', 'room_id': payload['room_id'], 'nickname': payload['nickname']})
                        rc = int(opens(payload['virtual_ip'].encode('ascii'), payload['session_name'].encode('gbk'),
                                       payload['nickname'].encode('gbk'), own, 3000))
                        joined = rc == 0
                        is_connected = bool(connected())
                        state.update(phase='room' if joined and is_connected else 'lobby', connected=is_connected,
                                     nickname=payload['nickname'], selected_room=payload if joined else None)
                        state['channel'].update(host_id=int(hostid()) if joined else None,
                                                target_virtual_ip=payload['virtual_ip'] if joined else None,
                                                open_rc=rc)
                        result.update(rc=rc, status='completed' if joined and is_connected else 'failed',
                                      detail='DLL 握手成功；未發玩家準備或戰局指令' if joined and is_connected else '房間未接受連接')
                    elif payload['op'] in ('leave', 'stop'):
                        rc = int(exits()) if joined or connected() else None
                        is_connected = bool(connected())
                        joined = is_connected
                        state.update(phase='room' if is_connected else 'lobby', connected=is_connected)
                        if not is_connected:
                            state['selected_room'] = None
                            state['channel'].update(host_id=None, target_virtual_ip=None, open_rc=None)
                        # ExitSession/End use BOOL-like returns (historical
                        # normal cleanup rc=1); verify actual local connection.
                        result.update(rc=rc, status='unknown' if is_connected else 'completed',
                                      detail='本端會話已退出；主機席位釋放未核實' if not is_connected else '本端仍顯示連接，未自動重試')
                        stop = payload['op'] == 'stop' and not is_connected
                    elif payload['op'] == 'search':
                        rc = do_search()
                        result.update(rc=rc, status='completed' if rc == 0 else 'failed')
                    else:
                        raise ValueError('此操作不可傳給探針')
                except Exception as error:
                    result.update(status='error', error=str(error)[:200])
                state['last_result'] = result
                write('result.json', result)
                log(dict(result, ev='room_control_result'))
                if stop:
                    break
            if not joined and time.monotonic() >= next_search:
                do_search()
            receiver.pump()
            is_connected = bool(connected())
            if joined and not is_connected:
                joined = False
                state.update(phase='disconnected', connected=False)
            if time.monotonic() >= next_save:
                state.update(observed_at=time.time(), connected=is_connected,
                             received=receiver.count, released=receiver.freed, receiver_errors=receiver.errors)
                write('state.json', state)
                next_save = time.monotonic() + 1
            time.sleep(.05)
    except Exception as error:
        state.update(error=type(error).__name__ + ': ' + str(error)[:200])
        log({'ev': 'session_error', 'error': state['error']})
    finally:
        if joined or started and connected():
            state['exit_rc'] = int(exits())
        if started:
            state['end_rc'] = int(end())
        receiver.close()
        state.update(phase='stopped', connected=False, observed_at=time.time())
        write('state.json', state)
        audit.close()


if __name__ == '__main__':
    main()
