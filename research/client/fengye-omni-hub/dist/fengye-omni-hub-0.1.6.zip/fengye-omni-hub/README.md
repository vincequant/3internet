# 風夜 · 全知情報 Hub 0.1.6

風夜的獨立原生桌面 Hub，沿用原版情報頁的呈現方式。玩家視角的全知來源已關閉：不讀取 Mac／Windows 玩家採集 API、不提供來源切換或玩家戰局檔案入口，也不複製原版來源設定。只有風夜收到的封包、同步記錄、聊天及回執作為情報來源；尚未還原的世界資料保持未知。原版 Hub 獨立安裝不受影響。

## 風夜操控台

1. 選擇線路，點「登入風夜大廳」。使用採集端已配置的風夜帳號及原版中繼取得自己的會話；不啟動遊戲。
2. 大廳就緒後，每 15 秒 SearchSession 取得房間列表，顯示房間、房主、虛擬 IP 及人數，也可手動更新。未收到回覆顯示未確認，不當成零房間。
3. 選一個房間，選擇或輸入「進房暱稱」，點「進入所選房間」。暱稱限 GBK 可表示、30 位元組，不接受空白或控制字元。只接受 60 秒內實際查房回覆中的房間，不允許直接指定任意 IP。
4. 面板顯示 OpenSession 原始回傳、本端／房主 ID、目標虛擬 IP、遊戲口、中繼 A／B 口及收包／釋放數。這是 DLL 連接握手，**不是玩家準備完成或開局成功**；本版不自動發 cmd2/cmd9、不參與同步或發戰局指令。進入可能佔據房間席位，房主開局前請退出。
5. 「退出房間」調用正常 ExitSession，返回大廳監控；「停止大廳」結束本 Hub 自己的會話。退出回執驗證本端 IsConnected，不把 BOOL 型回傳 1 當成錯誤，也不宣稱主機席位已釋放。

每條進退房請求先綁定會話、保留唯一 ID，再執行一次。等待回執或結果未知時不重發。視窗關閉後停止查房輪詢；本 Hub 啟動的探針在最多 90 秒內因視窗心跳到期正常收尾。

若採集端另有研究會話運行，復用唯一現有中繼查房，顯示「既有大廳中繼監控」；不重複登入、接管或終止別的會話。此時進退房按鈕停用，需原會話正常結束後才能啟動本 Hub 的獨立會話。

帳號和認證仍由採集端既有 P1／原版 loader 流程處理，不放入發行包或顯示握手通道。採集端需已配置 `~/sgi-protocol-lab-20260915`、Wine、32 位探針、P1／P39c2 loader 及 P28 接收模組。Mac／Windows 前端均經既有 SSH 連接採集端；此版未提供原生 Windows 採集代理。

## 情報與既有控制

保留風夜封包／同步記錄篩選、原生指令解讀、本地回放及原有研究探針的 chat／stop 回執。同步記錄使用原版解析器，不由差分補造指令或結算結果。新大廳會話和原有歷史 run 分別標示，不把歷史勢力快照當成本次握手。

## 啟動及驗證

- Mac：`啟動風夜Hub.command` 或 `python3 launch.py`。
- `python3 build_app.py` 更新原生 .app 入口。
- Windows：`启动风夜Hub.cmd`；需 Python、Tk、Pillow 和系統 SSH。
- `python3 run.py --replay /path/to/observation.json`：本地風夜回放，禁止 SSH、登入或進退房。

```sh
python3 -m unittest discover -s tests
python3 run.py --replay data/last-observation.json --verify-json data/fengye-only-verification.json --verify-exit
python3 build_dist.py
```

本次單元測試 19 項通過；Mac 原生視窗驗證玩家世界狀態未載入、玩家身份工具已隱藏。遠端 Wine 原生 smoke 驗證新探針 Start／自有 HWND／SearchSession／End 正常執行，receiver_errors=0；查房 rc=0，但此次未收到房間回覆。**新控制台完整登入→暱稱進房→握手→退出尚未實機驗收**：當前採集端已有研究會話，未中止或接管。Windows 前端通過 Python 3.8 語法檢查，未做原生 Windows GUI 實測。

發行包使用明確白名單及 SHA256，排除 data/、連線設定、憑據、快取、遊戲、存檔與執行環境。UPSTREAM.json 記錄複製時原版 SHA；RELEASE.json 記錄本副本與上游版本。
