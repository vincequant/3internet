"""The complete native OmniWindow with an additional Fengye console."""
import json
import queue
import subprocess
import sys
import time
import threading
import tkinter as tk
from datetime import datetime
from tkinter import ttk, messagebox, filedialog

from omni_window import OmniWindow, DAMASK, PANEL, WELL, INK, GOLD, GOLD_HI, MUTED, WARN, BG
from fengye_source import FengyeSource, feed_items, control_ready, mode_text, validate_control
from room_client import RoomClient
from backend.room_protocol import nickname


def wall_text(value):
    if not isinstance(value, (int, float)):
        return '—'
    try:
        return datetime.fromtimestamp(value).strftime('%m-%d %H:%M:%S')
    except (OSError, ValueError, OverflowError):
        return '—'


def dur_text(value):
    """Human duration for long-run listening windows; never negative."""
    try:
        seconds = int(max(0, float(value)))
    except (TypeError, ValueError):
        return '—'
    hours, rem = divmod(seconds, 3600)
    minutes = rem // 60
    if hours:
        return '{}時{:02d}分'.format(hours, minutes)
    if minutes:
        return '{}分'.format(minutes)
    return '{}秒'.format(rem)


def notify_operator(title, message, sound='Glass'):
    """摘席流程的本地提示：聲音＋系統通知。

    讓操作者在遊戲視窗在前時也能察覺「先勿按開始／可以按開始」。
    只在本機發出（macOS osascript/afplay）；不觸碰遊戲、會話或網路。
    """
    try:
        if sys.platform == 'darwin':
            safe_title = str(title).replace('"', ' ')
            safe_message = str(message).replace('"', ' ')
            subprocess.Popen(
                ['osascript', '-e',
                 'display notification "{}" with title "{}"'.format(safe_message, safe_title)],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            subprocess.Popen(
                ['afplay', '/System/Library/Sounds/{}.aiff'.format(sound)],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


class FengyeWindow(OmniWindow):
    def __init__(self, root, source=None):
        self.source = source or FengyeSource()
        self.messages = queue.Queue()
        self.jobs = queue.Queue(maxsize=1)
        self.view = self.source.view
        self.feed_filter = tk.StringVar(root, value='全部')
        self.query = tk.StringVar(root)
        self.control_busy = False
        self.cooldown = 0
        self.pending_id = None
        self.pending_run = None
        self.pending_uncertain = False
        self.render_signature = None
        self.render_error = None
        self.rooms = RoomClient(host=self.source.sources.host, replay=bool(self.source.sources.source_file))
        self.room_busy = False
        self.room_pending = None
        self.room_uncertain = False
        self.room_rows = {}
        self.room_signature = None
        self.retry = None
        self._init_wait_alerted = False
        super().__init__(root)
        root.title('風夜 · 全知情報 Hub 0.2.7')
        root.minsize(1120, 700)
        self.version_label.configure(text='風夜 0.2.7')
        self.identity_label.master.pack_forget()
        self.status.configure(text='玩家全知來源已關閉 · 僅風夜資料', fg='#ffd08a')
        self.coverage.configure(text='世界情報尚未由風夜封包完整還原；缺失資料保持未知。')
        top = self.version_label.master
        for w in top.winfo_children():
            if isinstance(w, tk.Label) and w.cget('text') == '全知情报':
                w.configure(text='風夜 · 全知情報')
        self.original_tabs = list(self.workspace.tabs())
        self.fengye_page = tk.Frame(self.workspace, bg=DAMASK)
        self.workspace.insert(0, self.fengye_page, text='風夜情報／操控台')
        self.fengye_book = ttk.Notebook(self.fengye_page)
        self.fengye_book.pack(fill='both', expand=True)
        self._build_intel()
        self._build_console()
        self._build_legacy()
        self._build_decoded()
        self.fengye_book.select(self.console_page)
        self.workspace.select(self.fengye_page)
        self.query.trace_add('write', lambda *_: self.render_feed())
        self.feed_filter.trace_add('write', lambda *_: self.render_feed())
        self.render_view(self.view)
        threading.Thread(target=self._fetch_fengye, daemon=True, name='fengye-evidence-reader').start()
        self.root.after(250, self._tick_fengye)

    def fetch(self):
        """Never start the inherited player API/evidence polling path."""
        return

    def tick(self):
        return

    def confirm_player(self, clear=False):
        return

    def pick_history_archive(self):
        return

    def clear_history_review(self):
        return

    def _apply_review(self, bundle):
        raise ValueError('玩家視角的全知檔案來源已關閉')

    def _page(self, title, index=None):
        page = tk.Frame(self.fengye_book, bg=DAMASK)
        if index is None:
            self.fengye_book.add(page, text=title)
        else:
            self.fengye_book.insert(index, page, text=title)
        return page

    def _text(self, parent, height=5):
        frame = tk.Frame(parent, bg=WELL)
        frame.pack(fill='both', expand=True, padx=8, pady=6)
        w = tk.Text(frame, height=height, bg=WELL, fg=INK, wrap='word', relief='flat',
                    font=(self.face, 11), state='disabled', padx=10, pady=8)
        scroll = ttk.Scrollbar(frame, command=w.yview)
        scroll.pack(side='right', fill='y')
        w.configure(yscrollcommand=scroll.set)
        w.pack(side='left', fill='both', expand=True)
        return w

    @staticmethod
    def _set_text(widget, text):
        if widget.get('1.0', 'end-1c') == text:
            return
        pos = widget.yview()[0]
        widget.configure(state='normal')
        widget.delete('1.0', 'end')
        widget.insert('1.0', text)
        widget.configure(state='disabled')
        widget.yview_moveto(pos)

    def _box(self, parent, title):
        return tk.LabelFrame(parent, text=title, bg=DAMASK, fg=GOLD, font=(self.face, 12, 'bold'))

    def _build_intel(self):
        self.intel_page = self._page('風夜情報', 0)
        bar = tk.Frame(self.intel_page, bg=PANEL)
        bar.pack(fill='x', padx=8, pady=8)
        self.mode_label = tk.Label(bar, bg=PANEL, fg=GOLD_HI, font=(self.face, 13, 'bold'), anchor='w')
        self.mode_label.pack(side='left', padx=12, pady=8)
        self.run_label = tk.Label(bar, bg=PANEL, fg='#eee3c5', font=(self.face, 11))
        self.run_label.pack(side='right', padx=12)
        self.target_label = tk.Label(self.intel_page, bg=DAMASK, fg=INK, font=(self.face, 11), anchor='w')
        self.target_label.pack(fill='x', padx=12)
        self.counter_label = tk.Label(self.intel_page, bg=DAMASK, fg=MUTED, font=(self.face, 10), anchor='w')
        self.counter_label.pack(fill='x', padx=12, pady=(4, 8))
        panes = tk.PanedWindow(self.intel_page, orient='horizontal', bg=DAMASK, sashwidth=9, bd=0)
        panes.pack(fill='both', expand=True, padx=8, pady=(0, 8))
        left = tk.Frame(panes, bg=DAMASK)
        right = tk.Frame(panes, bg=DAMASK)
        panes.add(left, width=720, minsize=480, stretch='always')
        panes.add(right, width=400, minsize=320, stretch='always')
        tools = tk.Frame(left, bg=DAMASK)
        tools.pack(fill='x', pady=(0, 6))
        self.feed_count = tk.Label(tools, text='情報 0', bg=DAMASK, fg=GOLD, font=(self.face, 12, 'bold'))
        self.feed_count.pack(side='left', padx=4)
        ttk.Combobox(tools, textvariable=self.feed_filter, values=['全部', '訊框', '遊戲數據', '聊天', '控制'],
                     state='readonly', width=9).pack(side='left', padx=8)
        tk.Entry(tools, textvariable=self.query, bg=WELL, fg=INK, width=18).pack(side='left', fill='x', expand=True)
        tk.Button(tools, text='清除', bg=BG, command=lambda: self.query.set('')).pack(side='left', padx=4)
        self.feed_tree = self.tree(left, [('time', '時間', 112), ('kind', '分類', 76),
                                          ('label', '收到的情報', 260), ('detail', '摘要', 310)])
        self.feed_tree.tag_configure('data', foreground='#225e54')
        self.feed_tree.tag_configure('control', foreground='#8a3030')
        self.feed_tree.tag_configure('chat', foreground='#325f86')
        self.feed_tree.bind('<<TreeviewSelect>>', self.select_feed)
        self.feed_detail = self._text(left, 4)
        snapshot_box = self._box(right, '會話席位 · 快照時點')
        snapshot_box.pack(fill='both', expand=True)
        self.snapshot_note = tk.Label(snapshot_box, bg=DAMASK, fg=MUTED, anchor='w', font=(self.face, 10))
        self.snapshot_note.pack(fill='x', padx=8, pady=4)
        self.snapshot_tree = self.tree(snapshot_box, [('seat', '席', 38), ('name', '玩家', 90),
                                                     ('faction', '勢力', 80), ('state', '狀態', 58)])
        self.snapshot_tree.configure(height=8)
        self.snapshot_tree.tag_configure('fengye', background='#f4df96', foreground='#85291c')
        d8_box = self._box(right, '旁聽回執')
        d8_box.pack(fill='x', pady=(8, 0))
        self.d8_label = tk.Label(d8_box, bg=DAMASK, fg=INK, anchor='w', justify='left',
                                 wraplength=350, font=(self.face, 11))
        self.d8_label.pack(fill='x', padx=10, pady=10)
        chat_box = self._box(right, '收到的聊天')
        chat_box.pack(fill='both', expand=True, pady=(8, 0))
        self.chat_log = self._text(chat_box, 5)

    def _build_console(self):
        self.console_page = self._page('風夜操控台', 1)
        self.console_state = tk.Label(self.console_page, text='未就緒', bg=PANEL, fg=GOLD_HI,
                                      font=(self.face, 15, 'bold'), anchor='w', padx=16, pady=12)
        self.console_state.pack(fill='x', padx=12, pady=8)
        self.control_book = ttk.Notebook(self.console_page)
        self.control_book.pack(fill='both', expand=True, padx=12, pady=(0, 10))
        self.room_control_page = tk.Frame(self.control_book, bg=DAMASK)
        self.chat_control_page = tk.Frame(self.control_book, bg=DAMASK)
        self.control_book.add(self.room_control_page, text='房間監控')
        self.control_book.add(self.chat_control_page, text='發言與回執')
        self._build_room_controls()
        tk.Label(self.chat_control_page, text='以風夜的名義發言', bg=DAMASK, fg=GOLD,
                 font=(self.face, 14, 'bold'), anchor='w').pack(fill='x', padx=18)
        self.chat_input = tk.Text(self.chat_control_page, height=4, wrap='word', bg=WELL, fg=INK,
                                  font=(self.face, 13), padx=12, pady=10)
        self.chat_input.pack(fill='x', padx=16, pady=8)
        buttons = tk.Frame(self.chat_control_page, bg=DAMASK)
        buttons.pack(fill='x', padx=16)
        self.chat_button = tk.Button(buttons, text='以風夜發言', bg=BG, fg=INK, command=self.send_chat)
        self.chat_button.pack(side='left')
        self.char_label = tk.Label(buttons, text='0 / 120 字 · GBK', bg=DAMASK, fg=MUTED)
        self.char_label.pack(side='left', padx=12)
        self.stop_button = tk.Button(buttons, text='風夜收線（令探針正常退出）', bg='#ead4c6', fg=WARN, command=self.send_stop)
        self.stop_button.pack(side='right')
        self.chat_input.bind('<<Modified>>', self.input_changed)
        self.control_result = tk.Label(self.chat_control_page, text='每條請求僅執行一次；失敗或結果未知時不自動重發。',
                                      bg=DAMASK, fg=MUTED, anchor='w', justify='left', wraplength=1050)
        self.control_result.pack(fill='x', padx=18, pady=10)
        panes = tk.PanedWindow(self.chat_control_page, orient='horizontal', bg=DAMASK, sashwidth=9)
        panes.pack(fill='both', expand=True, padx=12, pady=(0, 12))
        chats = self._box(panes, '聊天記錄')
        receipts = self._box(panes, '控制回執')
        panes.add(chats, minsize=360, stretch='always')
        panes.add(receipts, minsize=360, stretch='always')
        self.console_chat = self._text(chats, 10)
        self.control_log = self._text(receipts, 10)

    def _build_room_controls(self):
        box = self._box(self.room_control_page, '大廳房間監控與連接')
        box.pack(fill='both', expand=True, padx=10, pady=10)
        bar = tk.Frame(box, bg=DAMASK)
        bar.pack(fill='x', padx=8, pady=6)
        self.room_line = tk.StringVar(value='多线3')
        self.room_line_combo = ttk.Combobox(bar, textvariable=self.room_line, width=8,
                                          values=['多线2', '多线3'], state='readonly')
        self.room_line_combo.pack(side='left')
        self.room_start = tk.Button(bar, text='登入風夜大廳', bg=BG,
                                    command=lambda: self.room_action({'op': 'start', 'line': self.room_line.get()}))
        self.room_start.pack(side='left', padx=5)
        self.room_search = tk.Button(bar, text='更新房間', bg=BG,
                                     command=lambda: self.room_action({'op': 'search'}))
        self.room_search.pack(side='left')
        tk.Label(bar, text='進房暱稱', bg=DAMASK, fg=INK).pack(side='left', padx=(16, 5))
        self.room_nickname = tk.StringVar(value='風夜')
        self.room_nick_combo = ttk.Combobox(bar, textvariable=self.room_nickname, width=14,
                                          values=['風夜', '小白'], state='normal')
        self.room_nick_combo.pack(side='left')
        self.room_join = tk.Button(bar, text='進入所選房間（進房後自動註冊→摘席）', bg=BG, command=self.join_selected_room)
        self.room_join.pack(side='left', padx=5)
        self.room_leave = tk.Button(bar, text='退出房間', bg=BG,
                                    command=lambda: self.room_action({'op': 'leave'}))
        self.room_leave.pack(side='left')
        self.room_stop = tk.Button(bar, text='停止大廳', bg=BG,
                                   command=lambda: self.room_action({'op': 'stop'}))
        self.room_stop.pack(side='right', padx=5)
        flow = tk.Frame(box, bg=DAMASK)
        flow.pack(fill='x', padx=8, pady=(0, 4))
        tk.Label(flow, text='開局前流程', bg=DAMASK, fg=GOLD).pack(side='left', padx=(0, 8))
        self.room_register = tk.Button(flow, text='幽靈註冊（cmd2 無特徵）', bg=BG,
                                       command=self.register_ghost)
        self.room_register.pack(side='left')
        self.room_d8 = tk.Button(flow, text='開局前摘席（D8）', bg='#ead4c6', fg=WARN,
                                 command=self.withdraw_ghost)
        self.room_d8.pack(side='left', padx=8)
        self.room_retry = tk.Button(flow, text='↻ 一鍵重來', bg='#ead4c6', fg=WARN,
                                    command=self.one_click_retry)
        self.room_retry.pack(side='left')
        self.room_flow_label = tk.Label(flow, bg=DAMASK, fg=MUTED)
        self.room_flow_label.pack(side='left', padx=8)
        self.room_tree = self.tree(box, [('name', '房間', 160), ('host', '房主', 140),
                                       ('ip', '房間虛擬 IP', 160), ('count', '人數', 70)])
        self.room_tree.configure(height=4)
        self.room_tree.bind('<<TreeviewSelect>>', lambda _e: self.update_room_controls())
        self.room_status = tk.Label(box, bg=DAMASK, fg=MUTED, anchor='w', justify='left', wraplength=1100)
        self.room_status.pack(fill='x', padx=10, pady=4)
        self.room_channel = tk.Label(box, bg=WELL, fg=INK, anchor='w', justify='left', wraplength=1100)
        self.room_channel.pack(fill='x', padx=8, pady=(0, 6))
        self.room_receipt = tk.Label(box, text='登入後每 15 秒查房；進退房各執行一次。按「進入所選房間」會自動走完整套「加入→註冊（cmd2）→摘席（D8）」（各一次性、失敗不重試）；「摘席：已執行」出現前，請勿在遊戲按開始。摘席後風夜持續旁聽（上限 24 小時），結束時按「收線（結束旁聽）」。失敗後可按「↻ 一鍵重來」自動收尾重來。',
                                     bg=DAMASK, fg=MUTED, anchor='w', wraplength=1100)
        self.room_receipt.pack(fill='x', padx=10, pady=(0, 6))

    def join_selected_room(self):
        ids = self.room_tree.selection()
        row = self.room_rows.get(ids[0]) if ids else None
        if row is None and len(self.room_rows) == 1:
            row = next(iter(self.room_rows.values()))  # 只有一個房間：未選取也可直接進入
        if row is None:
            self.room_receipt.configure(text='請先在房間列表點選一個房間列，再按「進入所選房間」。')
            return
        try:
            name = nickname(self.room_nickname.get())
        except ValueError as error:
            self.room_receipt.configure(text=str(error))
            return
        self.room_action({'op': 'join', 'room_id': row['id'], 'nickname': name})

    def register_ghost(self):
        state = self.rooms.state
        if not (state.get('fresh') and state.get('connected')):
            return
        if not messagebox.askokcancel('幽靈註冊（cmd2）',
                                      '將以採集機器的名稱發送一次 cmd2（seq0 免檢通道）。\n'
                                      '房間名單會短暫出現一行無特徵成員；ACK 以序號推進為準。\n'
                                      '一次性、失敗不重試。確認執行？', parent=self.root):
            return
        self.room_action({'op': 'register'})

    def withdraw_ghost(self):
        state = self.rooms.state
        if not (state.get('fresh') and state.get('connected')):
            return
        if not messagebox.askokcancel('開局前摘席（D8）',
                                      '將以可靠通道發送一次 D8（自身離場）：\n'
                                      '應用層席位行消失，房間會出現一行「（暱稱）从游戏中退出了」；\n'
                                      'DLL 會話保持並繼續接收。僅在開局前（原生 state=1）可發。\n'
                                      '摘席後可長時間旁聽（會話上限 24 小時）；結束時按「收線（結束旁聽）」。\n'
                                      '一次性、失敗不重試。確認執行？', parent=self.root):
            return
        self.room_action({'op': 'd8'})

    def room_action(self, payload):
        if self.room_busy or self.room_pending or self.room_uncertain or self.source.sources.source_file:
            self.room_receipt.configure(text='上一個操作尚未完成，或上次結果未知（一次性原則），本次未送出。')
            return
        try:
            self.jobs.put_nowait(('room', payload))
        except queue.Full:
            self.room_receipt.configure(text='正在讀取狀態，請稍候。')
            return
        self.room_busy = True
        self.room_receipt.configure(text='正在執行一次操作，等待實際回執…')
        self.update_room_controls()

    def update_room_controls(self):
        if not hasattr(self, 'room_start'):
            return
        state = self.rooms.state
        writable = not self.source.sources.source_file and not (self.room_busy or self.room_pending or self.room_uncertain)
        fresh = state.get('fresh') and (state.get('external') or
            isinstance(state.get('observed_at'), (int, float)) and 0 <= time.time()-state['observed_at'] <= 20)
        lobby = fresh and state.get('phase') == 'lobby' and not state.get('connected')
        q = state.get('room_query') or {}
        observed = q.get('observed_at')
        listed = isinstance(observed, (int, float)) and 0 <= time.time()-observed <= 60
        registered = bool(state.get('ghost_registered'))
        withdrawn = bool(state.get('ghost_withdrawn'))
        native_state = state.get('native_sync_state')
        modes = ((self.room_start, not state.get('alive')),
                 (self.room_search, lobby or fresh and state.get('external')), (self.room_join, lobby and listed and (bool(self.room_tree.selection()) or len(self.room_rows) == 1)),
                 (self.room_leave, fresh and state.get('connected')), (self.room_stop, fresh and not state.get('external') and state.get('phase') != 'stopped'),
                 (self.room_register, fresh and state.get('connected') and not registered),
                 (self.room_d8, fresh and state.get('connected') and registered and not withdrawn
                  and native_state == 1))
        retrying = self.retry is not None
        for button, allowed in modes:
            button.configure(state='normal' if writable and allowed and not retrying else 'disabled')
        if hasattr(self, 'room_retry'):
            self.room_retry.configure(
                state='disabled' if self.source.sources.source_file else 'normal',
                text=('✕ 取消重來' if retrying else '↻ 一鍵重來'))
        init_wait = bool(state.get('host_init_wait'))
        if init_wait and state.get('connected') and not withdrawn and not self._init_wait_alerted:
            self._init_wait_alerted = True
            notify_operator('風夜：開始被提前按了', '主機已抓住席位，摘席無法完成——請按「↻ 一鍵重來」', sound='Basso')
        elif not init_wait or not state.get('connected') or withdrawn:
            self._init_wait_alerted = False
        self.room_stop.configure(text='收線（結束旁聽）' if withdrawn else '停止大廳',
                                 bg='#ead4c6' if withdrawn else BG)
        if fresh and state.get('connected') and registered and not withdrawn:
            if state.get('host_init_wait'):
                self.room_flow_label.configure(text='⛔ 摘席已鎖住（開始被提前按）——請按「↻ 一鍵重來」', fg='#a03028')
            else:
                self.room_flow_label.configure(text='⚠️ 摘席進行中（數秒）——請勿在遊戲按開始', fg=WARN)
        elif fresh and state.get('connected') and withdrawn:
            self.room_flow_label.configure(text='✅ 摘席已執行——現在可以按開始', fg='#2f6a4f')
        else:
            self.room_flow_label.configure(text='註冊：{}　摘席：{}　原生狀態：{}'.format(
                '已執行' if registered else '未執行',
                '已執行' if withdrawn else '未執行',
                'state=1（開局前）' if native_state == 1 else
                ('state={}'.format(native_state) if native_state is not None else '未知')), fg=MUTED)
        self.room_line_combo.configure(state='readonly' if writable and not state.get('alive') else 'disabled')
        self.room_nick_combo.configure(state='normal' if writable and not state.get('connected') else 'disabled')

    def render_rooms(self):
        state = self.rooms.state
        q = state.get('room_query') or {}
        signature = json.dumps(q, ensure_ascii=False, sort_keys=True)
        if signature != self.room_signature:
            selected = self.room_tree.selection()
            selected_id = self.room_rows.get(selected[0], {}).get('id') if selected else None
            self.room_tree.delete(*self.room_tree.get_children())
            self.room_rows = {}
            for row in q.get('rooms') or []:
                iid = self.room_tree.insert('', 'end', values=(row.get('name', '—'), row.get('host', '—'),
                    row.get('virtual_ip', '—'), '{}/{}'.format(row.get('current', '—'), row.get('maximum', '—'))))
                self.room_rows[iid] = row
                if row.get('id') == selected_id:
                    self.room_tree.selection_set(iid)
            self.room_signature = signature
        labels = {'idle': '尚未登入', 'starting': '正在登入', 'lobby': '大廳監控中',
                  'joining': '正在握手', 'room': '房間 DLL 握手已建立', 'stopped': '會話已停止',
                  'stale': '觀測過期', 'disconnected': '連接已斷開', 'external_lobby': '既有大廳中繼監控'}
        text = '{} · {} · 房間列表時間 {}{}'.format(labels.get(state.get('phase'), '未知'),
            state.get('line') or self.room_line.get(), wall_text(q.get('observed_at')),
            ' · 未收到房間回覆，不代表零房間' if q.get('status') == 'unconfirmed_empty' else '')
        if state.get('error'):
            text += ' · ' + str(state['error'])
        if q.get('error'):
            text += ' · ' + str(q['error'])
        self.room_status.configure(text=text)
        ch = state.get('channel') or {}
        register = state.get('register') or {}
        d8 = state.get('d8') or {}
        listen = ''
        if state.get('ghost_withdrawn') and isinstance(d8.get('wall'), (int, float)):
            listen = ' · 旁聽中 {}（收線上限 24 小時）'.format(dur_text(time.time()-d8['wall']))
        self.room_channel.configure(text='{}：本端 ID {} → 房主 ID {}／{}　遊戲口 {}　中繼 A {}／B {}　OpenSession rc={}\n暱稱：{} · 收包 {}／釋放 {} · 註冊 {} · 摘席 {}{}'.format(
            '目前握手通道' if state.get('fresh') and state.get('connected') else '通道記錄（未確認在線）',
            ch.get('own_id', '—'), ch.get('host_id') or '—', ch.get('target_virtual_ip') or '—',
            ch.get('local_game_port', '—'), ch.get('a_port') or '—', ch.get('b_port') or '—',
            ch.get('open_rc', '—'), state.get('nickname') or '—', state.get('received', 0), state.get('released', 0),
            ('cmd2 rc={}'.format(register.get('rc')) if state.get('ghost_registered') else '未執行'),
            ('D8 raw_rc={}'.format(d8.get('raw_rc')) if state.get('ghost_withdrawn') else '未執行'),
            listen))
        result = state.get('last_result') or {}
        if self.room_pending and result.get('id') == self.room_pending:
            self.room_receipt.configure(text='{} · {} · rc={} · {}'.format(result.get('op'),
                result.get('status'), result.get('rc', '—'), result.get('detail') or result.get('error') or wall_text(result.get('wall'))))
            self.room_pending = None
            self.room_uncertain = result.get('status') == 'unknown'
            self._maybe_chain(result)
            self._notify_room_result(result)
            self._maybe_retry(result)
        self.update_room_controls()

    def _notify_room_result(self, result):
        """0.2.5：摘席流程關鍵節點的本機提示（遊戲視窗在前也看得到）。"""
        op, status = result.get('op'), result.get('status')
        if op == 'join' and status == 'completed':
            notify_operator('風夜：已進房', '自動註冊→摘席進行中——先勿按開始', sound='Ping')
        elif op == 'd8' and status == 'completed':
            notify_operator('風夜：摘席已執行', '現在可以在遊戲按開始', sound='Glass')
        elif op == 'd8' and status == 'error':
            reason = str(result.get('error') or result.get('detail') or '請依訊息重做流程')
            if '開局等待' not in reason:
                notify_operator('風夜：摘席未執行', reason[:90], sound='Basso')

    def _maybe_chain(self, result):
        if result.get('status') != 'completed':
            return
        state = self.rooms.state
        op = result.get('op')
        if op == 'join' and state.get('connected') and not state.get('ghost_registered') and not state.get('ghost_withdrawn'):
            self.room_receipt.configure(text='一鍵流程：已進房，0.8 秒後自動註冊（cmd2）…')
            self.root.after(800, lambda: self._chain_fire('register'))
        elif op == 'register' and state.get('ghost_registered') and not state.get('ghost_withdrawn'):
            self.room_receipt.configure(text='一鍵流程：已註冊，0.8 秒後自動摘席（D8）…')
            self.root.after(800, lambda: self._chain_fire('d8'))

    def _chain_fire(self, op):
        self.room_action({'op': op})

    def one_click_retry(self):
        """失敗後一鍵收尾重來：退房→收線→重登→查房→進入（接手自動註冊→摘席）。"""
        if self.source.sources.source_file:
            return
        if self.retry is not None:
            self.retry = None
            self.room_receipt.configure(text='已取消「一鍵重來」流程；當前操作恢復正常。')
            return
        state = self.rooms.state
        steps = []
        if state.get('connected'):
            steps.append('leave')
        if state.get('alive') or state.get('fresh'):
            steps.append('stop')
        steps += ['wait_teardown', 'start', 'wait_lobby', 'search', 'wait_rooms']
        self.retry = {'steps': steps, 'deadline': time.monotonic() + 150, 'start_retries': 0}
        self.room_receipt.configure(text='一鍵重來：開始收尾（遊戲端若顯示「等待風夜」請讓它失敗／按掉取消）…')
        self.retry_next()

    def retry_next(self):
        """推進「一鍵重來」流程；每步只發一次操作，結果經 _maybe_retry 續行。"""
        if self.retry is None:
            return
        if time.monotonic() > self.retry.get('deadline', 0):
            self.retry = None
            self.room_receipt.configure(text='一鍵重來：逾時中止；請檢查狀態後再試。')
            return
        if self.room_uncertain:
            self.retry = None
            self.room_receipt.configure(text='一鍵重來：上次操作結果未知（一次性原則），已中止；請核實後再試。')
            return
        if self.room_busy or self.room_pending:
            return
        steps = self.retry['steps']
        if not steps:
            self.retry = None
            self.room_receipt.configure(text='一鍵重來：已送出「進入」——等 Glass 提示音（摘席已執行）後再按開始。')
            return
        step = steps[0]
        state = self.rooms.state
        if step == 'leave':
            self.retry['steps'] = steps[1:]
            self.room_action({'op': 'leave'})
            self.room_receipt.configure(text='一鍵重來：退出房間…（遊戲端的等待畫面請按掉取消）')
        elif step == 'stop':
            self.retry['steps'] = steps[1:]
            self.room_action({'op': 'stop'})
            self.room_receipt.configure(text='一鍵重來：收線（結束舊會話）…')
        elif step == 'wait_teardown':
            if not state.get('alive') and not state.get('fresh'):
                self.retry['steps'] = steps[1:]
                self.room_receipt.configure(text='一鍵重來：舊鏈已退出，重新登入…')
                self.retry_next()
        elif step == 'start':
            self.retry['steps'] = steps[1:]
            self.room_action({'op': 'start', 'line': self.room_line.get()})
            self.room_receipt.configure(text='一鍵重來：重新登入風夜大廳…')
        elif step == 'wait_lobby':
            if state.get('fresh') and state.get('alive') and state.get('phase') == 'lobby':
                self.retry['steps'] = steps[1:]
                self.retry_next()
        elif step == 'search':
            self.retry['steps'] = steps[1:]
            self.room_action({'op': 'search'})
            self.room_receipt.configure(text='一鍵重來：大廳就緒，查房中…')
        elif step == 'wait_rooms':
            if not (state.get('fresh') and state.get('phase') == 'lobby'):
                return
            q = state.get('room_query') or {}
            observed = q.get('observed_at')
            if not isinstance(observed, (int, float)) or time.time() - observed > 60:
                return
            rooms = q.get('rooms') or []
            self.retry['steps'] = []
            if len(rooms) == 1:
                row = rooms[0]
                try:
                    name = nickname(self.room_nickname.get())
                except ValueError as error:
                    self.retry = None
                    self.room_receipt.configure(text=str(error))
                    return
                self.room_action({'op': 'join', 'room_id': row['id'], 'nickname': name})
                self.room_receipt.configure(text='一鍵重來：進入「{}」——等 Glass 提示音後再按開始…'.format(row.get('name') or row.get('id')))
            elif not rooms:
                self.retry = None
                self.room_receipt.configure(text='一鍵重來：查房沒有房間——請先在遊戲重開房間，再按「一鍵重來」。')
            else:
                self.retry = None
                self.room_receipt.configure(text='一鍵重來：查到多個房間，請在列表選房後按「進入」。')

    def _maybe_retry(self, result):
        if self.retry is None:
            return
        op, status = result.get('op'), result.get('status')
        if op == 'start':
            if status == 'started':
                self.retry_next()
            elif self.retry.get('start_retries', 0) < 2:
                self.retry['start_retries'] = self.retry.get('start_retries', 0) + 1
                self.retry['steps'].insert(0, 'start')
                self.room_receipt.configure(text='一鍵重來：重新登入暫未成功，4 秒後再試一次…')
                self.root.after(4000, self.retry_next)
            else:
                self.retry = None
                self.room_receipt.configure(text='一鍵重來：重新登入失敗——' + str(result.get('error') or status))
            return
        if op in ('leave', 'stop', 'search') and status in ('completed', 'error'):
            # 收尾步驟失敗不致命（可能已斷線／已停止）：繼續下一步。
            self.retry_next()
        elif op == 'join':
            self.retry_next()

    def _build_legacy(self):
        self.legacy_page = self._page('房間與來源記錄', 2)
        bar = tk.Frame(self.legacy_page, bg=DAMASK)
        bar.pack(fill='x', padx=12, pady=8)
        self.room_button = tk.Button(bar, text='讀取房間列表', bg=BG, command=lambda: self.request_refresh(search=True))
        self.room_button.pack(side='left')
        tk.Button(bar, text='開啟本地回放…', bg=BG, command=self.pick_replay).pack(side='left', padx=8)
        tk.Label(bar, text='查詢不入座；舊記錄保留原時間', bg=DAMASK, fg=MUTED).pack(side='left', padx=8)
        self.legacy_book = ttk.Notebook(self.legacy_page)
        self.legacy_book.pack(fill='both', expand=True, padx=12, pady=(0, 12))
        self.legacy_texts = {}
        for key, title in [('rooms', '房間'), ('members', '成員'), ('events', '事件'),
                           ('directory', '線路目錄'), ('source', '會話與採集來源')]:
            page = tk.Frame(self.legacy_book, bg=DAMASK)
            self.legacy_book.add(page, text=title)
            self.legacy_texts[key] = self._text(page, 14)

    def _build_decoded(self):
        self.decoded_page = self._page('風夜指令解讀')
        tk.Label(self.decoded_page, text='使用原版 Hub 的原生封包解析器。發送者 ID 與指令內勢力 ID 分開；未證明結算結果。',
                 bg=DAMASK, fg=MUTED, anchor='w', wraplength=1050).pack(fill='x', padx=12, pady=10)
        self.decoded_tree = self.tree(self.decoded_page, [('time', '收到時間', 140), ('round', '同步輪', 70),
                                     ('sender', '會話發送者', 130), ('force', '勢力 ID', 80),
                                     ('action', '指令', 140), ('value', '參數', 130), ('status', '解析狀態', 250)])
        self.decoded_note = tk.Label(self.decoded_page, text='', bg=DAMASK, fg=MUTED, anchor='w')
        self.decoded_note.pack(fill='x', padx=12, pady=8)

    # Keep the complete original polling/rendering path. Fengye has a separate
    # worker and queue, so an offline probe never replaces a valid world state.
    def _fetch_fengye(self):
        job = ('refresh', False)
        while not self.stop.is_set():
            op, payload = job
            try:
                if op == 'room':
                    result = self.rooms.call(payload)
                    self.messages.put(('room_result', result))
                if op == 'control':
                    try:
                        result = self.source.send(payload)
                    except Exception:
                        result = {'status': 'error', 'error': '控制結果未知；未重試'}
                    self.messages.put(('control', result))
            except Exception:
                self.messages.put(('error', '操作失敗；保留最後記錄'))
            # 2026-10-17：資料讀取與大廳心跳分開執行——資料通道失敗或超時時，
            # 房間監控（維持探針心跳）仍必須繼續，避免探針因心跳到期誤收尾。
            try:
                self.messages.put(('view', self.source.refresh(search=(op == 'refresh' and payload))))
            except Exception:
                self.messages.put(('error', '讀取失敗；保留最後記錄'))
            try:
                self.rooms.call({'op': 'status'})
                self.messages.put(('rooms', None))
            except Exception:
                pass
            self.messages.put(('idle', None))
            while not self.stop.is_set():
                try:
                    job = self.jobs.get(timeout=.25)
                    break
                except queue.Empty:
                    if self.stop.wait(.25):
                        return
                    # Poll only while this native window exists. 房間操作待回執時
                    # 加快輪詢（5s→1s），縮短一鍵流程的暴露窗口。
                    interval = 1 if (self.room_busy or self.room_pending) else 5
                    if time.monotonic() - getattr(self, '_last_poll', 0) >= interval:
                        job = ('refresh', False)
                        break
            self._last_poll = time.monotonic()

    def request_refresh(self, search=False):
        if self.stop.is_set():
            return
        try:
            self.jobs.put_nowait(('refresh', search))
        except queue.Full:
            pass

    def _tick_fengye(self):
        try:
            while True:
                kind, value = self.messages.get_nowait()
                if kind == 'view':
                    self.view = value
                    self.render_view(value)
                elif kind == 'control':
                    self.control_busy = False
                    if value.get('status') == 'sent':
                        self.pending_id = value.get('id')
                        self.control_result.configure(text='請求已寫入 · {} · 等待探針回執，尚未確認執行'.format(self.pending_id))
                        if value.get('op') == 'chat':
                            self.chat_input.delete('1.0', 'end')
                    else:
                        self.pending_uncertain = True
                        self.control_result.configure(text='{} · 未自動重試；關閉或重新核實前不再送出。'.format(value.get('error') or value.get('status')))
                elif kind == 'room_result':
                    self.room_busy = False
                    if value.get('status') == 'sent':
                        self.room_pending = value.get('id')
                        self.room_receipt.configure(text='請求已送出，等待探針執行回執：' + str(self.room_pending))
                    else:
                        self.room_uncertain = value.get('status') == 'unknown'
                        self.room_receipt.configure(text=value.get('error') or ('大廳會話已啟動' if value.get('status') == 'started' else str(value.get('status'))))
                        self._maybe_retry(value)
                    self.render_rooms()
                elif kind == 'rooms':
                    self.render_rooms()
                elif kind == 'error':
                    self.mode_label.configure(text=value)
                elif kind == 'idle':
                    self.reload_btn.configure(state='normal')
        except queue.Empty:
            pass
        except Exception as error:
            self.render_error = str(error)
            print('fengye-render', error, flush=True)
        self.update_control_state()
        self.update_room_controls()
        if self.retry is not None:
            try:
                self.retry_next()
            except Exception:
                self.retry = None
        if not self.stop.is_set():
            self.root.after(250, self._tick_fengye)

    def render_view(self, view):
        p = view.get('p34') or {}
        session = view.get('session') or {}
        c = p.get('counters') or {}
        host = view.get('host') or {}
        self.mode_label.configure(text=mode_text(view))
        self.run_label.configure(text=p.get('run_name') or '尚無本局會話')
        if session:
            room = host.get('session') or ('大廳中 · 未入房' if session.get('phase') in ('lobby', 'starting', 'joining') else '未入房')
            self.target_label.configure(text='房間：{}　虛擬 IP：{}　線路：{}　最後資料：{}'.format(
                room, host.get('virtual_ip') or '—', view.get('line') or session.get('line') or '—',
                wall_text(c.get('last_packet_wall'))))
        else:
            self.target_label.configure(text='房間：未加入本局會話　虛擬 IP：—　線路：{}　最後資料：{}'.format(
                view.get('line') or '—', wall_text(c.get('last_packet_wall'))))
        self.counter_label.configure(text='收幀 {}　釋放 {}　錯誤 {}　同步 {} 輪　D8 後 {} 幀'.format(
            c.get('received', '—'), c.get('released', '—'), c.get('errors', '—'), c.get('rounds', '—'), c.get('received_after_d8', '—')))
        signature = json.dumps({k: view.get(k) for k in ('p34', 'host', 'members', 'events', 'directory', 'room_query', 'chain', 'source', 'ghost', 'collector')}, ensure_ascii=False, sort_keys=True)
        if signature != self.render_signature:
            self.render_feed()
            self.snapshot_tree.delete(*self.snapshot_tree.get_children())
            snapshots = p.get('snapshots') or {}
            block = snapshots.get('start') or snapshots.get('initial') or {}
            for r in block.get('rows') or []:
                name = r.get('name') or ('電腦' if r.get('state42') == 2 else '空席' if not r.get('id') else '未命名')
                self.snapshot_tree.insert('', 'end', values=(r.get('i', '—'), name, r.get('faction') or '—', r.get('state42', '—')),
                                          tags=('fengye',) if name in ('风夜', '風夜') else ())
            self.snapshot_note.configure(text=(
                ('cmd{} · {} · 本局會話快照'.format(block.get('cmd', '—'), wall_text(block.get('observed_at')))
                 if block.get('rows') else '本局尚未收到開局快照（cmd3／cmd7）。')
                if session else
                ('cmd{} · {} · 非即時'.format(block.get('cmd', '—'), wall_text(block.get('observed_at')))
                 if block.get('rows') else '尚無快照資料。')))
            chats = (p.get('chat') or {}).get('messages') or []
            chat_text = '\n\n'.join('{}　{}\n{}'.format(wall_text(m.get('wall')),
                m.get('sender_name') or '—', str(m.get('text') or '—')) for m in chats) or (
                '本局尚無聊天記錄。' if session else '目前沒有可核實的聊天記錄。')
            self._set_text(self.chat_log, chat_text)
            self._set_text(self.console_chat, chat_text)
            events = (p.get('control') or {}).get('events') or []
            self._set_text(self.control_log, '\n\n'.join('{}　{}\n{}{}{}'.format(
                wall_text(e.get('wall')), e.get('ev') or '', e.get('text') or '',
                ' · rc=' + str(e['rc']) if e.get('rc') is not None else '',
                ' · ' + str(e['reason']) if e.get('reason') else '') for e in reversed(events)) or '尚無控制回執。')
            self.render_legacy(view)
            self.render_decoded(view)
            self.render_signature = signature
        d8 = p.get('d8') or {}
        if session:
            if d8.get('sent_once'):
                d8_text = ('D8：已發一次 · raw_rc={}\nDLL 會話保持；行消隱未由主機側核實\n回執時間：{}\n旁聽：{}'.format(
                    d8.get('raw_rc', '—'), wall_text(d8.get('sent_wall')),
                    '本局會話保持中（上限 24 小時）' if session.get('alive') else '會話目前已停止'))
            elif session.get('ghost_registered'):
                d8_text = 'D8：尚未執行（已註冊 cmd2，等待摘席）'
            else:
                d8_text = 'D8：尚未執行（本局尚未註冊）'
            if session.get('host_init_wait'):
                d8_text += '\n注意：主機已把本席位拉入開局等待（已有人按了開始）。'
            self.d8_label.configure(text=d8_text)
        else:
            effect = d8.get('effect') or {}
            row = effect.get('row_present')
            effect_text = '應用行仍在' if row is True else '觀測時應用行已消失' if row is False else '行消隱效果未知'
            w = p.get('window') or {}
            longrun = p.get('longrun') or {}
            health = longrun.get('health') or {}
            extra = []
            remaining = None
            if isinstance(w.get('end_wall'), (int, float)):
                remaining = w['end_wall'] - time.time()
            elif isinstance(health.get('observe_remaining'), (int, float)):
                remaining = health['observe_remaining']
            if longrun.get('listen_started_wall') or health:
                line = '旁聽：' + ('剩餘約 {}'.format(dur_text(remaining))
                                  if remaining is None or remaining > 0 else '觀察窗已滿')
                if health:
                    if health.get('connected') is not None:
                        line += ' · 連線{}'.format('正常' if int(health.get('connected') or 0) == 1 else '中斷')
                    line += ' · 收包 {}'.format(health.get('packets', '—'))
                    if isinstance(health.get('last_activity_age'), (int, float)):
                        line += ' · 最後活動 {}前'.format(dur_text(health['last_activity_age']))
                extra.append(line)
            if longrun.get('end_reason'):
                extra.append('收線：{}（收尾觀察{}）'.format(
                    longrun['end_reason'], '已記錄' if longrun.get('tail_recorded') else '未記錄'))
            detail_text = ('\n' + '\n'.join(extra)) if extra else ''
            self.d8_label.configure(text='D8：{} · raw_rc={}\n{}\n原回執：{}\n觀察窗結束：{}{}'.format(
                '已發一次' if d8.get('sent_once') else '未證已發', d8.get('raw_rc', '—'), effect_text,
                wall_text(d8.get('sent_wall')), wall_text(w.get('end_wall')), detail_text))
        control = p.get('control') or {}
        last = control.get('last_result') or {}
        if self.pending_id and last.get('id') == self.pending_id:
            self.control_result.configure(text='已收到執行回執 · {} · rc={} · {}'.format(last.get('op'), last.get('rc'), wall_text(last.get('wall'))))
            self.pending_id = None
        if self.pending_run and p.get('run_name') != self.pending_run:
            self.pending_id = None
            self.pending_uncertain = False
            self.control_result.configure(text='已切換 run；先前請求不會重發。')
            self.pending_run = None
        self.update_control_state()

    def render_feed(self):
        if not hasattr(self, 'feed_tree'):
            return
        all_items = feed_items(self.view)
        kind = {'訊框': 'frame', '遊戲數據': 'data', '聊天': 'chat', '控制': 'control'}.get(self.feed_filter.get())
        query = self.query.get().strip().lower()
        items = [r for r in all_items if (not kind or r['kind'] == kind)
                 and (not query or query in (r['label'] + ' ' + r['detail']).lower())]
        selected = self.feed_tree.selection()
        old_key = self.feed_rows.get(selected[0]) if selected and hasattr(self, 'feed_rows') else None
        pos = self.feed_tree.yview()[0]
        self.feed_tree.delete(*self.feed_tree.get_children())
        self.feed_rows = {}
        names = {'frame': '訊框', 'data': '遊戲數據', 'chat': '聊天', 'control': '控制'}
        for i, row in enumerate(items):
            key = str(i)
            self.feed_rows[key] = row
            self.feed_tree.insert('', 'end', iid=key, values=(wall_text(row['wall']), names[row['kind']], row['label'], row['detail'].split('\n')[0]), tags=(row['kind'],))
            if row == old_key:
                self.feed_tree.selection_set(key)
        self.feed_tree.yview_moveto(pos)
        self.feed_count.configure(text='情報 {} / {}'.format(len(items), len(all_items)))
        if not self.feed_tree.selection():
            self._set_text(self.feed_detail, '選取一條情報查看細節。' if items else '此篩選沒有情報；未補入示範內容。')

    def select_feed(self, _=None):
        selected = self.feed_tree.selection()
        if selected:
            r = self.feed_rows.get(selected[0])
            if r:
                self._set_text(self.feed_detail, '{}　{}\n{}'.format(wall_text(r['wall']), r['label'], r['detail']))

    def render_legacy(self, v):
        q = v.get('room_query') or {}
        room_text = '狀態：{}　觀測：{}\n{}\n\n'.format(q.get('status', '未知'), wall_text(q.get('observed_at')), q.get('error') or '房間回覆不證明已開局。')
        room_text += '\n'.join('{}　{}　{}　{}/{}'.format(r.get('name') or '—', r.get('host') or '—', r.get('virtual_ip') or '—', r.get('current', '—'), r.get('maximum', '—')) for r in q.get('rooms') or []) or '尚無房間回覆；不作零房間判斷。'
        self._set_text(self.legacy_texts['rooms'], room_text)
        self._set_text(self.legacy_texts['members'], '主機 DLL 表觀測；與開局快照分開。\n\n' + ('\n'.join(
            '{}　ID {}　重連 {}　失敗 {}'.format(r.get('name') or '—', r.get('id', '—'), r.get('reconnecting', '—'), r.get('failed', '—')) for r in v.get('members') or []) or '尚無成員觀測。'))
        self._set_text(self.legacy_texts['events'], '\n'.join('{}　{}　{}'.format(wall_text(e.get('wall')), e.get('ev') or '', e.get('label') or '') for e in reversed(v.get('events') or [])) or '尚無事件。')
        directory = v.get('directory') or {}
        self._set_text(self.legacy_texts['directory'], '歷史目錄 · {}\n\n'.format(wall_text(directory.get('observed_at'))) + '\n'.join(
            '{}　{}:{}'.format(r.get('name') or '—', r.get('server') or '未知', r.get('port', '—')) for r in directory.get('lines') or []))
        # Render only public fields, never stringify raw backend dictionaries.
        source = v.get('source') or {}
        collector = v.get('collector') or {}
        ghost = v.get('ghost') or {}
        self._set_text(self.legacy_texts['source'], '模式：{}\nrun：{}\n來源觀測：{}\n採集：{}\n風夜：{}\n\n進程鏈\n{}\n\n僅讀風夜探針既有記錄；未啟動記憶體採集橋。'.format(
            mode_text(v), source.get('run_name') or '未知', wall_text(source.get('observed_at')),
            collector.get('mode') or '未知', ghost.get('state') or '未知',
            '\n'.join('{} · PID {}'.format(r.get('role') or '未知', r.get('pid', '—')) for r in v.get('chain') or []) or '未取得'))

    def input_changed(self, _=None):
        if not self.chat_input.edit_modified():
            return
        self.chat_input.edit_modified(False)
        text = self.chat_input.get('1.0', 'end-1c')
        try:
            text.encode('gbk')
            valid = len(text) <= 120
            suffix = 'GBK' if valid else '超過字數上限'
        except UnicodeEncodeError:
            valid = False
            suffix = '含 GBK 不支援字元'
        self.char_label.configure(text='{} / 120 字 · {}'.format(len(text), suffix), fg=MUTED if valid else WARN)
        self.update_control_state()

    def update_control_state(self):
        if not hasattr(self, 'console_state'):
            return
        ready = control_ready(self.view)
        p = self.view.get('p34') or {}
        pending = self.pending_id or (p.get('control') or {}).get('pending')
        enabled = ready and not self.control_busy and not pending and not self.pending_uncertain and time.monotonic() >= self.cooldown
        lobby = self.rooms.state
        if self.source.sources.source_file:
            headline = '本地回放 · 大廳與控制已停用'
        elif lobby.get('fresh'):
            if lobby.get('connected') and lobby.get('ghost_registered') and not lobby.get('ghost_withdrawn'):
                if lobby.get('host_init_wait'):
                    headline = '⛔ 開始被提前按了——摘席已鎖住；請按「↻ 一鍵重來」'
                else:
                    headline = '⚠ 已進房·摘席進行中——請勿按開始'
            elif lobby.get('connected') and lobby.get('ghost_withdrawn'):
                headline = '✅ 摘席已執行·旁聽中——可以按開始'
            else:
                headline = '大廳房間監控 · ' + ('既有中繼' if lobby.get('external') else '風夜獨立會話')
        else:
            headline = '風夜操控台 · 選線路登入大廳；查房後選暱稱進入'
        self.console_state.configure(text=headline)
        try:
            validate_control({'op': 'chat', 'text': self.chat_input.get('1.0', 'end-1c')})
            text_valid = True
        except ValueError:
            text_valid = False
        self.chat_button.configure(state='normal' if enabled and text_valid else 'disabled')
        self.stop_button.configure(state='normal' if enabled else 'disabled')
        transport = self.view.get('transport') or {}
        self.room_button.configure(state='normal' if transport.get('status') == 'online' and not self.source.sources.source_file else 'disabled')

    def send_control(self, payload):
        if not control_ready(self.view) or self.control_busy or self.pending_id or self.pending_uncertain or (self.view.get('p34') or {}).get('control', {}).get('pending') or time.monotonic() < self.cooldown:
            return
        try:
            payload = validate_control(payload)
        except ValueError as error:
            messagebox.showerror('無法送出', str(error), parent=self.root)
            return
        try:
            self.jobs.put_nowait(('control', payload))
        except queue.Full:
            self.control_result.configure(text='正在讀取狀態；本次未送出，請稍候。')
            return
        self.control_busy = True
        self.pending_run = (self.view.get('p34') or {}).get('run_name')
        self.cooldown = time.monotonic() + 2
        self.control_result.configure(text='送出單次請求中；不會自動重試。')
        self.update_control_state()

    def send_chat(self):
        self.send_control({'op': 'chat', 'text': self.chat_input.get('1.0', 'end-1c')})

    def send_stop(self):
        if not control_ready(self.view) or self.control_busy:
            return
        if messagebox.askokcancel('風夜收線（正常退出）',
                                  '確認令風夜收線（正常退出自己的會話）？\n'
                                  '長局模式下，收線後編排器會保留 60 秒主機側收尾觀察；\n'
                                  '退出後需另行啟動探針。', parent=self.root):
            self.send_control({'op': 'stop'})

    def pick_replay(self):
        path = filedialog.askopenfilename(parent=self.root, title='開啟風夜觀測 JSON', filetypes=[('JSON', '*.json')])
        if path:
            # Open a separate viewer; do not replace a source under an in-flight
            # control request or lose the original view's pending receipt.
            import subprocess, sys
            from pathlib import Path
            subprocess.Popen([sys.executable, str(Path(__file__).with_name('run.py')), '--replay', path])

    def render_decoded(self, view):
        from fengye_source import decoded_commands
        self.decoded_tree.delete(*self.decoded_tree.get_children())
        rows = decoded_commands(view)
        for r in rows:
            self.decoded_tree.insert('', 'end', values=(wall_text(r.get('wall')), r.get('round', '—'),
                r.get('sender', '—'), r.get('actor_force_id', '—'), r.get('action', '未解碼'),
                r.get('value_raw', '—'), r.get('error') or '原始指令已解讀／結算未確認'))
        self.decoded_note.configure(text='{} 條同步記錄；使用原版解析器，不由指令推造兵力或資源。'.format(len(rows)))
