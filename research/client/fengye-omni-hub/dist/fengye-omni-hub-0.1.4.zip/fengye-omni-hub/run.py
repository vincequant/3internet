#!/usr/bin/env python3
"""Launch the native Fengye Hub. No browser, HTTP server, or game startup."""
import argparse
import json
import os
from pathlib import Path
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent
for folder in (ROOT, ROOT / 'app', ROOT / 'bridge'):
    sys.path.insert(0, str(folder))
# Ignore source overrides used by another Hub process or shell session.
os.environ['SGI_CONNECTION_CONFIG'] = str(ROOT / 'connection.local.json')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--replay', help='Read an existing raw observation JSON; controls stay disabled')
    parser.add_argument('--data-dir')
    parser.add_argument('--verify-json', help='Write native widget verification, without sending controls')
    parser.add_argument('--verify-exit', action='store_true')
    args = parser.parse_args()
    import tkinter as tk
    from mac_light_theme import apply_light_defaults
    from display_layout import configure
    from dock_icon import apply
    from fengye_source import FengyeSource, feed_items, control_ready, mode_text
    from native_window import FengyeWindow
    # File viewers get a disposable cache, so they cannot replace live caches.
    cache = tempfile.TemporaryDirectory(prefix='fengye-replay-') if args.replay else None
    try:
        source = FengyeSource(data_dir=(cache.name if cache else args.data_dir), replay=args.replay)
        root = tk.Tk()
        apply_light_defaults(root)
        configure(root)
        apply(root, 'hub')
        app = FengyeWindow(root, source)
        def close():
            app.stop.set()
            root.destroy()
        root.protocol('WM_DELETE_WINDOW', close)
        from graceful_shutdown import install
        install(root, close)
        if args.verify_json:
            started = time.monotonic()
            def verify():
                if source.sources.transport['status'] == 'not_checked' and time.monotonic() - started < 30:
                    root.after(250, verify)
                    return
                root.update_idletasks()
                record = {'title': root.title(), 'viewable': bool(root.winfo_viewable()),
                          'frontend': 'native-tk', 'run': (app.view.get('p34') or {}).get('run_name'),
                          'mode': mode_text(app.view), 'feed_count': len(app.feed_tree.get_children()),
                          'total_feed_count': len(feed_items(app.view)),
                          'snapshot_rows': [list(app.snapshot_tree.item(i, 'values')) for i in app.snapshot_tree.get_children()],
                          'control_ready': control_ready(app.view), 'chat_button': str(app.chat_button.cget('state')),
                          'stop_button': str(app.stop_button.cget('state')), 'render_error': app.render_error,
                          'workspace_tabs': [app.workspace.tab(i, 'text') for i in app.workspace.tabs()],
                          'legacy_tabs': [app.legacy_book.tab(i, 'text') for i in app.legacy_book.tabs()],
                          'selected_tab': app.workspace.tab(app.workspace.select(), 'text'),
                          'data_source': 'fengye-only', 'upstream_state_loaded': app.doc is not None}
                # Exercise actual filtering and selection in the Tk widgets.
                app.feed_filter.set('遊戲數據')
                record['data_filter_count'] = len(app.feed_tree.get_children())
                if app.feed_tree.get_children():
                    app.feed_tree.selection_set(app.feed_tree.get_children()[0])
                    app.select_feed()
                    record['data_detail'] = app.feed_detail.get('1.0', 'end-1c')
                app.feed_filter.set('全部')
                app.workspace.select(app.console_page)
                root.update_idletasks()
                record['console_viewable'] = bool(app.console_state.winfo_viewable())
                app.workspace.select(app.intel_page)
                root.update_idletasks()
                out = Path(args.verify_json)
                out.parent.mkdir(parents=True, exist_ok=True)
                out.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')
                if args.verify_exit:
                    close()
            root.after(1500, verify)
        root.mainloop()
    finally:
        if cache:
            cache.cleanup()


if __name__ == '__main__':
    main()
