"""Fengye-only source adapter. No HTTP listener and no memory collector."""
import importlib.util
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('fengye_backend', ROOT / 'backend/server.py')
backend = importlib.util.module_from_spec(spec)
spec.loader.exec_module(backend)

CMD_NAMES = {0: '玩家通知', 3: '初始快照', 6: '劇本請求', 7: '開局快照',
             10: '開局指令', 11: '取消', 18: '遊戲數據', 26: '逐輪通知'}


def class_name(raw):
    try:
        data = bytes.fromhex(str(raw or '')[:240])
    except ValueError:
        return None
    start = data.find(b'CSanInet')
    if start < 0:
        return None
    end = start
    while end < len(data) and 32 <= data[end] < 127:
        end += 1
    return data[start:end].decode('ascii') or None


def feed_items(view):
    """Show each real item once; zero/unknown is never filled with demo data."""
    p = view.get('p34') or {}
    items = []
    for f in p.get('frames') or []:
        cmd = f.get('cmd')
        name = CMD_NAMES.get(cmd, 'cmd' + str(cmd)) if isinstance(cmd, int) else f.get('cls') or '未知'
        items.append({'wall': f.get('wall'), 'kind': 'frame', 'label': name,
                      'detail': 'type {} · {} B · {}'.format(f.get('type', '—'), f.get('len', '—'), f.get('sha8', ''))})
    for b in (p.get('sync') or {}).get('nonempty') or []:
        for r in b.get('records') or []:
            items.append({'wall': b.get('wall'), 'kind': 'data', 'label': class_name(r.get('raw')) or '遊戲數據',
                          'detail': '第 {} 輪 · sender={} · {} B · {}\n{}'.format(
                              b.get('round', '—'), r.get('sender', '—'), r.get('len', '—'),
                              r.get('sha8', ''), str(r.get('raw') or '')[:240])})
    for e in (p.get('control') or {}).get('events') or []:
        items.append({'wall': e.get('wall'), 'kind': 'control', 'label': e.get('ev') or '控制事件',
                      'detail': '{}{}{}'.format(e.get('text') or '',
                                               ' · rc=' + str(e['rc']) if e.get('rc') is not None else '',
                                               ' · ' + str(e['reason']) if e.get('reason') else '')})
    for m in (p.get('chat') or {}).get('messages') or []:
        items.append({'wall': m.get('wall'), 'kind': 'chat', 'label': m.get('text') or '—', 'detail': '風夜收到的對話'})
    return sorted(items, key=lambda x: x.get('wall') or 0, reverse=True)


def control_ready(view, now=None):
    now = time.time() if now is None else now
    transport = view.get('transport') or {}
    checked = transport.get('checked_at')
    return bool((view.get('p34') or {}).get('live_probe') and transport.get('status') == 'online'
                and isinstance(checked, (int, float)) and 0 <= now - checked <= 20)


def mode_text(view, now=None):
    t = view.get('transport') or {}
    p = view.get('p34') or {}
    if t.get('status') == 'file':
        return '回放 · 本地記錄'
    if t.get('status') == 'offline':
        return '離線 · 最後記錄'
    if control_ready(view, now):
        return '在線 · 風夜探針'
    if p:
        return '回放 · 採集已停止' if not p.get('live_probe') else '未就緒 · 觀測過期'
    return '未就緒 · 尚無風夜記錄'


def validate_control(payload):
    if not isinstance(payload, dict) or payload.get('op') not in ('chat', 'stop'):
        raise ValueError('未知操作')
    if payload['op'] == 'stop':
        return {'op': 'stop'}
    text = payload.get('text')
    if not isinstance(text, str) or not text.strip() or not 0 < len(text) <= 120:
        raise ValueError('發言需為 1–120 字')
    try:
        text.encode('gbk')
    except UnicodeEncodeError:
        raise ValueError('文字含 GBK 無法表示的字元') from None
    return {'op': 'chat', 'text': text}


class FengyeSource:
    def __init__(self, data_dir=None, replay=None, sources=None):
        self.sources = sources or backend.Sources(data_dir=data_dir or ROOT / 'data', source_file=replay)
        self.view = self.sources.view()

    def refresh(self, search=False):
        self.view = self.sources.refresh(search=search)
        return self.view

    def send(self, payload):
        payload = validate_control(payload)
        if self.sources.source_file or not control_ready(self.view):
            return {'status': 'error', 'error': 'probe_not_running：回放或未就緒時不能操控'}
        # Existing backend keeps its two-second limiter and remote once-only
        # writer. No retries, including an ambiguous SSH failure.
        return self.sources.control(payload)
