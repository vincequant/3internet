"""Install a native Mac .app entry, without embedding a browser or game files."""
from pathlib import Path
import plistlib
import shutil
import sys
import sysconfig
import json
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent


def main():
    target = Path.home() / 'Library/Application Support/SGI-Wine/風夜全知情報 Hub.app'
    binary = target / 'Contents/MacOS/FengyeHub'
    binary.parent.mkdir(parents=True, exist_ok=True)
    # Embed the existing Python runtime so the running process keeps this
    # bundle's identity and window, instead of becoming an anonymous Python.app.
    def literal(value):
        return json.dumps(str(value), ensure_ascii=False)
    source = '''#include <Python.h>
int main(int argc, char **argv) {
    PyConfig config;
    PyConfig_InitPythonConfig(&config);
    config.parse_argv = 0;
    config.write_bytecode = 0;
    PyStatus status = PyConfig_SetBytesString(&config, &config.home, HOME_PATH);
    if (!PyStatus_Exception(status)) status = PyConfig_SetBytesString(&config, &config.executable, PYTHON_PATH);
    if (!PyStatus_Exception(status)) status = PyConfig_SetBytesString(&config, &config.run_filename, SCRIPT_PATH);
    if (!PyStatus_Exception(status)) status = PyConfig_SetBytesArgv(&config, argc, argv);
    if (!PyStatus_Exception(status)) status = Py_InitializeFromConfig(&config);
    PyConfig_Clear(&config);
    if (PyStatus_Exception(status)) Py_ExitStatusException(status);
    return Py_RunMain();
}
'''
    macros = '#define HOME_PATH {}\n#define PYTHON_PATH {}\n#define SCRIPT_PATH {}\n'.format(
        literal(sys.prefix), literal(sys.executable), literal(ROOT / 'run.py'))
    with tempfile.TemporaryDirectory() as folder:
        code = Path(folder) / 'main.c'
        code.write_text(macros + source)
        library = Path(sysconfig.get_config_var('LIBDIR'))
        subprocess.run(['/usr/bin/clang', '-I' + sysconfig.get_path('include'), str(code),
                        '-L' + str(library), '-lpython' + sysconfig.get_python_version(),
                        '-Wl,-rpath,' + str(library), '-o', str(binary)], check=True)
    info = {'CFBundleIdentifier': 'com.vk.sgi.fengye-omni-hub', 'CFBundleName': '風夜全知情報 Hub',
            'CFBundleDisplayName': '風夜全知情報 Hub', 'CFBundleExecutable': 'FengyeHub',
            'CFBundlePackageType': 'APPL', 'CFBundleShortVersionString': '0.1.4',
            'NSHighResolutionCapable': True, 'LSMinimumSystemVersion': '14.0'}
    info['SGIFengyeSourceRoot'] = str(ROOT)
    icon = Path.home() / 'Library/Application Support/SGI-Wine/三国志 Wine.app/Contents/Resources/AppIcon.icns'
    if icon.is_file():
        resources = target / 'Contents/Resources'
        resources.mkdir(exist_ok=True)
        shutil.copy2(icon, resources / 'AppIcon.icns')
        info['CFBundleIconFile'] = 'AppIcon'
    (target / 'Contents/Info.plist').write_bytes(plistlib.dumps(info))
    print(target)


if __name__ == '__main__':
    main()
